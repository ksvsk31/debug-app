# Debug Bot — Master SDD (execution spec for Cline)

This is the entry point. It holds the rules every track follows: how to work, when to ask, how to save progress and resume, where files go, and how to add more repos and tracks. The tasks themselves are in the track files.

| File (in `<backend>/docs/debug-bot/`) | What it is | Who writes it |
|---|---|---|
| `sdd.md` | This file: shared rules | Given |
| `track-be.md` | Track **BE**: backend knowledge, flows, runner, debug CLI, logs, env diff | Given |
| `track-fe.md` | Track **FE**: Next.js frontend, discovered on the go | Given |
| `track-ln.md` | Track **LN**: field-level lineage DB → downstream → backend → frontend → UI | Given |
| `track-doc.md` | Track **DOC**: Confluence pages, automatic knowledge updates, export for MCP/LLM/Vertex | Given |
| `guide.md` | Backend build guide with full code (referenced as "Guide §X") | Given |
| `resume.md` | One-page card for humans: start, resume, move machines | Given |
| `progress.md` | Progress, current position, evidence, decisions, open questions | Cline |
| `files.txt` | Every file created or changed outside the bot folders, as `<repo>:<path>` | Cline |

---

## 1. How to start and resume (for the human)

1. Put all given files in `<backend repo>/docs/debug-bot/`.
2. Cline → Auto-approve: **on** for read files, edit files, safe commands; **off** (manual approval) for commands that call a network service or database.
3. Start a new Cline task in **Act** mode with the **start prompt**:

```
Read docs/debug-bot/sdd.md and execute it. Begin with the session start check (section 3).
Follow the operating rules (section 2) exactly and only ask me what section 4 allows.
```

To steer it to a specific track, add one line, for example `Work on track FE.`

- **After any interruption** (network, tokens, crash): new Cline task, same prompt.
- **Another machine:** ask Cline to `pack the debug bot`, copy the bundle, extract it in the folder that contains your repos, start Cline with the same prompt (details in `resume.md`).

---

## 2. Operating rules for Cline

1. **Work autonomously.** Do tasks in order (section 9). Decide reasonable things yourself and record each decision under *Decisions* (what and why, one line).
2. **Ask only for what section 4 lists.** Collect all open questions of the current task and ask them **once, together**; meanwhile continue with work that doesn't depend on the answers.
3. **Verify every task.** A task is done only when its *Done when* checks pass. Record the evidence (command + short output) under *Evidence*.
4. **Retry, then escalate.** If a check fails, fix it. After **two** failed fix attempts on the same task, ask (4.5) with the error, what you tried and your best guess.
5. **Discover, don't assume.** Inspect the real code before writing tooling for it (routing, HTTP clients, logger, data access, build setup). Adapt the guide's code and record adaptations under *Decisions*.
6. **Workspace layout (section 5).** Tooling lives only in `<backend>/tools/debug-bot/`. Each repo's knowledge lives in `<repo>/.knowledge/`. Cross-repo knowledge (profiles, links, lineage, docs, export) lives in `<backend>/system-knowledge/`. Repos are registered in `tools/debug-bot/config/repos.yaml`; **every script reads repo paths from there** and never hardcodes them. Wherever the guide says `~/work/ecom-debug-bot` or `../ecom-debug-bot`, use `tools/debug-bot`; for `npm --prefix ../ecom-debug-bot`, use `npm --prefix tools/debug-bot` from the backend repo (from another repo: `npm --prefix <relative path to backend>/tools/debug-bot`).
7. **No absolute paths in any file you write.** Paths are relative to the backend repo or the workspace root and resolved at runtime. Machine-specific values go only in `.env` files.
8. **Code changes to the application repos** are limited to what a task explicitly lists. Record every file you create or change outside `tools/debug-bot/`, `docs/debug-bot/`, `system-knowledge/` and `.knowledge/` in `docs/debug-bot/files.txt` as `<repo>:<path>` (e.g. `backend:src/server.ts`) **immediately after** changing it.
9. **Git is optional.** Local branches (e.g. `feat/debug-bot`) and local commits are fine for undo. **Never push, merge, rebase, reset or delete branches.** Never rely on git for progress.
10. **Safety (always):**
    - Never read, print, cat, grep or copy `.env*` files or anything in a `.clineignore`. Create/extend them only with `env:init`; see what's missing only with `env:check` (names, never values).
    - Never put tokens, cookies, passwords or auth headers in any command, file or message.
    - Calls to dev/stage/qa services: **read-only** (GET; plus search-only endpoints where a task allows it), via public `curl` or the `debug` CLI.
    - **Production: public read-only only.** Allowed: GET to prod endpoints that need no login, token or cookie (public APIs, public storefront pages), via public `curl` or the `debug` CLI in `prod` (public) mode. Not allowed: anything needing prod credentials (prod DB, authenticated APIs, prod cache, running the backend or workers against prod). Reading prod logs needs a task that allows it and the human's approval.
    - Writes outside the repos (e.g. publishing to Confluence) only when a task allows it **and** the human said so in the current session. Default is dry-run.
    - Live tests may use **dev, stage and qa** (the user confirmed on 2026-10-28 that these systems hold no personal or secure data). `prod` is public read-only as above.
    - The systems hold no personal or secure data (confirmed by the user). Masking in the tools stays on as a cheap safety net, and secrets (tokens, passwords, keys) are never written anywhere.
    - No `sudo`, global installs or system changes without asking (4.4). Installing a registered repo's own dependencies with its lockfile (`npm ci`, `pnpm install --frozen-lockfile`, `yarn install --immutable`) is allowed.
11. **Keep output small.** Pipe large outputs through `head -c 5000`; summarise.
12. **Knowledge quality** (applies to every knowledge file, doc page and export):
    - **Traceable:** every fact cites its source (`<repo>:<path>:<line>` or a generated file).
    - **Reproducible:** deterministic parts come from scripts; AI-written parts (module summaries, rules, page prose, manual lineage edges) are marked `generated_by: cline` with the source hash they were written from, so they can be detected as stale.
    - **Small:** `INDEX.md` files ≤ ~1,500 tokens; any single page ≤ ~2,000 tokens; split larger content into linked files.
    - **Clear:** plain language, one idea per paragraph, examples with real but non-personal values (SKUs, offer ids), and a "how to debug" section wherever relevant.
13. **Expandability.** Scripts take a repo name (or loop over all repos of a `kind`) instead of assuming one repo. New repo kinds plug in through `kind` (e.g. `hapi`, `nextjs`). Don't fork scripts per repo.
14. **Knowledge from code and data.** Describe every area from both sides:
    - **What the code says can happen** (`source: code`): flows, gates, types, static lineage.
    - **What actually happens with real data** (`source: data`, with `env` and `observed_at`): profiles of tables, API responses and cache entries, saved runs of real sample cases, page data, and lineage proved by matching real values.

    Label every fact with its source. Report disagreements between code and data as findings: they're often the bug.

    All data observations follow `tools/debug-bot/config/data-policy.yaml`:
    - allowed envs only;
    - small samples;
    - example values may be stored for all business fields (no personal data in these systems);
    - credentials-like fields (token, password, secret, key) are never stored.
15. **Token economy.** Knowledge is built once and read many times, so optimise for cheap reading:
    - **Layered:** router (`system-knowledge/INDEX.md`) → cards → source files → code lines. Each layer points to the next with exact ids, paths and lines.
    - **Query, don't read:** big or generated files are query-only, through `debug kb`, `debug lineage` and `debug search`.
    - **Compute, don't reason:** anything a script can work out (rule checks, joins, comparisons, diffs) is a command that returns a short result (`debug diagnose`, `debug envdiff`), not Cline reasoning over raw data.
    - **Budgets** are enforced by `kb:check`, and output is compact by default.
    - **Reuse:** confirmed diagnoses become incidents that `kb similar` finds.
    - **The same applies while building:** read only what the current task needs (3.7).

---

## 3. Resumability rules

### 3.1 Save after every step
Each task has numbered steps (`BE05.2`, `FE01.3` …). **Before** a step, update *Current position* (status `in-progress`, what you're about to do). **After** it, mark it done and write *Next action*. An interruption loses at most one step.

### 3.2 Every step must be safe to rerun
Check before acting (file exists with intended content → skip; dependency installed → skip; output newer than inputs → skip). Write files whole. Long commands can simply be rerun.

### 3.3 Session start check (first thing in every new Cline task)
Read only what 3.7 allows, then:
1. If `docs/debug-bot/progress.md` doesn't exist → create it (section 7) and start at `BE00`.
2. Read *Current position*, *Tracks*, *Waiting on the human* and recent *Decisions*.
3. **Track:** if the human named a track, use it. Otherwise continue the track in *Current position*; if that track is finished, pick the next track in section 9 whose prerequisites are done.
4. **Machine check:** compare `Machine` with `hostname`. If different, or `tools/debug-bot/node_modules` is missing, run machine setup (3.4) first.
5. **Codebase check:** for each registered repo with git, compare its *Base commit* with `git rev-parse HEAD`. If files listed for that repo in `files.txt` changed upstream since then, ask (4.6) before continuing.
6. Status `in-progress` → redo that step from its start. `waiting-on-human` → re-ask once, then continue with other unblocked tasks. `done` → do *Next action*.
7. Re-run the *Done when* check of the last completed task. If it fails, reopen that task.

### 3.4 Machine setup (what a bundle can't carry)

| Item | Action |
|---|---|
| Node ≥ 20 | `node -v`; ask the human to install if lower (4.4) |
| Tool dependencies | `npm --prefix tools/debug-bot ci` |
| Registered repos | Check each path in `repos.yaml` exists; install a repo's own dependencies if a track needs its types (lockfile install) |
| Network to dev/stage | Repeat the BE01 health check (and FE base URL check if FE is registered) |
| Secrets | `env:init`, then `env:check`; ask (4.2) the human to fill the empty keys |
| Builds | Backend build (runner needs `dist/`) |
| Search index, lineage graph | `npm --prefix tools/debug-bot run index` (and `lineage:build` if LN started) |
| Hooks, crontab, Docker | Machine-local; ask (4.4) before setting up |
| Cline settings | Remind the human (section 1) |

Then set `Machine:` to this hostname.

### 3.5 Token / context limits
After each finished **task**, write *Next action*. If the conversation is long, tell the human it's a good point to start a new Cline task with the start prompt, and stop cleanly.

### 3.6 Keep progress small
`progress.md` is read at every session start, so keep it under ~3,000 tokens:
- *Step log*: last 30 lines;
- *Evidence*: last 3 tasks per track;
- *Decisions*: one line each.

Move older lines to `progress-archive.md` (append-only; read it only when needed).

### 3.7 Read only what you need
Per session:
- this file: sections 2–4 and 7, once;
- the track file: only the current task's section and the order section (find them by searching for the task id, then read that line range);
- `guide.md`: only the sections a task cites, by heading.

Never load a whole track or the whole guide "for context".

### 3.8 Handoff bundle
`npm --prefix tools/debug-bot run pack` writes `debug-bot-handoff-<date>.tgz` into the **workspace root** (the folder that contains the repos). It holds, for every registered repo, `.knowledge/`, `AGENTS.md`, `.clinerules/`, `.clineignore` and its files from `files.txt`, plus `tools/debug-bot/`, `docs/debug-bot/` and `system-knowledge/` from the backend. Never secrets, `node_modules`, search indexes or logs.

---

## 4. When to ask the human (and only then)

| # | Situation | What to ask |
|---|---|---|
| 4.1 | A value only the human knows that isn't in code, config or docs in the repos | e.g. a base URL per environment, a real test SKU/offer/store, OpenSearch index names, Confluence space, which app is the storefront when several exist |
| 4.2 | Secrets | Run `env:init` + `env:check`, tell the human which file and which empty keys to fill (names only). Never ask for values in chat. |
| 4.3 | Approvals | Prod log access; any prod access beyond public GET endpoints; publishing to Confluence; anything a track marks "needs approval" |
| 4.4 | Risky actions or changes outside the bot folders | App code changes beyond what a task lists; build settings; deleting files; global installs; Docker; crontab; git hooks; sudo |
| 4.5 | Stuck | Same task failed twice after fixes |
| 4.6 | Costly ambiguity | Two plausible interpretations where a wrong guess means redoing a lot; upstream changes to files in `files.txt` |

Everything else: decide, record under *Decisions*, continue.

---

## 5. Workspace, repos and tracks

### 5.1 Layout

```
<workspace root>/                      # folder that contains the repos (bundle is extracted here)
  ecom-backend/                        # backend repo (name may differ)
    tools/debug-bot/                   # ALL tooling, for every repo
      config/repos.yaml                # registered repos (see 5.2)
      config/environments.yaml         # base URLs per env (no secrets)
      config/data-policy.yaml          # what data may be observed and stored (BE23)
      config/samples.yaml              # real sample cases per flow/page (BE23, FE09)
      env-templates/  .env.*           # secrets: created by env:init, values by the human
    docs/debug-bot/                    # SDD, tracks, guide, progress, files.txt
    system-knowledge/                  # cross-repo knowledge
      profiles/      <repo>.yaml       # discovered architecture of each repo
      links/         http.yaml         # frontend calls <-> backend routes
      lineage/       graph.json, fields-index.yaml, manual-edges.yaml, observed-edges.yaml, review.yaml, schema.md
      docs/          Markdown pages (+ _prose/ written by Cline)
      confluence/    storage-format pages + diagrams, pages.yaml
      export/        manifest.json, documents.jsonl, chunks.jsonl, graph.json, llms.txt
      INDEX.md       router (<= ~800 tokens): what exists, which command answers what, query-only files
      kb/            index.json, search.json, cards/ (one compact card per flow, page, field)
      incidents/     confirmed diagnoses (symptom -> cause), found by `kb similar`
      STALE.md       AI-written parts that need refreshing, across all repos
    .knowledge/                        # code knowledge + data/observed/, data/findings.md, observed/flows/
    AGENTS.md  .clinerules/  .clineignore
  ecom-web/                            # frontend repo (registered in FE00)
    .knowledge/  AGENTS.md  .clinerules/  .clineignore
  ecom-debug.code-workspace            # VS Code multi-root workspace (FE00)
```

### 5.2 Repo registry — `tools/debug-bot/config/repos.yaml`

```yaml
workspace_root: ..                 # relative to the backend repo
system_knowledge: system-knowledge # relative to the backend repo
repos:
  backend:
    path: .                        # relative to the backend repo
    kind: hapi
  # frontend:                      # added in FE00
  #   path: ../ecom-web
  #   kind: nextjs
```

### 5.3 Tracks

| Track | File | Purpose | Prerequisites | Tasks |
|---|---|---|---|---|
| **BE** | `track-be.md` | Backend: knowledge from code **and data**, flows, runner, debug CLI, prod logs, env diff, caches, queues | — | BE00–BE28 |
| **FE** | `track-fe.md` | Frontend (Next.js): discover architecture, flows, links to backend, page checks, observed page data | BE16 | FE00–FE10 |
| **LN** | `track-ln.md` | Field lineage across DB, downstream, backend, frontend, UI, from code and from real values | FE05 (BE-only lineage can start after BE16) | LN00–LN08 |
| **DOC** | `track-doc.md` | Confluence pages, automatic knowledge updates, export for MCP/LLM/Vertex | BE16 (pages grow as other tracks finish) | DOC00–DOC08 |

---

## 6. Command reference

All from the backend repo root (from another repo, use the relative path to `tools/debug-bot`). Commands appear as their tasks are done.

```bash
# BE track
npm --prefix tools/debug-bot run extract | flows | stale | check-rules | index | catalog | logs
npm --prefix tools/debug-bot run -s debug -- request|worker|routes|workers|api|db|search|job-traces|envdiff|cache ...
npm --prefix tools/debug-bot run env:init | env:check | pack
npm --prefix tools/debug-bot run kb:build | kb:check                   # index, cards, token budgets (BE28)
npm --prefix tools/debug-bot run -s debug -- diagnose <flow> --env <env> --<input> <value> ...   # all rule checks in one call (BE27)
npm --prefix tools/debug-bot run -s debug -- kb find|card|show|refs|similar ...                # cheap knowledge lookup (BE28)
npm --prefix tools/debug-bot run data:observe | observe:flows          # data knowledge (BE24-BE25)
npm --prefix tools/debug-bot run -s debug -- request <env> <url> --save <dir>   # save a full masked run
# FE track (repo name from repos.yaml)
npm --prefix tools/debug-bot run fe:extract -- --repo frontend
npm --prefix tools/debug-bot run -s debug -- page <env> <path> [--find "<value>"] [--rsc]
npm --prefix tools/debug-bot run links
# LN track
npm --prefix tools/debug-bot run lineage:build | lineage:observe
npm --prefix tools/debug-bot run -s debug -- lineage <node id | Type.field | --ui Component.prop | --search word> [--observed]
# DOC track
npm --prefix tools/debug-bot run docs:build | docs:confluence | knowledge:update | knowledge:export
npm --prefix tools/debug-bot run docs:publish -- --dry-run      # real publish only when the human says so
```

---

## 7. Progress file template

Create `docs/debug-bot/progress.md`:

```markdown
# Debug bot — progress

Live test environments: dev, stage, qa; prod = public GET endpoints only
Base commits: backend=<sha or "no git">

## Current position
Track: BE   Task: BE00   Step: BE00.1   Status: in-progress
Doing: creating progress file
Next action: BE00.2
Last command: -
Machine: <hostname>   Updated: <timestamp>

## Tracks
| Track | Status | Next task | Notes |
|---|---|---|---|
| BE | in progress | BE00 | |
| FE | not started | FE00 | needs BE16 |
| LN | not started | LN00 | needs FE05 |
| DOC | not started | DOC00 | needs BE16 |

## Track BE — tasks
<!-- one "- [ ] <id> <title>" line per task heading in track-be.md -->

## Track FE — tasks
## Track LN — tasks
## Track DOC — tasks

## Step log
<!-- "BE05.2 done - <short result>" -->

## Machine setup
## Evidence
## Decisions
## Waiting on the human
## Summaries
<!-- one per finished track -->
```

Build each track's checklist by copying the task headings (`### <ID> — <title>`) from its track file. When a track file gains tasks later, add the missing lines; never remove ticked ones.

---

## 8. Adding a repo or a track (expandability)

**New repo** (e.g. a second frontend, another service):
1. Add it to `repos.yaml` with its `kind`. If the kind is new, add an adapter for it in the extract and flow scripts (entry points, HTTP calls, data access), keeping shared logic in one place.
2. Create its `.knowledge/`, `.clineignore`, `AGENTS.md`, `.clinerules/`; add it to the VS Code workspace file.
3. Run discovery for it (like FE01) into `system-knowledge/profiles/<repo>.yaml`.
4. Rebuild links (`links`), lineage (`lineage:build`) and docs (`docs:build`): they loop over all repos.

**New track:** create `track-<id>.md` using this template, add a row to 5.3, an entry in section 9, and its checklist in `progress.md`.

```markdown
# Track <ID> — <name>
Purpose: <one paragraph>
Prerequisites: <task ids>
Outputs: <files>

### <ID>00 — <title>
- **Steps:** 1. ... 2. ...
- **Done when:** ...
- **Ask if:** ...
```

---

## 9. Track order

```
BE00 … BE16 (core, incl. BE27 diagnose + BE28 kb) ──┬─> BE23 … BE25 (data knowledge: policy, samples, profiles, observed runs)
                     ├─> BE17 … BE22 (prod logs, env diff, caches, queues) ──> BE26 hand-over
                     ├─> FE00 … FE10 (incl. FE09 observed page data) ──> LN00 … LN08 (static + observed lineage)
                     └─> DOC00 … DOC03 (docs for what exists) ──> DOC04 … DOC08 (all repos, updates, export)
```

- Default sequence when the human doesn't name a track: BE core → BE data knowledge (BE23–BE25) → FE → LN → DOC → remaining BE extensions. If a task waits on the human, continue with any other unblocked task in any track.
- Each track ends with its own hand-over task (summary + pack).
