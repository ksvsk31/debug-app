# Track FE — Frontend (Next.js)

**Purpose:** extend the debug bot to the Next.js storefront (an app built from library packages in several folders, with SSR). Cline discovers the architecture itself, maps pages and their data, links every frontend API call to its backend route, and adds page-level checks.
**Prerequisites:** BE16 (backend core done).
**Rules:** everything in `sdd.md` applies. References like "(4.1)" point to SDD §4.
**Code reference:** no separate guide. Reuse the backend tools (`extract`, `flows`, `stale`, `check-rules`, `index`, `debug`) by adding a `nextjs` adapter. Don't copy them into a second set of scripts (SDD §2.13).

## Outputs and end state

```
<workspace root>/
  ecom-debug.code-workspace                  # multi-root VS Code workspace (backend + frontend)
  <frontend repo>/
    AGENTS.md  .clinerules/ecom-debug.md  .clineignore
    .knowledge/
      INDEX.md  glossary.yaml  search-synonyms.yaml  STALE.md
      generated/   pages.yaml  api-calls.yaml  components.yaml  env-vars.yaml  cache.yaml
                   symbols.yaml  call-graph.json  manifest.json
      observed/pages/<page>/<case>/   # observed page data per sample case (FE09)
      data/findings.md                # frontend code-vs-data findings (FE09)
      flows/       one file per page / route handler / API route (+ .mmd, INDEX.md, _data-links.yaml)
      rules/       page-level rules with checks (UI gates + data)
      modules/     one summary per package / feature folder
      prompts/
  <backend repo>/
    tools/debug-bot/src/...                  # nextjs adapter, links builder, `debug page`
    system-knowledge/
      profiles/frontend.yaml                 # discovered architecture (FE01)
      links/http.yaml                        # frontend calls <-> backend routes (FE05)
```

**Definition of done (FE10):** for "<something> is not showing / wrong on <page> for SKU <sku> in <env>", Cline answers with one table covering the page, the frontend rules and UI gates, the linked backend route and the backend rules, with the value found at each step.

---

## Tasks

### FE00 — Register the frontend repo
- **Steps:**
  1. Find the frontend repo: look in the workspace root for folders with `next.config.*`, or a `package.json` that depends on `next`. Exactly one candidate → use it. Several → ask (4.1) which one is the storefront. None → ask (4.1) where it is.
  2. Add it to `tools/debug-bot/config/repos.yaml` as `frontend: { path: ../<folder>, kind: nextjs }`.
  3. Create `<workspace root>/ecom-debug.code-workspace` listing both repo folders, and tell the human: "Reopen VS Code with File → Open Workspace from File → ecom-debug.code-workspace, then start a new Cline task with the start prompt." Set status `waiting-on-human`.
  4. After reopening: confirm you can read `<frontend>/package.json`. If this Cline build can't see the second folder, use the fallback: the human opens the **workspace root** folder instead, and you add a `.clineignore` there with `**/.env`, `**/.env.*`, `**/*.pem`, `**/*.key`, `**/node_modules`. Record which setup is used.
  5. In the frontend repo: create `.clineignore` (`.env`, `.env.*` — this covers `.env.local` — `**/*.pem`, `**/*.key`), the `.knowledge/` folder, and check `.gitignore` covers `.env*`.
  6. Add `frontend=<sha or "no git">` to *Base commits* and the FE checklist to `progress.md`.
- **Done when:** `repos.yaml` lists the frontend; Cline can read a frontend file; `.clineignore` exists in the frontend repo; `pack` includes `<frontend>/.knowledge` (check with `tar -tzf`, then delete the test bundle).

### FE01 — Discover the frontend architecture
Answer every item below **from the code and config**, each with evidence (`<repo>:<path>:<line>`). Write the result to `system-knowledge/profiles/frontend.yaml` (shape below). Ask only about items you cannot determine **and** that block a later task. Ask them together, once, at the end of this task.

- **Steps:**
  1. **Package manager and monorepo tool:** lockfiles (`package-lock.json`, `yarn.lock`, `pnpm-lock.yaml`); `workspaces` in `package.json`; `pnpm-workspace.yaml`, `nx.json`, `turbo.json`, `lerna.json`, `rush.json`.
  2. **Packages:** list every workspace package. Identify the Next.js app(s) (depends on `next`, has `next.config.*`) and the library folders: path, package name, likely role from contents (UI components, data/API client, shared types/utils, config). Map dependencies between them (package.json deps, tsconfig `paths`/project references, `transpilePackages` in `next.config`).
  3. **Next.js:** version; **Pages Router** (`pages/` or `src/pages/`) and/or **App Router** (`app/` or `src/app/`); per route, the rendering mode:
     - Pages Router: `getServerSideProps` (SSR), `getStaticProps`/`getStaticPaths` + `revalidate` (SSG/ISR), or none (static/client).
     - App Router: async server components; `"use client"` components; `export const dynamic`/`revalidate`; `fetch(..., { cache, next: { revalidate, tags } })`; route handlers `app/**/route.ts`.
     - Also: Pages API routes `pages/api/**`, `middleware.ts`, and `next.config` `rewrites`/`redirects`/`headers`/`basePath`/`i18n`.
  4. **How the frontend calls the backend:** every HTTP client and wrapper (fetch, axios, ky, graphql clients, generated clients such as openapi-typescript/orval); where base URLs come from (env vars incl. `NEXT_PUBLIC_*`, config files, rewrites); which calls run on the server (SSR, server components, route handlers) vs in the browser (client components, hooks); whether Next API routes or route handlers proxy to the Hapi backend (BFF).
  5. **Client data and state:** React Query/TanStack Query, SWR, Redux/RTK (incl. RTK Query), Zustand, context; where data is transformed (selectors, mappers, `select` options).
  6. **Backend contract:** in the backend repo, do Hapi routes define response schemas (`options.response.schema` with Joi)? Is there OpenAPI generation (e.g. hapi-swagger)? Is there a shared types package used by both repos?
  7. **Environments:** base URLs of the web app and of the API per environment (dev/stage/qa) from config, `.env.example` files, CI/deploy files (never from real `.env` files). Write them to `tools/debug-bot/config/environments.yaml` under `web_base_url`.
  8. **Logging/monitoring:** SSR logger (and whether its logs go to OpenSearch), Sentry/RUM or similar.
  9. **Test tooling:** Playwright/Cypress/Jest present? (Useful for optional runtime checks.)
  10. Write the profile; ask the blocking unknowns (4.1) together.
- **Profile shape:**
  ```yaml
  monorepo: { tool: pnpm-workspaces, package_manager: pnpm, evidence: [frontend:pnpm-workspace.yaml:1] }
  packages:
    - { name: "@shop/web", path: apps/web, role: next-app, depends_on: ["@shop/ui", "@shop/data"] }
    - { name: "@shop/ui", path: libs/ui, role: ui-components }
    - { name: "@shop/data", path: libs/data, role: api-client, depends_on: ["@shop/types"] }
  next:
    version: "14.2.x"
    routers: [app, pages]
    rendering: { ssr: [...], ssg_isr: [...], server_components: [...], client_only: [...] }
    api_routes: [...]
    route_handlers: [...]
    middleware: apps/web/middleware.ts
    rewrites: [{ source: /api/:path*, destination: "${API_URL}/:path*" }]
  backend_calls:
    style: [fetch-wrapper]
    wrappers: [{ name: apiGet, at: "frontend:libs/data/src/http.ts:12" }]
    base_url_sources: [NEXT_PUBLIC_API_URL, API_URL]
    runs_on: { server: [...], client: [...] }
    bff: none          # or: next-api-routes / route-handlers
  client_state: [tanstack-query]
  backend_contract: { joi_response_schemas: partial, openapi: none, shared_types: none, evidence: [...] }
  environments: { dev: { web: ..., api: ... }, stage: { ... } }
  logging: { ssr_logger: ..., opensearch: unknown }
  testing: [playwright]
  unknowns:
    - { item: "stage web base URL", blocks: FE07, question: "What is the stage URL of the storefront?" }
  ```
- **Done when:** the profile exists; every item has a value with evidence or is listed under `unknowns` with what it blocks; blocking questions (if any) were asked once.
- **Ask if:** several Next.js apps and it's unclear which is the storefront; base URLs not discoverable; a library folder looks unused and you're unsure whether to include it.

### FE02 — Frontend tooling setup
- **Steps:**
  1. If the frontend's dependencies aren't installed, run its lockfile install (allowed, SDD §2.10). Type resolution for React/Next needs them.
  2. Add a `nextjs` adapter module (`src/adapters/nextjs.ts`) and make `extract`, `flows`, `stale`, `check-rules` and `index` accept `--repo <name>`, choosing the adapter by `kind`.
  3. Build a ts-morph `Project` that loads the app's tsconfig **and** every library package's tsconfig (`addSourceFilesFromTsConfig`), honouring `paths` and project references, so imports across the library folders resolve to their source.
  4. Create the frontend `.knowledge/` skeleton and an `INDEX.md` stub.
- **Done when:** a check script prints the number of source files per package and resolves one import from the app into a library package to its declaration file.

### FE03 — Frontend extractor (`fe:extract`)
Write to `<frontend>/.knowledge/generated/`:
- `pages.yaml`: URL pattern from file-system routing (`pages/products/[sku].tsx` → `/products/[sku]`; `app/(shop)/products/[sku]/page.tsx` → `/products/[sku]`; ignore route groups `(x)`, parallel `@slot` and intercepting `(.)` segments), router, rendering mode, data functions / server-side fetches, layout chain (App Router), file.
- `api-calls.yaml`: each HTTP call with method, normalized URL template (`${sku}` → `{sku}`; base URL variable recorded separately), where it runs (server/client/both/unknown), wrapper, response type (generic argument, `as T`, or `Promise<T>` return type), `file:line`, enclosing function, and the pages that use it (reverse call graph).
- `components.yaml`: function components with props type, `"use client"` flag, child components (JSX tags resolved to declarations), package.
- `env-vars.yaml`, `cache.yaml` (revalidate, fetch cache options, `dynamic`, Cache-Control headers), `symbols.yaml`, `call-graph.json`, `manifest.json` (same shapes as the backend).
- **Steps:** 1. Implement in the `nextjs` adapter, reusing the backend extractor's helpers. 2. Add `"fe:extract"`. 3. Run it. 4. Spot-check three pages by reading their files.
- **Done when:** `pages.yaml` has every route file; `api-calls.yaml` has every call FE01 found, with response types where the code declares them; the spot-checks match.

### FE04 — Frontend flow maps
- **Steps:** 1. Extend `flows.ts` with `nextjs` entry points: every page (data function + page component), route handler, API route and the middleware. 2. Gates: the existing ones plus **UI gates**: `{cond && <X/>}`, ternaries choosing what to render, early `return null`, `notFound()`, `redirect()`; mark them `[SILENT]` unless they log. 3. Record HTTP calls (to the backend), client-side fetch hooks and cache settings per step. 4. Run `flows --repo frontend`.
- **Done when:** `<frontend>/.knowledge/flows/INDEX.md` lists every page and handler; the product detail page flow shows its API calls and the UI gates for offer/price display.

### FE05 — Link frontend calls to backend routes (`links`)
- **Steps:**
  1. Create `src/links/build.ts`: for every frontend call (and every Next API route or route handler that proxies), resolve the final backend path (strip the base URL, apply `rewrites` and proxy prefixes), then match it to backend routes from `hapi-routes.yaml` by method + path pattern (`{p}`, `[p]` and `:p` all normalize to `{}`).
  2. Write `system-knowledge/links/http.yaml`:
     ```yaml
     matched:
       - fe: { call: "GET {API_URL}/products/{sku}/offers", at: "frontend:libs/data/src/offers.ts:18", response_type: OffersResponse, runs_on: server }
         be: { route: "GET /products/{sku}/offers", handler: "backend:src/offers/handler.ts#getOffersHandler", response_type: OfferDto[] }
         confidence: pattern        # exact (same declared type/shared package) | pattern | guess
     unmatched_fe_calls: [...]      # calls to other services or external APIs
     unused_be_routes: [...]        # routes no frontend call reaches (may be used by other clients)
     ```
  3. Add `"links"` and run it; review the unmatched calls and record explanations under *Decisions*.
- **Done when:** every frontend call to the backend's base URL is matched or explained.
- **Ask if:** a frontend base URL points to a service not in `repos.yaml` and it's unclear whether it's internal (4.1).

### FE06 — Frontend knowledge files
- **Steps:**
  1. Module summaries per package and per feature folder (adapt `.knowledge/prompts/module-summary.md`; save a frontend copy).
  2. Glossary additions (UI and business terms), `search-synonyms.yaml`; extend `index` so the search covers all registered repos.
  3. Rules files for the key pages (product detail page first) by adapting `flow-to-rules.md` to UI: each rule is a UI gate or a data condition, with `check` using `debug page` (FE07) or the backend checks reached through `links/http.yaml`. Add `probe`/`assert` (BE27 format): page gates use probe kind `page` (pick from props or a `--find` value), and one `flow` probe pulls in the linked backend flow's diagnosis with mapped inputs.
  4. Frontend `INDEX.md` (≤ 1,500 tokens, pointing to the system router), then `kb:build` and `kb:check` so frontend pages, rules and cards are in the index.
  5. Frontend `AGENTS.md` + `.clinerules/ecom-debug.md`, and a short frontend section in the backend `AGENTS.md`. Frontend `AGENTS.md` must say: knowledge = frontend `.knowledge/INDEX.md` + backend `.knowledge/INDEX.md` + `system-knowledge/`; live data only via `npm --prefix <relative path>/tools/debug-bot run -s debug -- …` and public GET `curl`; and the debugging steps: page → frontend rules/UI gates → `links/http.yaml` → backend rules → (after LN) `debug lineage` → answer table with a *layer* column.
  6. Run `stale --repo frontend` and `check-rules --repo frontend`.
- **Done when:** frontend `STALE.md` says all current; the product page rules file maps every gate in its flow; `check-rules` passes for both repos.

### FE07 — `debug page` command
- **Steps:**
  1. Add to `debug.ts`: `page <env> <path> [--find "<value>"] [--rsc]`. GET `web_base_url + path` with no cookies or auth (public pages only). Works for dev, stage, qa **and prod** (public storefront), using `web_base_url` per env from `environments.yaml`. Print: status, final URL after redirects, cache headers (`cache-control`, `age`, `x-nextjs-cache`, CDN cache headers if present).
     - Pages Router: parse `<script id="__NEXT_DATA__">` and print masked, truncated `props.pageProps` and `buildId`.
     - App Router: say so; with `--rsc`, also GET the path with header `RSC: 1` and search the returned payload.
     - `--find`: report whether the value appears in the HTML, the props or the RSC payload, and where.
  2. Add `page-api <env> <path>` for Next API routes / route handlers (GET only).
  3. Add probe kind `page` to `debug diagnose`, so page rules run in the same single call.
  4. Update `USAGE` and both `AGENTS.md` files.
- **Done when:** on dev, `debug page dev /products/<test sku>` prints status and cache headers, and `--find "<a known price or offer id>"` locates it.
- **Ask if:** a test SKU (4.1); the dev storefront needs login even for product pages (4.6: then only `page-api` and backend checks are possible).

### FE08 — Frontend logs (optional)
- **Steps:** 1. If FE01 found SSR logs shipped to OpenSearch, ask once (4.4): "Apply the prod-log tasks (BE17–BE20) to the frontend now, later, or skip?" 2. If now: run BE17–BE20 with `--repo frontend` (logger profile, catalog, silent UI gates, runbooks and dashboards for pages).
- **Done when:** decision recorded, or frontend runbooks exist and one query was confirmed by the human.

### FE09 — Observed page data
- **Steps:**
  1. Add frontend cases to `samples.yaml`: the product page for each backend case (same SKUs), plus page-only cases if the frontend has its own gates (feature flags, A/B variants, locale). Observe them in stage **and prod** (public pages) so differences between the two are captured.
  2. Add `--save <dir>` to `debug page`. Save status, cache headers, the props shape plus allowed values (Pages Router) or the RSC matches (App Router), and the HTML text around `--find` values to `<frontend>/.knowledge/observed/pages/<page>/<case>/`, masked per `data-policy.yaml`.
  3. For the same case, link to the backend observation (`.knowledge/observed/flows/...` from BE25) so the page and the route it calls are tied together.
  4. If Playwright is present (FE01), optionally record the client-side network calls and the rendered text of key components (by `data-testid`) for each case.
  5. Code vs data findings for the frontend, in `<frontend>/.knowledge/data/findings.md`: props fields never rendered, API fields received but unused, UI gates whose outcome differs from `expect`, unexpected cache headers.
- **Done when:** every product-page case has an observation linked to its backend observation; findings are listed or "none".

### FE10 — End-to-end acceptance and hand-over
- **Steps:**
  1. Ask (4.1) for one real UI case, e.g. "offer badge not showing on the product page for SKU X in dev", and whether it's expected to show.
  2. Answer it by following the frontend `AGENTS.md` only (token rules): `kb card` for the page → `debug diagnose <page flow>` (which includes the linked backend flow) → cited code lines → envdiff/cache where relevant. Record tool calls and approximate tokens.
  3. Ask the human to confirm the verdict; if wrong, fix the faulty rule, gate or link and repeat.
  4. Write the FE summary under *Summaries* (what was built, the profile highlights, unmatched links, open `UNCLEAR:` items) and run `pack`.
- **Done when:** the answer has one table across layers (layer | rule | value | pass/fail | code), the human confirms it, and the summary and bundle exist.

---

## Order within track FE

```
FE00 → FE01 → FE02 → FE03 → FE04 → FE05 → FE06 → FE07 → FE09 → FE10
FE08: optional, after FE04
```

FE00 and FE01 may wait on the human (reopening VS Code, unknowns). Meanwhile continue other tracks' unblocked tasks.
