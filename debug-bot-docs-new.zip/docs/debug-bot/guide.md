# eCommerce Debug Bot – Step-by-Step Build Guide

Oct 27, 2026 · @Sunil

## Before you start

Follow the phases in order; each one ends with a **Verify** step, so don't move on until it passes. The runner, tools, secrets and databases stay on your machine. Only what the AI tool asks for (knowledge files and masked, compressed traces) goes to your company-approved AI tool.

The guide assumes your eCommerce backend is a Node/TypeScript repo called `ecom-backend` using Hapi (an API server plus cron-driven service workers), axios and Postgres. Where your stack differs (NestJS, Prisma, Mongo, fetch), the step says what to swap.

**Prerequisites**

| Item | Minimum | Check command |
| --- | --- | --- |
| OS | macOS 13+, Ubuntu 22.04+, or Windows 11 with WSL2 | — |
| RAM | 8 GB (16 GB recommended) | — |
| Disk | 10 GB free | `df -h` |
| Node.js | 20 LTS or newer | `node -v` |
| Docker Desktop / Docker Engine | 24+ | `docker -v` |
| git | any recent | `git --version` |
| Approved AI tool | Cline (corporate build) with terminal commands allowed (see Phase 1) | — |

If Node is missing, install it with nvm:

```bash
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.40.1/install.sh | bash
# restart the terminal, then:
nvm install 20
nvm use 20
node -v   # should print v20.x
```

**Folder layout you will end up with**

```
~/work/
  ecom-backend/            # your existing repo (small code changes in Phase 6)
    .knowledge/            # generated + hand-written knowledge (Phases 4–5)
    AGENTS.md              # pointer for any AI tool
  ecom-debug-bot/          # NEW tooling repo you create in Phase 3
    src/extract/           # code extractor
    src/mcp/               # MCP server (the bot's tools)
    src/profile/           # data profiler
    src/search/            # semantic search
    config/environments.yaml
    .env.stage             # secrets, never committed
```

Keeping the bot in a separate repo means your production code only gains the small explain-mode change; everything else lives outside it.

## Phase 1 — Prepare Cline

Your corporate Cline is the bot's "brain". It reads your code and the `.knowledge/` files with its built-in file tools, runs the read-only `debug` command (Phase 7) in the VS Code terminal, reads the output, and explains it. No MCP and no local model are needed.

| Cline needs to | Built-in? | Used for |
| --- | --- | --- |
| Read and search files in the workspace | Yes | Code, `AGENTS.md`, `.knowledge/` |
| Run terminal commands (with your approval) | Yes, allowed in your build | The `debug` CLI: live stage/qa data |
| Follow project rules | Yes, `.clinerules/` | The bot's instructions (Phase 7.5) |

### 1.1 Confirm Cline can run a command and read its output (2 minutes)

1. Open the `ecom-backend` folder in VS Code and open Cline.
2. In **Act** mode, ask: "Run `node -v` and `npm -v` in the terminal and tell me both versions."
3. Cline shows the command and asks for approval. Approve it.

**Pass:** Cline replies with both version numbers (Node should be 20 or newer). That proves it can run a command and read the result, which is all the bot needs.

**If it fails:** if Cline says it can't run commands, check Cline's settings for terminal or command execution (some builds call it "execute command"). If the output never comes back, enable VS Code's shell integration (Settings → search "shell integration" → enable) and restart VS Code.

**Then check the two things the debug tool relies on.** Ask Cline to run each command (approve each one):

| Check | Ask Cline to run | Pass if the output shows |
| --- | --- | --- |
| Runs TypeScript | `npx -y tsx -e "console.log('tsx ok', process.version)"` | `tsx ok v20...` (or newer) |
| Reaches stage from the terminal | `node -e "fetch('https://catalog.stage.internal.example/health').then(r => console.log('status', r.status)).catch(e => console.log('error', e.message))"` | `status 200` (any status code means the network works) |

Replace the URL with a real health or status endpoint of one of your stage services, one that returns no business data. If you get `error ... ENOTFOUND` or a timeout, the terminal can't reach stage (VPN off, or proxy settings missing in VS Code's terminal). Fix that before Phase 6, because the runner makes the same calls.

### 1.2 Hide secrets from Cline

Cline can read files and run commands, so make sure it can't read tokens or database URLs.

1. Create `.clineignore` in the root of **both** repos (`ecom-backend` and `ecom-debug-bot`) with:

   ```
   .env
   .env.*
   **/*.pem
   **/*.key
   ```
2. Keep **command approval on** (don't enable auto-approve for terminal commands). You'll see every command before it runs, so Cline can't, for example, run `cat .env.stage`.
3. Open the `ecom-backend` folder in VS Code (not the parent `~/work` folder), so the tooling repo's secret files stay outside the workspace.

**Verify:** ask Cline "Read .env.stage in ecom-debug-bot." It should say it can't access that file.

## Phase 2 — Agree what data may leave your machine

With a cloud AI tool, everything a tool call returns is sent to the vendor. Get this cleared once, before you connect any environment.

| Data | Leaves your machine? | Control |
| --- | --- | --- |
| Source code and `.knowledge/` files | Yes, when read | Usually already covered by the tool's approval |
| Traces, API and DB results from stage/qa | Yes, as command output Cline reads | Masked + truncated by the debug CLI (Phase 6.5, 7.1) |
| Secrets (tokens, DB URLs) | **No** | Stay in `.env.*`; never printed; hidden from Cline by .clineignore (Phase 1.2) |
| Production data | **No** | Not in `ALLOWED_ENVS` (Phase 6.5) |

1. **Ask your security team one question:** "May masked stage/qa responses (SKUs, prices, inventory, offer configs, no customer data) be sent to \[approved tool\] as tool results?" Keep the answer in writing.
2. **Extend the PII mask** in Phase 6.5 with any other field names your stage data uses for customer details (for example `customerId`, `loyaltyNumber`, `dob`).
3. **Keep production out.** Leave `prod` out of `ALLOWED_ENVS` unless security explicitly approves it.
4. **Disable training on your data** if your tool's org settings offer it (enterprise plans usually do this by default).

## Phase 3 — Create the tooling project

This repo holds the extractor, the bot's MCP server, the profiler and search.

1. **Create and initialise it:**

   ```bash
   mkdir -p ~/work/ecom-debug-bot && cd ~/work/ecom-debug-bot
   git init
   npm init -y
   npm pkg set type=module
   ```
2. **Install dependencies:**

   ```bash
   npm i ts-morph yaml zod dotenv axios fast-glob @modelcontextprotocol/sdk
   npm i -D typescript tsx @types/node
   ```

   | Package | Why |
   | --- | --- |
   | ts-morph | Reads your TypeScript code as a syntax tree |
   | yaml | Writes compact knowledge files |
   | zod | Validates tool inputs |
   | dotenv | Loads per-environment secrets |
   | axios | Calls downstream APIs |
   | fast-glob | Finds files |
   | @modelcontextprotocol/sdk | Optional: MCP gateway later (Phase 7.7) |
   | tsx | Runs `.ts` files directly |
3. **Create `tsconfig.json`:**

   ```json
   {
     "compilerOptions": {
       "target": "ES2022",
       "module": "NodeNext",
       "moduleResolution": "NodeNext",
       "strict": true,
       "esModuleInterop": true,
       "skipLibCheck": true,
       "outDir": "dist"
     },
     "include": ["src"]
   }
   ```
4. **Create the folders and ignore secrets:**

   ```bash
   mkdir -p src/extract src/mcp src/profile src/search config
   printf "node_modules\ndist\n.env*\n.lancedb\n" > .gitignore
   ```
5. **Point the tools at your backend** with a `.env` file in the tooling repo:

   ```
   ECOM_REPO=/Users/you/work/ecom-backend
   
   ```

**Verify:** `npx tsx -e "console.log('ok')"` prints `ok`.

## Phase 4 — Generate knowledge from your code

A script reads your backend's TypeScript (no LLM involved) and writes compact facts into `ecom-backend/.knowledge/generated/`. Then your approved AI tool writes a short summary per module from those facts.

### 4.1 Create the extractor

Create `src/extract/index.ts`:

```ts
import "dotenv/config";
import { Project, SyntaxKind, Node, SourceFile } from "ts-morph";
import { mkdirSync, writeFileSync } from "node:fs";
import { createHash } from "node:crypto";
import path from "node:path";
import YAML from "yaml";

const REPO = process.env.ECOM_REPO!;
const OUT = path.join(REPO, ".knowledge", "generated");
mkdirSync(OUT, { recursive: true });

const project = new Project({ tsConfigFilePath: path.join(REPO, "tsconfig.json") });
const files = project.getSourceFiles().filter(
  (f) => !/node_modules|\.(spec|test)\.ts$|\.d\.ts$/.test(f.getFilePath())
);

const rel = (p: string) => path.relative(REPO, p);
const HTTP = new Set(["get", "post", "put", "patch", "delete"]);
const NEST = new Set(["Get", "Post", "Put", "Patch", "Delete"]);

const routes: any[] = [];
const outbound: any[] = [];
const envVars: Record<string, Set<string>> = {};
const symbols: Record<string, any[]> = {};
const callGraph: Record<string, string[]> = {};
const manifest: Record<string, string> = {};

// Name of the function/method that contains a node
function owner(node: Node): string {
  for (const a of node.getAncestors()) {
    if (Node.isFunctionDeclaration(a) || Node.isMethodDeclaration(a)) {
      const cls = a.getFirstAncestorByKind(SyntaxKind.ClassDeclaration)?.getName();
      return (cls ? cls + "." : "") + (a.getName() ?? "anonymous");
    }
    if (Node.isVariableDeclaration(a)) return a.getName();
  }
  return "<module>";
}

function scanFile(sf: SourceFile) {
  const file = rel(sf.getFilePath());
  manifest[file] = createHash("sha1").update(sf.getFullText()).digest("hex").slice(0, 12);

  // 1) Express routes + outbound HTTP calls
  for (const call of sf.getDescendantsOfKind(SyntaxKind.CallExpression)) {
    const expr = call.getExpression();
    if (!Node.isPropertyAccessExpression(expr)) continue;
    const method = expr.getName();
    const target = expr.getExpression().getText();
    const [first] = call.getArguments();
    if (!HTTP.has(method)) continue;

    if (/^(app|router|\w+Router)$/.test(target) && first && Node.isStringLiteral(first)) {
      routes.push({ method: method.toUpperCase(), path: first.getLiteralValue(), file,
        handler: call.getArguments().at(-1)?.getText().slice(0, 80) });
    } else if (/axios|http|client|api/i.test(target)) {
      outbound.push({ caller: owner(call), via: target, method: method.toUpperCase(),
        url: first?.getText().slice(0, 150), file, line: call.getStartLineNumber() });
    }
  }

  // 2) NestJS routes (@Get('path') on methods)
  for (const m of sf.getDescendantsOfKind(SyntaxKind.MethodDeclaration)) {
    for (const d of m.getDecorators()) {
      if (NEST.has(d.getName())) {
        routes.push({ method: d.getName().toUpperCase(), path: d.getArguments()[0]?.getText() ?? "''",
          file, handler: owner(m.getBody() ?? m) });
      }
    }
  }

  // 3) Environment variables (process.env.X)
  for (const pa of sf.getDescendantsOfKind(SyntaxKind.PropertyAccessExpression)) {
    if (pa.getExpression().getText() === "process.env") {
      (envVars[pa.getName()] ??= new Set()).add(file);
    }
  }

  // 4) Exported symbols with signatures + JSDoc
  for (const [name, decls] of sf.getExportedDeclarations()) {
    for (const d of decls) {
      const entry: any = { name, kind: d.getKindName() };
      if (Node.isFunctionDeclaration(d)) {
        entry.sig = `(${d.getParameters().map((p) => p.getText()).join(", ")}): ${d.getReturnType().getText(d)}`;
        entry.doc = d.getJsDocs().map((j) => j.getDescription().trim()).join(" ") || undefined;
      }
      if (Node.isClassDeclaration(d)) entry.methods = d.getMethods().map((m) => m.getName());
      if (Node.isInterfaceDeclaration(d) || Node.isTypeAliasDeclaration(d)) entry.def = d.getText().slice(0, 400);
      (symbols[file] ??= []).push(entry);
    }
  }

  // 5) Call graph: function -> names it calls
  const fns = [...sf.getFunctions(), ...sf.getClasses().flatMap((c) => c.getMethods())];
  for (const fn of fns) {
    const key = `${file}#${owner(fn.getBody() ?? fn)}`;
    const callees = new Set(
      fn.getDescendantsOfKind(SyntaxKind.CallExpression).map((c) => c.getExpression().getText().split("(")[0].slice(0, 60))
    );
    callGraph[key] = [...callees];
  }
}

files.forEach(scanFile);

const env = Object.fromEntries(Object.entries(envVars).map(([k, v]) => [k, [...v]]));
writeFileSync(path.join(OUT, "routes.yaml"), YAML.stringify(routes));
writeFileSync(path.join(OUT, "downstream-calls.yaml"), YAML.stringify(outbound));
writeFileSync(path.join(OUT, "env-vars.yaml"), YAML.stringify(env));
writeFileSync(path.join(OUT, "symbols.yaml"), YAML.stringify(symbols));
writeFileSync(path.join(OUT, "call-graph.json"), JSON.stringify(callGraph));
writeFileSync(path.join(OUT, "manifest.json"), JSON.stringify(manifest, null, 1));
console.log(`files=${files.length} routes=${routes.length} outbound=${outbound.length} env=${Object.keys(env).length}`);
```

**Adjust for your stack:** if your HTTP client is a wrapper (for example `this.inventoryClient.get(...)`), the regex `/axios|http|client|api/i` already catches names containing "client" or "api"; add your wrapper's name if it differs. For `fetch(url)`, add a check for `expr.getText() === "fetch"`.

**Hapi routes:** Hapi declares routes as `server.route({ method, path, handler })` objects, which this extractor doesn't parse. You don't need it to: Phase 7.2 writes the real route table from `server.table()` into `generated/hapi-routes.yaml`. Keep this extractor for outbound calls, env vars, symbols and the call graph.

### 4.2 Run it

Add scripts to the tooling repo's `package.json`:

```bash
npm pkg set scripts.extract="tsx src/extract/index.ts"
npm run extract
```

**Verify:** the console prints non-zero counts, and `ecom-backend/.knowledge/generated/` contains six files. Open `downstream-calls.yaml` and check that your inventory, catalog and offer API calls appear. If a known call is missing, adjust the regex as above.

### 4.3 Add the module dependency graph

Run inside the backend repo:

```bash
cd ~/work/ecom-backend
npx madge --ts-config tsconfig.json --extensions ts --json src > .knowledge/generated/deps.json
npx madge --ts-config tsconfig.json --extensions ts --circular src   # bonus: lists circular imports
```

### 4.4 Write module summaries with your AI tool

Open `ecom-backend` in VS Code, open Cline in Act mode, and run this prompt once per module folder under `src/` (for example `offers`, `inventory`, `pricing`, `workers`). Save it as `.knowledge/prompts/module-summary.md` so the whole team uses the same one.

```markdown
Write .knowledge/modules/{MODULE}.md for the module in src/{MODULE}/.

Inputs (read these first, in this order):
1. .knowledge/generated/symbols.yaml - entries for files under src/{MODULE}/
2. .knowledge/generated/downstream-calls.yaml - entries for files under src/{MODULE}/
3. The source files themselves, only where the YAML isn't enough

Use exactly these sections:
# {MODULE}
## Purpose (2 sentences)
## Entry points (bullets: file#function -> one line)
## Business rules (bullets, each ending with its source file#function)
## Downstream dependencies (bullets: API or table + why it's called)
## Failure modes (bullets: what goes wrong and the reason code, if any)

Rules: only facts from the code; max 350 words; no code blocks; mark anything unclear as "UNCLEAR:".
At the very top, add: <!-- source_hash: {the value listed for this module in .knowledge/STALE.md} -->
```

Replace `{MODULE}` before sending. Before the first run, create the stale-summary script from Phase 10.1 and run npm run stale in the tooling repo: it lists every module with the hash its summary should carry. Most tools can do several modules in one run if you list them, but one at a time gives better summaries.

**Verify:** open `.knowledge/modules/offers.md`. Check every business rule against the code, fix anything wrong, and resolve every `UNCLEAR:` line. These files are reviewed by you, not trusted blindly, and committed with the code.

### 4.5 Map every flow automatically

This script reads your code (no AI) and, for **every Hapi route and every registered worker**, follows the call chain through all the functions it reaches, across files and interfaces. For each flow it records:

- **Gates:** every `if (...) return/throw/continue` and every `.filter/.find/.some/.every` callback, which are the places an item can be dropped, with file and line.
- **Downstream calls:** every HTTP call (method + URL template) and which function makes it.
- **Data:** every table or collection read or written.
- **Config:** every `process.env.X` and `config.get('x')` the flow depends on.
- **Cross-connections:** which workers write the tables a route reads (`_data-links.yaml`). This answers "the offer is missing because the publisher job didn't write it".

It writes one file per entry point into `ecom-backend/.knowledge/flows/`:

```
.knowledge/flows/
  INDEX.md                          # every entry point, size, downstream calls, tables
  GET_products_sku_offers.yaml      # summary (all gates, APIs, data, config) + step tree
  GET_products_sku_offers.mmd       # Mermaid diagram of the same flow
  WORKER_offer_publisher.yaml
  _data-links.yaml                  # table -> written_by workers / read_by routes
```

Create `src/extract/flows.ts` in the tooling repo:

```ts
import "dotenv/config";
import { Project, SyntaxKind, Node, Symbol as TsSymbol } from "ts-morph";
import { mkdirSync, writeFileSync } from "node:fs";
import path from "node:path";
import YAML from "yaml";

const REPO = process.env.ECOM_REPO!;
const OUT = path.join(REPO, ".knowledge", "flows");
const MAX_DEPTH = Number(process.env.FLOW_DEPTH ?? 8);
const SKIP = new RegExp(process.env.FLOW_SKIP ?? "(logger|logging|metrics|telemetry)", "i");
mkdirSync(OUT, { recursive: true });

const project = new Project({ tsConfigFilePath: path.join(REPO, "tsconfig.json") });
const files = project.getSourceFiles().filter((f) => !f.isInNodeModules() && !/\.(spec|test)\.ts$|\.d\.ts$/.test(f.getFilePath()));
const rel = (p: string) => path.relative(REPO, p);
const short = (s: string, n = 160) => s.replace(/\s+/g, " ").slice(0, n);
const at = (n: Node) => `${rel(n.getSourceFile().getFilePath())}:${n.getStartLineNumber()}`;
const local = (n: Node) => !n.getSourceFile().isInNodeModules() && !n.getSourceFile().isDeclarationFile();

const HTTP = new Set(["get", "post", "put", "patch", "delete", "head"]);
const CLIENT = /axios|http|client|api/i;                                  // adjust to your HTTP wrappers
const DB_RECEIVER = /prisma|knex|db|repo|repository|model|collection|pool|pg/i;
const DB_READ = /^(find\w*|count|aggregate|select)$/;
const DB_WRITE = /^(create\w*|insert\w*|update\w*|upsert|delete\w*|save|remove|destroy|bulkWrite)$/;
const IGNORE = /^(console|Math|JSON|Object|Array|Promise|String|Number|Date|logger|log)\b/;

// ---------- find the function behind a call (follows imports and interface implementations) ----------
function fnFrom(n?: Node): Node | undefined {
  for (let x = n; x; x = x.getParent()) {
    if (Node.isFunctionDeclaration(x) || Node.isMethodDeclaration(x) || Node.isArrowFunction(x) || Node.isFunctionExpression(x)) return x;
    if (Node.isVariableDeclaration(x) || Node.isPropertyAssignment(x) || Node.isPropertyDeclaration(x)) {
      const init = x.getInitializer();
      return init && (Node.isArrowFunction(init) || Node.isFunctionExpression(init)) ? init : undefined;
    }
    if (Node.isBlock(x) || Node.isSourceFile(x)) return undefined;
  }
}
function fromSymbol(sym?: TsSymbol): Node | undefined {
  if (sym?.isAlias()) sym = sym.getAliasedSymbol() ?? sym;
  for (const d of sym?.getDeclarations() ?? []) { const f = fnFrom(d); if (f && local(f)) return f; }
}
function targets(call: Node) {
  const e = (call as any).getExpression() as Node;
  const nameNode = Node.isPropertyAccessExpression(e) ? e.getNameNode() : e;
  let sym = nameNode.getSymbol();
  if (sym?.isAlias()) sym = sym.getAliasedSymbol() ?? sym;
  const fns: Node[] = [];
  for (const d of sym?.getDeclarations() ?? []) {
    if (!local(d)) continue;                                            // library call (Array.map, axios...)
    if (Node.isMethodSignature(d) || Node.isPropertySignature(d)) {     // interface method -> every implementation
      if (Node.isIdentifier(nameNode))
        for (const impl of nameNode.getImplementations()) { const f = fnFrom(impl.getNode()); if (f && local(f)) fns.push(f); }
    } else { const f = fnFrom(d); if (f) fns.push(f); }
  }
  return { fns, typed: !!sym };
}
function idOf(fn: Node) {
  const name = Node.isFunctionDeclaration(fn) || Node.isMethodDeclaration(fn) ? fn.getName()
    : (fn.getFirstAncestor((a) => Node.isVariableDeclaration(a) || Node.isPropertyAssignment(a) || Node.isPropertyDeclaration(a)) as any)?.getName();
  const owner = fn.getFirstAncestorByKind(SyntaxKind.ClassDeclaration)?.getName()
    ?? (Node.isMethodDeclaration(fn) ? fn.getFirstAncestorByKind(SyntaxKind.VariableDeclaration)?.getName() : undefined);
  return `${rel(fn.getSourceFile().getFilePath())}#${owner ? owner + "." : ""}${name ?? `anon@${fn.getStartLineNumber()}`}`;
}

// ---------- facts inside one function ----------
type Facts = { gates: string[]; http: any[]; db: any[]; config: string[]; calls: Node[]; unresolved: string[] };
const memo = new Map<string, Facts>();
function factsOf(fn: Node): Facts {
  const id = idOf(fn);
  if (memo.has(id)) return memo.get(id)!;
  const f: Facts = { gates: [], http: [], db: [], config: [], calls: [], unresolved: [] };
  memo.set(id, f);
  const body: Node = (fn as any).getBody?.() ?? fn;
  body.forEachDescendant((n) => {
    if (Node.isIfStatement(n)) {
      const then = n.getThenStatement();
      const exit = [SyntaxKind.ReturnStatement, SyntaxKind.ThrowStatement, SyntaxKind.ContinueStatement]
        .find((k) => then.isKind(k) || then.getFirstDescendantByKind(k));
      if (exit) f.gates.push(`${at(n)} if (${short(n.getExpression().getText())}) -> ${SyntaxKind[exit].replace("Statement", "").toLowerCase()}`);
    }
    if (Node.isPropertyAccessExpression(n) && n.getExpression().getText() === "process.env") f.config.push(`env.${n.getName()}`);
    if (!Node.isCallExpression(n)) return;
    const e = n.getExpression();
    const name = Node.isPropertyAccessExpression(e) ? e.getName() : e.getText();
    const recv = Node.isPropertyAccessExpression(e) ? e.getExpression().getText() : "";
    const [arg0] = n.getArguments();

    if (["filter", "find", "some", "every"].includes(name) && arg0 && (Node.isArrowFunction(arg0) || Node.isFunctionExpression(arg0)))
      f.gates.push(`${at(n)} ${name}(${short(arg0.getText())})`);
    else if (HTTP.has(name) && CLIENT.test(recv))
      f.http.push({ at: at(n), method: name.toUpperCase(), url: short(arg0?.getText() ?? "", 200), via: short(recv, 60) });
    else if (name === "fetch")
      f.http.push({ at: at(n), method: "FETCH", url: short(arg0?.getText() ?? "", 200) });
    else if (/^(query|raw)$/.test(name) && arg0 && (Node.isStringLiteral(arg0) || Node.isNoSubstitutionTemplateLiteral(arg0) || Node.isTemplateExpression(arg0))) {
      const sql = arg0.getText();
      const tables = [...sql.matchAll(/\b(?:from|join|into|update)\s+([\w."]+)/gi)].map((m) => m[1].replace(/"/g, ""));
      f.db.push({ at: at(n), op: /^\W*(select|with)\b/i.test(sql) ? "read" : "write", tables: [...new Set(tables)], sql: short(sql, 200) });
    } else if (DB_RECEIVER.test(recv) && (DB_READ.test(name) || DB_WRITE.test(name))) {
      const table = recv.match(/collection\(\s*['"`](\w+)/)?.[1] ?? recv.split(".").pop()!;
      f.db.push({ at: at(n), op: DB_READ.test(name) ? "read" : "write", tables: [table], call: short(`${recv}.${name}`, 80) });
    } else if (/^(get|has)$/.test(name) && /config/i.test(recv) && arg0 && Node.isStringLiteral(arg0))
      f.config.push(`config.${arg0.getLiteralValue()}`);
    else if (!IGNORE.test(e.getText())) {
      const { fns, typed } = targets(n);
      if (fns.length) f.calls.push(...fns.filter((x) => !SKIP.test(idOf(x))));
      else if (!typed) f.unresolved.push(`${at(n)} ${short(e.getText(), 80)}`);   // untyped/any: needs a human or Cline
    }
  });
  f.config = [...new Set(f.config)];
  return f;
}

// ---------- walk one entry point ----------
function walk(entry: Node) {
  const steps: any[] = [];
  const seen = new Set<string>();
  const visit = (fn: Node, depth: number, from?: string) => {
    const id = idOf(fn);
    if (seen.has(id) || depth > MAX_DEPTH) return;
    seen.add(id);
    const f = factsOf(fn);
    const step: any = { fn: id, depth };
    if (from) step.from = from;
    if (f.gates.length) step.gates = f.gates;
    if (f.http.length) step.http = f.http;
    if (f.db.length) step.db = f.db;
    if (f.config.length) step.config = f.config;
    if (f.unresolved.length) step.unresolved = f.unresolved;
    steps.push(step);
    for (const c of f.calls) visit(c, depth + 1, id);
  };
  visit(entry, 0);
  return steps;
}

// ---------- entry points: Hapi routes + WORKERS registry ----------
function valueFn(obj: Node, key: string): Node | undefined {
  if (!Node.isObjectLiteralExpression(obj)) return;
  const p = obj.getProperty(key);
  if (Node.isShorthandPropertyAssignment(p)) return fromSymbol(p.getValueSymbol());
  if (Node.isMethodDeclaration(p)) return p;
  if (!Node.isPropertyAssignment(p)) return;
  const v = p.getInitializer()!;
  if (Node.isArrowFunction(v) || Node.isFunctionExpression(v)) return v;
  return fromSymbol((Node.isPropertyAccessExpression(v) ? v.getNameNode() : v).getSymbol());
}
function literal(obj: Node, key: string) {
  const p = Node.isObjectLiteralExpression(obj) ? obj.getProperty(key) : undefined;
  const v = Node.isPropertyAssignment(p) ? p.getInitializer() : undefined;
  return v && (Node.isStringLiteral(v) || Node.isNoSubstitutionTemplateLiteral(v)) ? v.getLiteralValue() : undefined;
}
const entries: { name: string; fn: Node }[] = [];
for (const sf of files) {
  for (const obj of sf.getDescendantsOfKind(SyntaxKind.ObjectLiteralExpression)) {
    const route = literal(obj, "path");
    if (!route) continue;
    const opts = obj.getProperty("options") ?? obj.getProperty("config");
    const fn = valueFn(obj, "handler") ?? (Node.isPropertyAssignment(opts) ? valueFn(opts.getInitializer()!, "handler") : undefined);
    if (fn) entries.push({ name: `${(literal(obj, "method") ?? "GET").toUpperCase()} ${route}`, fn });
  }
  const workers = sf.getVariableDeclaration("WORKERS")?.getInitializer();
  if (workers && Node.isObjectLiteralExpression(workers))
    for (const pr of workers.getProperties()) {
      const key = (pr as any).getName?.() as string | undefined;
      const fn = key ? valueFn(workers, key) : undefined;
      if (fn) entries.push({ name: `WORKER ${key!.replace(/['"]/g, "")}`, fn });
    }
}

// ---------- outputs ----------
const slug = (s: string) => s.replace(/[^A-Za-z0-9]+/g, "_").replace(/^_|_$/g, "");
function mermaid(name: string, steps: any[]) {
  const ids = new Map<string, string>();
  const nid = (k: string) => { if (!ids.has(k)) ids.set(k, `n${ids.size}`); return ids.get(k)!; };
  const lab = (s: string) => s.replace(/["<>]/g, "'").slice(0, 60);
  const lines = ["flowchart TD", `  ${nid("entry")}["${lab(name)}"]`];
  for (const s of steps) {
    lines.push(`  ${nid(s.fn)}["${lab(s.fn.split("#")[1])}${s.gates ? ` (${s.gates.length} gates)` : ""}"]`, `  ${nid(s.from ?? "entry")} --> ${nid(s.fn)}`);
    for (const h of s.http ?? []) { const k = `http:${h.method} ${h.url}`; lines.push(`  ${nid(k)}(["${lab(`${h.method} ${h.url}`)}"])`, `  ${nid(s.fn)} -.-> ${nid(k)}`); }
    for (const d of s.db ?? []) for (const t of d.tables) { const k = `db:${t}`; lines.push(`  ${nid(k)}[("${lab(t)}")]`, `  ${nid(s.fn)} -. ${d.op} .-> ${nid(k)}`); }
  }
  return [...new Set(lines)].join("\n") + "\n";
}

const links: Record<string, { written_by: Set<string>; read_by: Set<string> }> = {};
const index = ["# Flow index (generated - do not edit)", "", "| Entry | Steps | Downstream calls | Tables | File |", "|---|---|---|---|---|"];
for (const e of entries) {
  const steps = walk(e.fn);
  const all = (k: string) => steps.flatMap((s) => (s[k] ?? []).map((x: any) => (typeof x === "string" ? `${x}  [${s.fn}]` : { ...x, fn: s.fn })));
  const db = all("db");
  for (const d of db) for (const t of d.tables) {
    const l = (links[t] ??= { written_by: new Set(), read_by: new Set() });
    (d.op === "read" ? l.read_by : l.written_by).add(e.name);
  }
  const flow = {
    entry: e.name, handler: idOf(e.fn),
    summary: { steps: steps.length, gates: all("gates"), downstream: all("http"), data: db,
               config: [...new Set(all("config"))], unresolved: all("unresolved") },
    steps,
  };
  writeFileSync(path.join(OUT, `${slug(e.name)}.yaml`), YAML.stringify(flow, { lineWidth: 0 }));
  writeFileSync(path.join(OUT, `${slug(e.name)}.mmd`), mermaid(e.name, steps));
  index.push(`| ${e.name} | ${steps.length} | ${flow.summary.downstream.length} | ${[...new Set(db.flatMap((d: any) => d.tables))].join(", ")} | ${slug(e.name)}.yaml |`);
}
writeFileSync(path.join(OUT, "_data-links.yaml"), YAML.stringify(Object.fromEntries(
  Object.entries(links).map(([t, l]) => [t, { written_by: [...l.written_by], read_by: [...l.read_by] }]))));
writeFileSync(path.join(OUT, "INDEX.md"), index.join("\n") + "\n");
console.log(`flows: ${entries.length} entry points -> .knowledge/flows/`);
```

Run it:

```bash
cd ~/work/ecom-debug-bot
npm pkg set scripts.flows="tsx src/extract/flows.ts"
npm run flows
```

It takes from a few seconds to a couple of minutes, depending on repo size. A shortened example of what it produces for the offers route:

```yaml
entry: GET /products/{sku}/offers
handler: src/offers/handler.ts#getOffersHandler
summary:
  steps: 14
  gates:
    - "src/offers/rules/offerActive.ts:9 if (offer.status !== 'ACTIVE') -> return  [src/offers/rules/offerActive.ts#offerActiveRule.evaluate]"
    - "src/inventory/availability.ts:22 if (qty < minQty) -> return  [src/inventory/availability.ts#isAvailable]"
    - "src/offers/stacking.ts:31 filter((o) => o.stackable || o.priority < winner.priority)  [src/offers/stacking.ts#resolveStack]"
  downstream:
    - { method: GET, url: "`/products/${sku}`", via: ctx.clients.catalog, fn: src/catalog/product.ts#getProduct }
    - { method: GET, url: "`/inventory/${sku}`", via: this.inventoryClient, fn: src/inventory/availability.ts#getAvailable }
  data:
    - { op: read, tables: [product_offers], fn: src/offers/eligibility.ts#getCandidateOffers }
  config: [env.OFFERS_MIN_QTY, config.offers.channels]
  unresolved: []
steps: [...]
```

And `_data-links.yaml` shows the cross-connection:

```yaml
product_offers:
  written_by: [WORKER offer-publisher]
  read_by: [GET /products/{sku}/offers, GET /cart/{id}]
```

**Verify:** open `.knowledge/flows/INDEX.md`. Every route and worker you know should be listed. Open the offers flow and check that the gates you know about (ecomFlag, inventory, stackability) appear. Paste a `.mmd` file into any Mermaid viewer (VS Code has extensions for it) to see the flow as a diagram.

**What static analysis can't see**, and how to handle it:

| Pattern in your code | What happens | Fix |
| --- | --- | --- |
| Loops over an array of rule objects (`for (const r of RULES) r.evaluate()`) | Followed through the interface to every implementation | Nothing to do, if the rules share a typed interface |
| `any`-typed services, string-based DI containers | Listed under `unresolved` with file:line | Cline resolves them in 4.6, or add types |
| HTTP wrappers with other names (`this.svc.call(...)`) | Not recognised as downstream calls | Add the wrapper's name to `CLIENT` / the method to `HTTP` |
| Rules stored as data (offer config rows in a DB) | The code path is found; the rule values aren't | 4.6 adds a `check` that reads that data |
| Very large flows | Capped at `FLOW_DEPTH` (default 8) | Raise it, or add noisy helper folders to `FLOW_SKIP` |

### 4.6 Let Cline turn each flow into a rules file with checks

The flow file says *where* the code can drop an item. Cline now reads the code at those lines and the data knowledge, and writes a rules file that says, in business terms, what each gate means, where its data comes from, and **the exact command to check it**. When someone later says "offer not coming", Cline just runs those checks.

Save this prompt as `ecom-backend/.knowledge/prompts/flow-to-rules.md`, then in Cline (Act mode) ask: "Run .knowledge/prompts/flow-to-rules.md for GET\_products\_sku\_offers."

```markdown
Turn a generated flow into a debug rules file. FLOW = the name I give you (e.g. GET_products_sku_offers).

Read, in this order:
1. .knowledge/flows/{FLOW}.yaml - the `summary` first; open source only at the file:line it cites
2. .knowledge/flows/_data-links.yaml - which workers write the tables this flow reads
3. .knowledge/envs/environments.yaml and .knowledge/generated/downstream-calls.yaml - base URLs per service
4. .knowledge/data/data-dictionary.yaml and .knowledge/data/job-outputs.generated.yaml - field meanings, typical values

Write .knowledge/rules/{FLOW}.yaml in exactly this shape:
version: 1
entry: <entry from the flow file>
flow_file: flows/{FLOW}.yaml
inputs: [request values a user must give, e.g. sku, storeId, offerId, channel]
evaluation_order: [rule ids, in the order the code applies them]
rules:
  - id: snake_case_name
    meaning: one line in business language
    check_in_code: the gate exactly as in the flow file, with file:line
    data_from: "service + path with {placeholders}" or "table.column"
    check: ONE command that fetches that data for the inputs, using only
      public GET:  curl -s "<stage base url><path with {placeholders}>" | head -c 5000
      database:    npm --prefix ../ecom-debug-bot run -s debug -- db {env} "<SELECT ... WHERE x = '{sku}'>"
    fail_when: the value(s) that make this gate drop the item
    fail_reason: REASON_CODE from the code, if one exists
    upstream: worker that produces this data (from _data-links), or none

Also:
- Resolve every entry under summary.unresolved by reading the code; add any rule it hides.
- Include config values the gates depend on (summary.config) as rules of their own if they change the outcome.
- Never invent URLs, columns or reason codes. Mark anything you can't confirm as UNCLEAR:.
- At the top add: # flow_steps: {summary.steps from the flow file}
```

Run it once per important flow: start with the offers route and the workers in its `_data-links`. Most teams need 5–15 rules files, not one per route.

**Verify:** open `.knowledge/rules/GET_products_sku_offers.yaml`. Every gate from the flow summary should map to a rule; every rule should have a `check` you can run yourself with a real SKU; and `UNCLEAR:` lines need your answer. This file replaces the hand-written one in 5.3: review it the same way.

**When the code changes:** `npm run flows` regenerates the flow files (nightly, Phase 10). If `git diff .knowledge/flows/<flow>.yaml` shows new gates or calls, rerun the prompt for that flow.

## Phase 5 — Write the hand-curated knowledge

Generated files tell an AI *what exists*; these files tell it *how the business works*. Spend real time here, because they are what make answers correct. All go in `ecom-backend/.knowledge/`.

### 5.1 `INDEX.md` — the only file always loaded (keep under \~60 lines)

```markdown
# Knowledge index (read this first, then load only what you need)

## System in one paragraph
Node/TS backend serving catalog, pricing, offers, inventory and cart for web + app.

## Where to look
| Question about | Read |
|---|---|
| Why an offer is/isn't applied | rules/offer-eligibility.yaml, modules/offers.md |
| Inventory / availability | modules/inventory.md |
| Which API / URL per env | envs/environments.yaml, generated/downstream-calls.yaml |
| DB tables and fields | data/data-dictionary.yaml |
| What a data job produces | data/job-outputs.yaml |
| Terms (ecomFlag, stackable...) | glossary.yaml |
| Full flow of an endpoint or worker | flows/INDEX.md -> flows/<entry>.yaml, rules/<entry>.yaml |
| Which job writes the data a flow reads (tables, cache keys, topics) | flows/_data-links.yaml |
| Prod issue: which logs to search, in order | runbooks/<flow>.md, logs/opensearch.yaml |
| Where items are dropped without a log line | logs/gaps.md |
| HTTP endpoints | generated/routes.yaml |
| Who calls what | generated/call-graph.json (large: search, don't load whole) |

## Debugging tools available
debug CLI (see AGENTS.md): request, worker, routes, workers, api, db, search, job-traces, envdiff, cache
```

### 5.2 `AGENTS.md` at the repo root

Many AI coding tools read this file automatically.

```markdown
# AGENTS.md
Before answering questions about this codebase, read .knowledge/INDEX.md and load only the files it points to.
Prefer YAML knowledge files over reading source. Open source files only at the file#function a rule cites.
Never modify .knowledge/generated/* by hand; run `npm run extract` in ecom-debug-bot.
```

### 5.3 `rules/offer-eligibility.yaml` — the most important file

Start from the draft Cline wrote in 4.6 and correct it. You need one entry per rule your offer engine applies, in the order it applies them. The example below shows the shape. Open your offer code and copy each check's real condition.

```yaml
version: 1
entry_point: src/offers/eligibility.ts#evaluateOffer
evaluation_order: [offer_active, ecom_flag, inventory, channel, stackability, customer_segment]
rules:
  - id: offer_active
    check: offer.status == ACTIVE and now between offer.startDate and offer.endDate (UTC)
    source: src/offers/rules/offerActive.ts#isActive
    data_from: offers-api GET /offers/{offerId}
    fail_reason: OFFER_INACTIVE
    common_causes: [end date passed in stage, timezone mismatch, offer not published to stage]
  - id: ecom_flag
    check: product.ecomFlag == 'Y'
    source: src/offers/rules/ecomFlag.ts#isEcomEnabled
    data_from: catalog-api GET /products/{sku}
    fail_reason: OFFER_ECOM_FLAG_OFF
  - id: inventory
    check: availableQty >= config.offers.minQty (default 1) at the requested store
    source: src/inventory/availability.ts#getAvailable
    data_from: inventory-api GET /inventory/{sku}?storeId={storeId}
    fail_reason: OFFER_NO_INVENTORY
  - id: stackability
    check: no other active offer on the SKU with stackable=false and higher priority
    source: src/offers/stacking.ts#resolveStack
    data_from: offers-api GET /offers?sku={sku}&status=ACTIVE
    fail_reason: OFFER_NOT_STACKABLE
```

### 5.4 `envs/environments.yaml` — URLs only, never secrets

```yaml
stage:
  catalog_api: https://catalog.stage.internal.example
  inventory_api: https://inventory.stage.internal.example
  offers_api: https://offers.stage.internal.example
  auth: { type: bearer, token_env: STAGE_API_TOKEN }
  db: { url_env: STAGE_DB_URL_READONLY }
qa:
  catalog_api: https://catalog.qa.internal.example
  inventory_api: https://inventory.qa.internal.example
  offers_api: https://offers.qa.internal.example
  auth: { type: bearer, token_env: QA_API_TOKEN }
  db: { url_env: QA_DB_URL_READONLY }
```

Copy the same file to `ecom-debug-bot/config/environments.yaml` (Phase 6.3 extends it for the runner). The `*_env` fields name variables held in `.env.stage` / `.env.qa`, so tokens never appear in knowledge or prompts.

### 5.5 `glossary.yaml`

```yaml
ecomFlag: Catalog attribute; 'Y' means the product may be sold online. Set by merchandising feed.
stackable: Offer attribute; false means it cannot combine with another offer on the same SKU.
channel: WEB | APP | STORE; offers can target a subset.
```

**Verify:** paste `INDEX.md` into your AI tool's chat and ask "Which files would you read to explain why an offer is missing?" It should name the rules file and the offers module.

## Phase 6 — Integrate once: the debug runner (Hapi + cron workers)

The runner boots your **real** Hapi server or any cron worker in a child process, configured for one environment (stage, qa…). It records every business function call (arguments + return), every downstream API response and every DB query, blocks all writes, and returns a compact trace. No per-feature code: a new domain is one folder name in a regex.

For the offer question, the bot calls the runner with `GET /products/4455/offers?storeId=12` and reads back a trace like this:

```
GET /products/4455/offers?storeId=12 → 200 []
├ offers/eligibility#getCandidateOffers(["4455"]) → ["OFF-123","OFF-099"]
│ ├ HTTP GET https://offers.stage…/offers?sku=4455 → 200 [{id:OFF-123,stackable:false…}]
├ catalog/product#getProduct(["4455"]) → {ecomFlag:"Y",…}
├ inventory/availability#isAvailable(["4455","12"]) → false
│ ├ HTTP GET https://inventory.stage…/inventory/4455?storeId=12 → 200 {availableQty:0}
├ offers/stacking#resolveStack([["OFF-123","OFF-099"]]) → ["OFF-099"]
└ offers/filter#applyEligibility(…) → []
```

The backend needs two small, one-time refactors (6.1, 6.2). Everything else lives in the tooling repo.

### 6.1 Backend: build the server without starting it

Hapi's `server.inject()` runs a request through all your plugins, auth, validation and handlers without opening a port. To use it, the server must be creatable without `start()`. Many Hapi projects already have this split for `@hapi/lab` tests; if yours does, reuse it.

`src/server.ts`:

```ts
import Hapi from "@hapi/hapi";
import { registerPlugins } from "./plugins";
import { registerRoutes } from "./routes";

export async function createServer() {
  const server = Hapi.server({ port: Number(process.env.PORT ?? 3000), host: "0.0.0.0" });
  await registerPlugins(server);
  registerRoutes(server);
  await server.initialize();          // runs onPreStart etc.; ready for inject(), no port opened
  return server;
}
```

`src/index.ts` (production entry, behaviour unchanged):

```ts
import { createServer } from "./server";
createServer().then((s) => s.start()).then(() => console.log("server started"));
```

If a plugin starts background work on initialize (queue consumers, schedulers, cache warmers), skip it in debug mode:

```ts
if (process.env.DEBUG_RUNNER !== "true") startQueueConsumer();
```

### 6.2 Backend: a worker registry (separate "what" from "when")

Cron decides *when* a worker runs; the registry exposes *what* it does, so the runner can call any worker on demand, for one SKU, without waiting for the schedule.

`src/workers/registry.ts`:

```ts
import { syncInventory } from "./inventorySync";
import { publishOffers } from "./offerPublisher";
import { buildProductFeed } from "./productFeed";

export type WorkerArgs = { skus?: string[]; limit?: number; dryRun?: boolean };

export const WORKERS: Record<string, (args: WorkerArgs) => Promise<unknown>> = {
  "inventory-sync": syncInventory,
  "offer-publisher": publishOffers,
  "product-feed": buildProductFeed,
};
```

Your cron file keeps the schedule and calls the registry (shown with node-cron; agenda, bull or node-schedule work the same way):

```ts
import cron from "node-cron";
import { WORKERS } from "./registry";
cron.schedule("*/15 * * * *", () => WORKERS["inventory-sync"]({}));
cron.schedule("0 * * * *", () => WORKERS["offer-publisher"]({}));
```

Give each worker an optional `skus` / `limit` filter, so a debug run processes one product instead of the whole catalog. This is the only change inside worker code.

**Build the backend with tsc.** The runner loads the compiled `dist/` output (`npm run build`), because tsc-compiled CommonJS exports can be wrapped at load time. Check that `tsconfig.json` has `"module": "commonjs"` and `"sourceMap": true`.

### 6.3 Describe each environment for the runner

Replace `ecom-debug-bot/config/environments.yaml` with:

```yaml
stage:
  backend_env_file: .env.backend.stage     # env vars your Hapi app reads at boot
  services:                                # used by the call_api tool
    catalog: https://catalog.stage.internal.example
    inventory: https://inventory.stage.internal.example
    offers: https://offers.stage.internal.example
  auth: { token_env: STAGE_API_TOKEN }
  db_readonly_env: STAGE_DB_URL_READONLY
  allow_post_paths: ["/offers/search"]     # downstream POSTs that only read
qa:
  backend_env_file: .env.backend.qa
  services: { catalog: https://catalog.qa.internal.example }
  auth: { token_env: QA_API_TOKEN }
  db_readonly_env: QA_DB_URL_READONLY
```

`.env.backend.stage` = exactly the variables your deployment sets for stage (`NODE_ENV`, downstream URLs, DB URL, Redis…), with two changes: **the DB user is read-only** and **API tokens are read-only**. If you use the `config` npm package, `NODE_ENV=stage` plus `NODE_CONFIG_DIR=/Users/you/work/ecom-backend/config` is usually enough.

`.env.stage` holds the tooling's own secrets (`STAGE_API_TOKEN`, `STAGE_DB_URL_READONLY`). Both files are git-ignored by the `.env*` rule.

### 6.4 Install the runner's dependencies (tooling repo)

```bash
cd ~/work/ecom-debug-bot
npm i require-in-the-middle @opentelemetry/api @opentelemetry/sdk-node \
      @opentelemetry/sdk-trace-base @opentelemetry/auto-instrumentations-node pg
npm i -D @types/pg
mkdir -p src/runner
```

### 6.5 Shared config + masking

`src/runner/config.ts`:

```ts
import { readFileSync } from "node:fs";
import path from "node:path";
import YAML from "yaml";
import dotenv from "dotenv";

export const ROOT = path.resolve(import.meta.dirname, "../..");
export const ALLOWED_ENVS = ["dev", "stage", "qa"] as const;      // no prod until you trust it
export type Env = (typeof ALLOWED_ENVS)[number];

const all = YAML.parse(readFileSync(path.join(ROOT, "config/environments.yaml"), "utf8"));
export function cfg(env: Env) {
  if (!ALLOWED_ENVS.includes(env) || !all[env]) throw new Error(`Env ${env} not allowed or not configured`);
  return all[env];
}
export const secrets = (env: Env) => dotenv.parse(readFileSync(path.join(ROOT, `.env.${env}`)));
```

`src/runner/mask.ts`:

```ts
const PII = /email|phone|firstName|lastName|address|customerName|card|password|token/i;
export function mask(v: unknown): unknown {
  if (Array.isArray(v)) return v.map(mask);
  if (v && typeof v === "object")
    return Object.fromEntries(Object.entries(v).map(([k, x]) => [k, PII.test(k) ? "***" : mask(x)]));
  return v;
}
export const short = (v: unknown, n = 400) => {
  try { return JSON.stringify(mask(v))?.slice(0, n) ?? "undefined"; } catch { return "[unserializable]"; }
};
```

### 6.6 The instrumentation (the "integrate once" core)

`src/runner/instrument.ts` must load before any backend code. It does four things: starts tracing into memory, wraps business functions, captures and guards axios calls, and guards Postgres writes.

```ts
import { NodeSDK } from "@opentelemetry/sdk-node";
import { InMemorySpanExporter, SimpleSpanProcessor } from "@opentelemetry/sdk-trace-base";
import { getNodeAutoInstrumentations } from "@opentelemetry/auto-instrumentations-node";
import { trace } from "@opentelemetry/api";
import { Hook } from "require-in-the-middle";
import { short } from "./mask.js";

// 1) Tracing into memory (DB, Redis, Hapi spans come from auto-instrumentation)
export const exporter = new InMemorySpanExporter();
const sdk = new NodeSDK({
  serviceName: "debug-runner",
  spanProcessors: [new SimpleSpanProcessor(exporter)],
  instrumentations: [getNodeAutoInstrumentations({
    "@opentelemetry/instrumentation-fs": { enabled: false },
    "@opentelemetry/instrumentation-http": { enabled: false },   // axios is captured below, with bodies
  })],
});
sdk.start();
export const shutdown = () => sdk.shutdown();
export const tracer = trace.getTracer("biz");
export const blocked: string[] = [];

// 2) Wrap every exported function in the watched folders of dist/
const BUILD = process.env.BUILD_DIR ?? "dist";
const WATCH = new RegExp(`/${BUILD}/(${process.env.WATCH ?? "offers|pricing|inventory|catalog|cart|promotions|workers|services"})/`);

new Hook(null, { internals: true }, (exports: any, name: string) => {
  const file = name.replace(/\\/g, "/");
  if (!WATCH.test(file) || !exports || typeof exports !== "object") return exports;
  for (const key of Object.keys(exports)) {
    const fn = exports[key];
    if (typeof fn !== "function" || /^[A-Z]/.test(key)) continue;          // skip classes
    const label = `${file.split(`/${BUILD}/`)[1].replace(/\.js$/, "")}#${key}`;
    const wrapped = function (this: unknown, ...args: unknown[]) {
      return tracer.startActiveSpan(label, (span) => {
        span.setAttribute("biz", true);
        span.setAttribute("args", short(args));
        const done = (r: unknown) => { span.setAttribute("return", short(r)); span.end(); return r; };
        const failed = (e: any) => { span.setAttribute("error", String(e?.message ?? e)); span.end(); throw e; };
        try {
          const r: any = fn.apply(this, args);
          return r && typeof r.then === "function" ? r.then(done, failed) : done(r);
        } catch (e) { return failed(e); }
      });
    };
    try { exports[key] = wrapped; } catch { /* non-writable export: skip */ }
  }
  return exports;
});

// 3) axios: record every downstream response; block writes but keep the flow running
new Hook(["axios"], (axios: any) => {
  const allowPost: string[] = JSON.parse(process.env.ALLOW_POST_PATHS ?? "[]");
  const attach = (inst: any) => {
    inst.interceptors.request.use((c: any) => {
      const m = String(c.method ?? "get").toUpperCase();
      const url = `${c.baseURL ?? ""}${c.url ?? ""}`;
      if (!["GET", "HEAD"].includes(m) && !allowPost.some((p) => url.includes(p))) {
        blocked.push(`HTTP ${m} ${url} ${short(c.data, 300)}`);
        c.adapter = async () => ({ data: { debugRunner: "write blocked" }, status: 200, statusText: "BLOCKED", headers: {}, config: c });
      }
      return c;
    });
    const record = (c: any, status: unknown, body: unknown) =>
      trace.getActiveSpan()?.addEvent("downstream", {
        method: String(c?.method ?? "get").toUpperCase(), url: `${c?.baseURL ?? ""}${c?.url ?? ""}`,
        status: String(status), body: short(body, 600) });
    inst.interceptors.response.use(
      (r: any) => { record(r.config, r.status, r.data); return r; },
      (e: any) => { record(e.config, e.response?.status ?? "ERR", e.response?.data ?? e.message); throw e; });
  };
  attach(axios);
  const create = axios.create;
  axios.create = function (...a: any[]) { const inst = create.apply(this, a); attach(inst); return inst; };
  return axios;
});

// 4) Postgres: let reads through, record and skip writes
new Hook(["pg"], (pg: any) => {
  for (const C of [pg.Client, pg.Pool]) {
    const query = C.prototype.query;
    C.prototype.query = function (text: any, ...rest: any[]) {
      const sql = typeof text === "string" ? text : text?.text ?? "";
      if (!/^\s*(select|show|explain)\b/i.test(sql) && !/^\s*with\b(?![\s\S]*\b(insert|update|delete)\b)/i.test(sql)) {
        blocked.push(`SQL ${sql.replace(/\s+/g, " ").slice(0, 300)}`);
        const fake = { rows: [], rowCount: 0, command: "BLOCKED" };
        const cb = rest.find((r) => typeof r === "function");
        if (cb) return void cb(null, fake);
        return Promise.resolve(fake);
      }
      return query.call(this, text, ...rest);
    };
  }
  return pg;
});
```

Notes:

- Calls **between functions in the same file** don't pass through `exports`, so they show as one step. If a critical decision is buried inside a large function, extract it into its own exported function (see 6.9).
- Using `fetch` instead of axios? Re-enable `instrumentation-http` and `instrumentation-undici` (URLs and status, no bodies). Using MongoDB? Add a hook on `mongodb` that wraps `Collection.prototype` write methods (`insertOne`, `updateOne`, `deleteMany`…) the same way as `pg`.
- These guards keep the flow running. The read-only DB user and read-only tokens from 6.3 are the real safety net; keep both.

### 6.7 The child process: runs one job

`src/runner/child.ts`:

```ts
import { exporter, shutdown, blocked, tracer } from "./instrument.js";   // MUST be the first import
import { createRequire } from "node:module";
import { writeFileSync } from "node:fs";
import path from "node:path";
import { compress } from "./compress.js";
import { short } from "./mask.js";

const job = JSON.parse(process.argv[2]);
const req = createRequire(import.meta.url);
const load = (p: string) => req(path.join(process.cwd(), process.env.BUILD_DIR ?? "dist", p));

async function run(): Promise<unknown> {
  switch (job.kind) {
    case "request": {
      const server = await load("server.js").createServer();
      const res = await server.inject({ method: job.method ?? "GET", url: job.url, headers: job.headers, payload: job.payload });
      await server.stop();
      return { status: res.statusCode, body: res.result ?? res.payload };
    }
    case "worker": {
      const { WORKERS } = load("workers/registry.js");
      if (!WORKERS[job.name]) throw new Error(`Unknown worker ${job.name}. Known: ${Object.keys(WORKERS).join(", ")}`);
      return WORKERS[job.name]({ ...job.args, dryRun: true });
    }
    case "routes": {
      const server = await load("server.js").createServer();
      const routes = server.table().map((r: any) => ({ method: r.method.toUpperCase(), path: r.path,
        description: r.settings.description, tags: r.settings.tags }));
      await server.stop();
      return routes;
    }
    case "workers":
      return Object.keys(load("workers/registry.js").WORKERS);
  }
  throw new Error(`Unknown job kind ${job.kind}`);
}

let result: unknown, error: string | undefined;
try {
  result = await tracer.startActiveSpan("job", async (span) => { try { return await run(); } finally { span.end(); } });
} catch (e: any) { error = String(e?.stack ?? e).slice(0, 2000); }
await new Promise((r) => setTimeout(r, 300));        // let late async spans finish

const listing = job.kind === "routes" || job.kind === "workers";
writeFileSync(job.out, JSON.stringify({
  result: listing ? result : short(result, 3000),
  error,
  trace: listing ? undefined : compress(exporter.getFinishedSpans()),
  blocked_writes: blocked,
}));
await shutdown();
process.exit(0);
```

The result goes to a file, not stdout, because your Hapi app's own logs also print to stdout.

### 6.8 Trace compression and the parent launcher

`src/runner/compress.ts` turns hundreds of spans into a short tree (typically 1–3k tokens):

```ts
import type { ReadableSpan } from "@opentelemetry/sdk-trace-base";

const sid = (s: ReadableSpan) => s.spanContext().spanId;
const pid = (s: any): string | undefined => s.parentSpanContext?.spanId ?? s.parentSpanId;
const t = (s: ReadableSpan) => s.startTime[0] * 1e9 + s.startTime[1];

function label(s: any): string | null {
  const a = s.attributes;
  if (a.biz) return `${s.name}(${a.args}) → ${a.error ? "THROW " + a.error : a.return}`;
  const stmt = a["db.query.text"] ?? a["db.statement"];
  if (stmt) return `DB ${String(stmt).replace(/\s+/g, " ").slice(0, 200)}`;
  return null;                                   // Hapi internals, Redis pings, etc. are folded away
}

export function compress(spans: ReadableSpan[], maxLines = 150): string {
  const ids = new Set(spans.map(sid));
  const kids = new Map<string, ReadableSpan[]>();
  for (const s of spans) { const p = pid(s); if (p && ids.has(p)) kids.set(p, [...(kids.get(p) ?? []), s]); }
  const lines: string[] = [];
  const pad = (d: number) => "│ ".repeat(d) + "├ ";

  const walk = (s: any, depth: number) => {
    const l = label(s);
    const d = l ? depth + 1 : depth;
    if (l) lines.push(pad(depth) + l);
    for (const e of s.events ?? []) {
      if (e.name !== "downstream") continue;
      const x = e.attributes;
      lines.push(pad(d) + `HTTP ${x.method} ${x.url} → ${x.status} ${x.body}`);
    }
    const children = (kids.get(sid(s)) ?? []).sort((a, b) => t(a) - t(b));
    for (let i = 0; i < children.length; ) {
      let j = i;
      while (j + 1 < children.length && children[j + 1].name === children[i].name) j++;
      if (j - i >= 3) { walk(children[i], d); lines.push(pad(d) + `… ${children[i].name} ×${j - i} more`); }
      else for (let k = i; k <= j; k++) walk(children[k], d);
      i = j + 1;
    }
  };
  spans.filter((s) => !pid(s) || !ids.has(pid(s)!)).sort((a, b) => t(a) - t(b)).forEach((r) => walk(r, 0));
  return lines.length > maxLines
    ? lines.slice(0, maxLines).join("\n") + `\n… ${lines.length - maxLines} more lines truncated`
    : lines.join("\n");
}
```

`src/runner/runner.ts` starts one child per job, with the backend repo as working directory and the chosen environment's variables:

```ts
import { spawn } from "node:child_process";
import { mkdtempSync, readFileSync } from "node:fs";
import os from "node:os";
import path from "node:path";
import dotenv from "dotenv";
import { ROOT, cfg, type Env } from "./config.js";

export async function runJob(env: Env, job: Record<string, unknown>, timeoutMs = 120_000) {
  const c = cfg(env);
  const backendEnv = dotenv.parse(readFileSync(path.join(ROOT, c.backend_env_file)));
  const out = path.join(mkdtempSync(path.join(os.tmpdir(), "dbg-")), "out.json");
  const child = spawn(path.join(ROOT, "node_modules/.bin/tsx"), [path.join(ROOT, "src/runner/child.ts"), JSON.stringify({ ...job, out })], {
    cwd: process.env.ECOM_REPO,
    env: { ...process.env, ...backendEnv, DEBUG_RUNNER: "true", ALLOW_POST_PATHS: JSON.stringify(c.allow_post_paths ?? []) },
    stdio: ["ignore", "ignore", "pipe"],
  });
  let stderr = "";
  child.stderr!.on("data", (d) => { stderr = (stderr + d).slice(-4000); });
  await new Promise((resolve, reject) => {
    const timer = setTimeout(() => { child.kill("SIGKILL"); reject(new Error("runner timed out")); }, timeoutMs);
    child.on("exit", (code) => { clearTimeout(timer); code === 0 ? resolve(null) : reject(new Error(`runner exit ${code}: ${stderr.slice(-1500)}`)); });
  });
  return JSON.parse(readFileSync(out, "utf8"));
}
```

And a small CLI for testing, `src/runner/cli.ts`:

```ts
import "dotenv/config";
import { runJob } from "./runner.js";
const [env, kind, a, b] = process.argv.slice(2);
const job = kind === "request" ? { kind, method: "GET", url: a }
          : kind === "worker" ? { kind, name: a, args: JSON.parse(b ?? "{}") }
          : { kind };
const r = await runJob(env as any, job);
console.log(r.trace ?? ""); console.log("RESULT:", r.result); if (r.error) console.log("ERROR:", r.error);
if (r.blocked_writes?.length) console.log("BLOCKED WRITES:\n" + r.blocked_writes.join("\n"));
```

### 6.9 Verify

```bash
cd ~/work/ecom-backend && npm run build
cd ~/work/ecom-debug-bot
npm pkg set scripts.run-debug="tsx src/runner/cli.ts"
npm run run-debug -- stage routes                                  # every Hapi route, from server.table()
npm run run-debug -- stage workers                                 # every registered worker
npm run run-debug -- stage request "/products/4455/offers?storeId=12"
npm run run-debug -- stage worker offer-publisher '{"skus":["4455"]}'
```

You should see a trace tree like the one at the top of this phase, and for the worker a `BLOCKED WRITES` list showing exactly what it *would* have written. If the tree has few business lines, widen the `WATCH` folder list (environment variable `WATCH="offers|pricing|…"`) to match your `src/` layout.

**When the trace isn't enough:** if one big function makes the whole decision internally, you'll only see its input and output. Fix those gradually: extract the decision into a small exported function that returns a reason (for example `{ eligible: false, reason: "OFFER_NOT_STACKABLE", blockedBy: "OFF-099" }`). The runner picks it up automatically.

## Phase 7 — The debug command Cline runs

One read-only command, `debug`, gives Cline everything it needs for live questions. Cline runs it in the VS Code terminal (you approve each run), reads the output, and explains it. All safety rules live inside the command: allowed environments, read-only calls, PII masking, output size limits and secrets that are never printed.

| Subcommand | What it does | Typical question |
| --- | --- | --- |
| `request <env> <url>` | Runs a real Hapi request through the runner; prints response + trace | "Why is offer X missing for SKU Y in stage?" |
| `worker <env> <name> --skus a,b` | Runs a cron worker in dry-run mode; prints trace + blocked writes | "Why didn't the feed job publish SKU Y?" |
| `routes <env>` / `workers <env>` | Lists Hapi routes / registered workers | "Which endpoint returns offers?" |
| `api <env> <service> <path> --query k=v` | One GET to a downstream service | "What does inventory say right now?" |
| `db <env> "<SELECT ...>"` | One read-only SELECT, max 200 rows | "What's stored for SKU Y?" |
| `search "<words>"` | Keyword search over code + knowledge (Phase 9) | "Where do we handle BOGO?" |
| `job-traces <sku>` | Recent job traces from Jaeger (Phase 8) | "How did last night's job classify SKU Y?" |

Cline reads code and `.knowledge/` files directly with its own file tools; it doesn't need a command for that.

### 7.1 Create the debug CLI

In the tooling repo:

```bash
cd ~/work/ecom-debug-bot
mkdir -p src/cli
npm pkg set scripts.debug="tsx src/cli/debug.ts"
```

Create `src/cli/debug.ts`:

```ts
import "dotenv/config";
import { readFileSync } from "node:fs";
import path from "node:path";
import axios from "axios";
import pg from "pg";
import YAML from "yaml";
import { runJob } from "../runner/runner.js";
import { cfg, secrets, ALLOWED_ENVS, ROOT, type Env } from "../runner/config.js";
import { mask } from "../runner/mask.js";

const MAX = 12_000;                                   // keep output small for the AI
const KNOWLEDGE = path.join(process.env.ECOM_REPO!, ".knowledge");

const print = (data: unknown) => {
  const text = typeof data === "string" ? data : JSON.stringify(mask(data), null, 1);
  console.log(text.length > MAX ? text.slice(0, MAX) + `\n... truncated (${text.length - MAX} more chars)` : text);
};
const traced = (r: any) => print([
  r.error ? `ERROR: ${r.error}` : `RESULT: ${r.result}`,
  `TRACE:\n${r.trace}`,
  r.blocked_writes?.length ? `BLOCKED WRITES (would have written):\n${r.blocked_writes.join("\n")}` : "",
].join("\n\n"));

// tiny argument parser: positional args + --flag value
const pos: string[] = [];
const flags: Record<string, string> = {};
const argv = process.argv.slice(2);
for (let i = 0; i < argv.length; i++) {
  if (argv[i].startsWith("--")) flags[argv[i].slice(2)] = argv[++i] ?? "";
  else pos.push(argv[i]);
}
const [cmd, ...args] = pos;
const env = (e?: string): Env => {
  if (!e || !(ALLOWED_ENVS as readonly string[]).includes(e)) throw new Error(`env must be one of: ${ALLOWED_ENVS.join(", ")}`);
  return e as Env;
};

const USAGE = `debug <command>
  request <env> <url> [--method GET] [--payload '<json>']
  worker <env> <name> [--skus a,b] [--limit n]
  routes <env> | workers <env>
  api <env> <service> <path> [--query k=v,k2=v2]
  db <env> "<SELECT ...>"
  search "<words>" [--limit 5]
  job-traces <sku>
envs: ${ALLOWED_ENVS.join(", ")}`;

async function main() {
  switch (cmd) {
    case "request": {
      const [e, url] = args;
      return traced(await runJob(env(e), { kind: "request", url, method: flags.method ?? "GET",
        payload: flags.payload ? JSON.parse(flags.payload) : undefined }));
    }
    case "worker": {
      const [e, name] = args;
      return traced(await runJob(env(e), { kind: "worker", name,
        args: { skus: flags.skus?.split(","), limit: flags.limit ? Number(flags.limit) : undefined } }, 300_000));
    }
    case "routes":
    case "workers":
      return print((await runJob(env(args[0]), { kind: cmd })).result);

    case "api": {
      const [e, service, p] = args;
      const c = cfg(env(e));
      const base = c.services?.[service];
      if (!base) throw new Error(`Unknown service. Known: ${Object.keys(c.services ?? {}).join(", ")}`);
      const token = secrets(env(e))[c.auth?.token_env];
      const query = flags.query ? Object.fromEntries(flags.query.split(",").map((kv) => kv.split("="))) : undefined;
      const r = await axios.get(base + p, { params: query, timeout: 10_000,
        headers: token ? { Authorization: `Bearer ${token}` } : {} });     // GET only, by design
      return print({ status: r.status, data: r.data });
    }

    case "db": {
      const [e, sql = ""] = args;
      const clean = sql.trim().replace(/;\s*$/, "");
      if (!/^(select|with)\b/i.test(clean) || clean.includes(";") ||
          /\b(insert|update|delete|drop|alter|truncate|grant|create|copy)\b/i.test(clean))
        throw new Error("Only a single SELECT statement is allowed");
      const client = new pg.Client({ connectionString: secrets(env(e))[cfg(env(e)).db_readonly_env] });
      try {
        await client.connect();
        await client.query("SET statement_timeout = 10000; SET default_transaction_read_only = on;");
        const r = await client.query(`SELECT * FROM (${clean}) q LIMIT 200`);
        return print({ rowCount: r.rowCount, rows: r.rows });
      } finally { await client.end().catch(() => {}); }
    }

    case "search": {
      const { default: MiniSearch } = await import("minisearch");          // loaded only when used (Phase 9)
      const { SEARCH_OPTIONS } = await import("../search/options.js");
      const ms = MiniSearch.loadJSON(readFileSync(path.join(ROOT, ".search-index.json"), "utf8"), SEARCH_OPTIONS);
      let syn: Record<string, string[]> = {};
      try { syn = YAML.parse(readFileSync(path.join(KNOWLEDGE, "search-synonyms.yaml"), "utf8")) ?? {}; } catch {}
      const q = args.join(" ");
      const expanded = [q, ...q.toLowerCase().split(/\s+/).flatMap((w) => syn[w] ?? [])].join(" ");
      const hits = ms.search(expanded).slice(0, Number(flags.limit ?? 5));
      return print(hits.map((h: any) => ({ id: h.id, score: Math.round(h.score), snippet: String(h.text).slice(0, 600) })));
    }

    case "job-traces": {
      const tags = encodeURIComponent(JSON.stringify({ sku: args[0] }));
      const res = await fetch(`http://localhost:16686/api/traces?service=${flags.service ?? "ecom-jobs"}&tags=${tags}&limit=5`);
      const { data } = await res.json();
      return print(data.flatMap((t: any) => t.spans.map((s: any) => ({
        trace: t.traceID, op: s.operationName, start: new Date(s.startTime / 1000).toISOString(),
        tags: Object.fromEntries(s.tags.map((x: any) => [x.key, x.value])) }))).slice(0, 50));
    }

    default:
      console.log(USAGE);
  }
}

main().catch((e) => {
  console.log(`ERROR: ${e?.response?.status ? `HTTP ${e.response.status}` : e?.message ?? e}`);
  process.exitCode = 1;
});
```

The command prints only masked, truncated results. Tokens and DB URLs are read from `.env.*` inside the process and never printed, and the `.clineignore` from Phase 1.2 stops Cline reading those files directly.

### 7.2 Save routes and workers as knowledge

The real route table is better than anything parsed from source. Create `src/runner/catalog.ts`:

```ts
import "dotenv/config";
import { writeFileSync, mkdirSync } from "node:fs";
import path from "node:path";
import YAML from "yaml";
import { runJob } from "./runner.js";

const dir = path.join(process.env.ECOM_REPO!, ".knowledge/generated");
mkdirSync(dir, { recursive: true });
writeFileSync(path.join(dir, "hapi-routes.yaml"), YAML.stringify((await runJob("stage", { kind: "routes" })).result));
writeFileSync(path.join(dir, "workers.yaml"), YAML.stringify((await runJob("stage", { kind: "workers" })).result));
console.log("route + worker catalog written");
```

```bash
npm pkg set scripts.catalog="tsx src/runner/catalog.ts"
npm run catalog
```

Add each worker's cron schedule to `.knowledge/generated/workers.yaml` by hand once, so Cline knows when each one runs.

### 7.3 Test the command yourself first

From the `ecom-backend` folder (the same place Cline's terminal starts):

```bash
npm --prefix ../ecom-debug-bot run -s debug -- routes stage
npm --prefix ../ecom-debug-bot run -s debug -- request stage "/products/4455/offers?storeId=12"
npm --prefix ../ecom-debug-bot run -s debug -- worker stage offer-publisher --skus 4455
npm --prefix ../ecom-debug-bot run -s debug -- api stage inventory /inventory/4455 --query storeId=12
npm --prefix ../ecom-debug-bot run -s debug -- db stage "select sku, ecom_flag from products where sku = '4455'"
npm --prefix ../ecom-debug-bot run -s debug -- search "bogo"
```

`-s` keeps npm's own banner out of the output, so Cline reads only the result.

**Verify:** `request` prints `RESULT`, a `TRACE` tree and, for workers, `BLOCKED WRITES`; no output contains a token or an unmasked email or phone number. Fix boot errors (missing env vars in `.env.backend.stage`, DB or Redis connection) here, before involving Cline. A stage reproduction usually takes 3–10 seconds, mostly server boot.

### 7.4 How Cline should run it

- **Keep approval on for every command.** You see each `debug` call before it runs, and you can reject anything that isn't the `debug` command.
- **Use Act mode** for debugging questions.
- **Long workers:** `worker` can take minutes. Ask Cline to pass `--skus` with one SKU, or `--limit 1`.
- If Cline's terminal output gets cut off, ask it to rerun the command with a narrower question (one SKU, one store). The CLI already caps output at 12,000 characters.

### 7.5 Give Cline its instructions

Replace `ecom-backend/AGENTS.md` (from Phase 5.2) with:

```markdown
# AGENTS.md
You debug our eCommerce backend (Hapi API + cron workers). Environments: dev, stage, qa.

Knowledge: start with .knowledge/INDEX.md and load only the files it points to.
Prefer YAML knowledge over source; open source only at the file:line a rule or flow cites.
Never edit .knowledge/generated/* or .knowledge/flows/* by hand.

Live data - allowed commands only:
- curl for PUBLIC GET endpoints with no auth: curl -s "<url>" | head -c 5000
- npm --prefix ../ecom-debug-bot run -s debug -- <subcommand> ...
  (request, worker, routes, workers, api, db, search, job-traces, envdiff, cache; no args = usage)
Never send cookies, tokens or auth headers. Never use POST/PUT/PATCH/DELETE. Never read or print .env files.

For "X is missing / wrong" questions, give the COMPLETE picture:
1. Find the entry point in .knowledge/flows/INDEX.md (or run `debug routes <env>`).
2. Read .knowledge/rules/<flow>.yaml. If it doesn't exist, read flows/<flow>.yaml `summary` instead.
   Ask for any `inputs` the user didn't give (env, sku, storeId, offerId...).
3. Run EVERY rule's `check` with the user's inputs - do not stop at the first failure.
4. For each rule with an `upstream` worker, check whether that worker processed the item:
   `debug job-traces <sku>`, or `debug worker <env> <name> --skus <sku>`.
5. If the runner is built, run `debug request <env> <url>` to confirm the real decision.
6. Answer with:
   Verdict (1 line)
   Table: rule | value found | pass/fail | code (file:line) | upstream
   All contributing causes -> Fix / next step (who owns it: data, config, job or code).
Quote values from command output; never guess data. If a command errors, report it.
Do not modify code while debugging unless asked.
```

Then create `ecom-backend/.clinerules/ecom-debug.md` containing one line, so Cline always loads it:

```markdown
Follow the instructions in AGENTS.md at the repository root.
```

### 7.6 Verify — your target scenario

In Cline (Act mode), ask: "Offer OFF-123 is not showing for SKU 4455 in stage, store 12. Why?"

Cline should:

1. Read `.knowledge/INDEX.md` and the offer rules file.
2. Ask to run `debug routes stage` if it doesn't know the offers endpoint (approve it).
3. Ask to run `debug request stage "/products/4455/offers?storeId=12"` (approve it).
4. Point to the exact functions where OFF-123 dropped out (for example no inventory at store 12, OFF-099 winning stacking), quoting values from the trace, with fix suggestions.

Follow up with "Is the offer-publisher job the cause?" and it should ask to run `debug worker stage offer-publisher --skus 4455`.

### 7.7 Later (optional): MCP

If your company enables MCP in Cline later, the same functions can be exposed as MCP tools with `@modelcontextprotocol/sdk`: each subcommand above becomes one tool. Nothing in the runner, knowledge or search changes. Until then, the terminal command gives the same results.

## Phase 8 — Observe your data jobs

Three pieces: **traces** show what each job run did step by step, **reason-coded logs** explain why each record was classified or skipped, and a **profiler** records what the output data looks like.

### 8.1 Run Jaeger locally (trace viewer)

```bash
docker run -d --name jaeger --restart always \
  -e COLLECTOR_OTLP_ENABLED=true \
  -p 127.0.0.1:16686:16686 -p 127.0.0.1:4318:4318 \
  jaegertracing/all-in-one:latest
```

UI: `http://localhost:16686`. Port 4318 receives traces.

### 8.2 Add OpenTelemetry to the backend's jobs

```bash
cd ~/work/ecom-backend
npm i @opentelemetry/api @opentelemetry/sdk-node @opentelemetry/auto-instrumentations-node \
      @opentelemetry/exporter-trace-otlp-http pino
```

Create `src/observability/tracing.ts`:

```ts
import { NodeSDK } from "@opentelemetry/sdk-node";
import { OTLPTraceExporter } from "@opentelemetry/exporter-trace-otlp-http";
import { getNodeAutoInstrumentations } from "@opentelemetry/auto-instrumentations-node";

if (process.env.OTEL_ENABLED === "true") {
  const sdk = new NodeSDK({
    serviceName: process.env.OTEL_SERVICE_NAME ?? "ecom-jobs",
    traceExporter: new OTLPTraceExporter({ url: "http://localhost:4318/v1/traces" }),
    instrumentations: [getNodeAutoInstrumentations()],   // auto-traces HTTP, pg, mongodb, redis...
  });
  sdk.start();
  process.on("SIGTERM", () => sdk.shutdown());
}
```

Make it the **first import** in each job's entry file: `import "../observability/tracing";`

### 8.3 Add spans and reason codes inside a job

Create `src/observability/logger.ts`:

```ts
import pino from "pino";
export const logger = pino({ level: process.env.LOG_LEVEL ?? "info" });
```

Then wrap each stage and each classification decision. Example for a product-feed job:

```ts
import { trace } from "@opentelemetry/api";
import { randomUUID } from "node:crypto";
import { logger } from "../observability/logger";
const tracer = trace.getTracer("product-feed-job");

export async function runProductFeedJob() {
  const runId = randomUUID();
  const log = logger.child({ job: "product-feed", runId });
  await tracer.startActiveSpan("product-feed.run", async (run) => {
    run.setAttribute("job.runId", runId);
    const rows = await tracer.startActiveSpan("extract", async (s) => { const r = await loadFeed(); s.setAttribute("records.in", r.length); s.end(); return r; });

    for (const row of rows) {
      await tracer.startActiveSpan("classify", async (s) => {
        const result = classify(row);                       // your existing logic
        s.setAttributes({ sku: row.sku, "classification.result": result.category, "classification.reason": result.reason });
        log.info({ sku: row.sku, category: result.category, reason: result.reason }, "classified");
        if (result.category === "SKIPPED") log.warn({ sku: row.sku, reason: result.reason }, "skipped");
        s.end();
      });
    }
    run.end();
  });
}
```

Make `classify` return a `reason` string such as `SKIPPED_NO_PRICE` or `CLASSIFIED_AS_BUNDLE`, the same pattern as the offer rules. Write these codes into `.knowledge/data/job-outputs.yaml` (below) with a one-line meaning each.

Run the job with tracing and logs to a file:

```bash
OTEL_ENABLED=true npx tsx src/jobs/productFeed.ts | tee logs/product-feed.jsonl
```

**Verify:** in Jaeger, choose service `ecom-jobs` → Find Traces. You should see one `product-feed.run` trace with `extract`, `classify` and auto-traced HTTP/DB child spans. Search by tag `sku=4455` to follow one product through the job.

Per-record spans can be large. For jobs over \~50k records, only create `classify` spans for skipped/unusual records and rely on logs for the rest.

### 8.4 Profile job outputs with DuckDB

In the tooling repo:

```bash
cd ~/work/ecom-debug-bot
npm i @duckdb/node-api
npm pkg set scripts.profile="tsx src/profile/index.ts"
```

Describe each job's outputs in `config/jobs.yaml`:

```yaml
- job: product-feed
  outputs:
    - name: classified_products
      kind: file
      source: /data/feeds/out/classified/*.json       # json, csv or parquet
    - name: product_offers
      kind: postgres
      source: public.product_offers
      db_env: STAGE_DB_URL_READONLY
```

Create `src/profile/index.ts`:

```ts
import "dotenv/config";
import { DuckDBInstance } from "@duckdb/node-api";
import { readFileSync, writeFileSync, mkdirSync } from "node:fs";
import path from "node:path";
import dotenv from "dotenv";
import YAML from "yaml";

const jobs = YAML.parse(readFileSync("config/jobs.yaml", "utf8"));
const secrets = dotenv.parse(readFileSync(".env.stage"));
const db = await DuckDBInstance.create(":memory:");
const conn = await db.connect();
const q = async (sql: string) => (await conn.runAndReadAll(sql)).getRowObjectsJson();

function fromClause(o: any) {
  if (o.kind === "file") {
    const ext = path.extname(o.source);
    const fn = ext === ".csv" ? "read_csv_auto" : ext === ".parquet" ? "read_parquet" : "read_json_auto";
    return `${fn}('${o.source}')`;
  }
  return `pg.${o.source}`;
}

const report: any[] = [];
for (const job of jobs) {
  for (const o of job.outputs) {
    if (o.kind === "postgres") {
      await q("INSTALL postgres; LOAD postgres;");
      await q("DETACH DATABASE IF EXISTS pg;");
      await q(`ATTACH '${secrets[o.db_env]}' AS pg (TYPE postgres, READ_ONLY);`);
    }
    const src = `(SELECT * FROM ${fromClause(o)} USING SAMPLE 20000 ROWS)`;
    const summary = await q(`SUMMARIZE SELECT * FROM ${src}`);
    const columns: any[] = [];
    for (const c of summary as any[]) {
      const col: any = { name: c.column_name, type: c.column_type, null_pct: c.null_percentage, distinct_approx: c.approx_unique, min: c.min, max: c.max };
      if (Number(c.approx_unique) <= 20) {     // looks like a category/enum -> show its values
        col.top_values = await q(`SELECT "${c.column_name}" AS v, count(*) AS n FROM ${src} GROUP BY 1 ORDER BY 2 DESC LIMIT 10`);
      }
      columns.push(col);
    }
    report.push({ job: job.job, output: o.name, source: o.source, profiled_at: new Date().toISOString(), columns });
    console.log("profiled", job.job, o.name);
  }
}
const outDir = path.join(process.env.ECOM_REPO!, ".knowledge/data");
mkdirSync(outDir, { recursive: true });
writeFileSync(path.join(outDir, "job-outputs.generated.yaml"), YAML.stringify(report));
```

```bash
npm run profile
```

`INSTALL postgres` downloads a DuckDB extension once. On a fully offline machine, run it once while connected, or copy the extension file from another machine.

**Verify:** `.knowledge/data/job-outputs.generated.yaml` lists every column with type, null %, distinct count, and the value distribution of category-like columns (for example how many products landed in each classification). Keep a hand-written `job-outputs.yaml` next to it with the meaning of each reason code and category.

### 8.5 Optional: Metabase for visual exploration

```bash
docker run -d --name metabase -p 127.0.0.1:3001:3000 -e MB_ANON_TRACKING_ENABLED=false metabase/metabase
```

Open `http://localhost:3001`, connect the read-only stage database, and build quick charts of classification counts per run. This is for you to understand the logic before documenting it.

## Phase 9 — Code and knowledge search (no model needed)

The bot needs to find code for questions like "where do we handle BOGO?". Instead of embeddings (which need a model), this phase builds a keyword index with **MiniSearch**: a small JavaScript library that ranks results by relevance, tolerates typos, splits `camelCase` names, and expands your own synonyms. The index is one JSON file; there's no server to run.

### 9.1 Install

```bash
cd ~/work/ecom-debug-bot
npm i minisearch
npm pkg set scripts.index="tsx src/search/index.ts"
printf ".search-index.json\n" >> .gitignore
```

### 9.2 Shared search settings

Create `src/search/options.ts` (the indexer and the search tool must use identical options):

```ts
// Split identifiers so "resolveStack" also matches "resolve" and "stack"
const tokenize = (text: string) =>
  text.split(/[^A-Za-z0-9]+/).filter(Boolean)
    .flatMap((t) => [t, ...t.split(/(?<=[a-z0-9])(?=[A-Z])/)]);

export const SEARCH_OPTIONS = {
  idField: "id",
  fields: ["symbol", "file", "text"],
  storeFields: ["file", "symbol", "text"],
  tokenize,
  processTerm: (t: string) => (t.length < 2 ? null : t.toLowerCase()),
  searchOptions: { boost: { symbol: 3, file: 1.5 }, fuzzy: 0.2, prefix: true, combineWith: "OR" },
};
```

### 9.3 Add synonyms for business words

Keyword search only matches words that appear in the code, so teach it your vocabulary. Create `ecom-backend/.knowledge/search-synonyms.yaml`:

```yaml
bogo: [buy one get one, buyOneGetOne, bxgy]
stock: [inventory, availableQty, availability]
discount: [offer, promotion, promo, markdown]
stackable: [stacking, combinable, resolveStack]
ecom: [ecomFlag, online, sellable]
```

Add a line whenever a search misses something it should find.

### 9.4 Build the index

Create `src/search/index.ts` (one entry per function, one per knowledge section):

```ts
import "dotenv/config";
import MiniSearch from "minisearch";
import { Project } from "ts-morph";
import fg from "fast-glob";
import { readFileSync, writeFileSync } from "node:fs";
import path from "node:path";
import { SEARCH_OPTIONS } from "./options.js";

const REPO = process.env.ECOM_REPO!;
const docs: { id: string; file: string; symbol: string; text: string }[] = [];
const seen = new Map<string, number>();
const add = (file: string, symbol: string, text: string) => {
  const base = `${file}#${symbol}`;
  const n = (seen.get(base) ?? 0) + 1;
  seen.set(base, n);
  docs.push({ id: n === 1 ? base : `${base}~${n}`, file, symbol, text: text.slice(0, 4000) });
};

// Code: one entry per function / method
const project = new Project({ tsConfigFilePath: path.join(REPO, "tsconfig.json") });
for (const sf of project.getSourceFiles()) {
  const file = path.relative(REPO, sf.getFilePath());
  if (/node_modules|\.d\.ts$|\.(spec|test)\.ts$/.test(file)) continue;
  for (const fn of [...sf.getFunctions(), ...sf.getClasses().flatMap((c) => c.getMethods())]) {
    add(file, fn.getName() ?? "anonymous", fn.getText());
  }
}

// Knowledge: one entry per markdown section / yaml file
for (const f of await fg(["**/*.md", "**/*.yaml"], { cwd: path.join(REPO, ".knowledge"), ignore: ["generated/**", "prompts/**"] })) {
  const text = readFileSync(path.join(REPO, ".knowledge", f), "utf8");
  text.split(/\n(?=## )/).forEach((part) => add(`.knowledge/${f}`, part.split("\n")[0].slice(0, 80), part));
}

const ms = new MiniSearch(SEARCH_OPTIONS);
ms.addAll(docs);
writeFileSync(path.resolve(".search-index.json"), JSON.stringify(ms));
console.error(`indexed ${docs.length} entries`);
```

```bash
npm run index
```

This takes seconds, even for a large repo.

### 9.5 Optional: a shared index in Redis or CockroachDB

The JSON index works per laptop. If your team wants one shared, always-current index, store the same entries (`id`, `file`, `symbol`, `text`) in a database with full-text search and point the `search` subcommand of the debug CLI at it:

- **Redis** with its query engine: create an index over hashes with `FT.CREATE ... SCHEMA symbol TEXT WEIGHT 3 file TEXT text TEXT`, then query with `FT.SEARCH`.
- **CockroachDB**: a table with a generated `tsvector` column plus an inverted index, queried with `@@ plainto_tsquery(...)`.

Both give keyword search, not meaning-based search, so keep the synonyms file either way. Neither replaces the AI tool; they only store and find text.

## Phase 10 — Keep the knowledge fresh automatically

Scripts keep the generated facts, search index and data profiles current. Module summaries are the only part that needs the AI tool, so a script lists which ones are stale and you refresh just those.

| What | When | Who |
| --- | --- | --- |
| `extract` (facts) + `check-rules` | every commit (pre-commit hook) | script, seconds |
| flows + `stale` + `index` + `profile` + `catalog` + logs | nightly, 02:00 | script, minutes |
| Refresh module summaries listed in `STALE.md` | when the list isn't empty | you + AI tool (prompt from 4.4) |
| Review hand-written rules | when `check-rules` fails or offer code changes | you |

### 10.1 List modules whose summaries are stale

Create `src/extract/stale.ts` in the tooling repo. It compares each summary's `source_hash` comment (written by the 4.4 prompt) with the current hashes from `manifest.json`:

```ts
import "dotenv/config";
import { readFileSync, writeFileSync, existsSync } from "node:fs";
import { createHash } from "node:crypto";
import path from "node:path";

const K = path.join(process.env.ECOM_REPO!, ".knowledge");
const manifest: Record<string, string> = JSON.parse(readFileSync(path.join(K, "generated/manifest.json"), "utf8"));

// one hash per module = hash of its files' hashes
const modules: Record<string, string[]> = {};
for (const [file, h] of Object.entries(manifest)) (modules[file.split("/")[1] ?? "root"] ??= []).push(file + h);

const stale: string[] = [];
for (const [mod, parts] of Object.entries(modules)) {
  const current = createHash("sha1").update(parts.sort().join()).digest("hex").slice(0, 12);
  const md = path.join(K, "modules", `${mod}.md`);
  const recorded = existsSync(md) ? readFileSync(md, "utf8").match(/source_hash:\s*(\w+)/)?.[1] : undefined;
  if (recorded !== current) stale.push(`- ${mod} (source_hash should be ${current})`);
}
writeFileSync(path.join(K, "STALE.md"),
  stale.length ? `# Module summaries to refresh\nRun .knowledge/prompts/module-summary.md for:\n${stale.join("\n")}\n` : "# All module summaries are current\n");
console.log(`${stale.length} stale module summaries`);
```

The 4.4 prompt already tells the AI tool to copy that value into each summary: `At the very top, add: <!-- source_hash: {the value listed for this module in .knowledge/STALE.md} -->`. To refresh, tell your AI tool: "Refresh every module listed in .knowledge/STALE.md using .knowledge/prompts/module-summary.md", then review the diffs.

### 10.2 Check that hand-written rules still point at real code

Create `src/extract/check-rules.ts`:

```ts
import "dotenv/config";
import { readFileSync, existsSync } from "node:fs";
import path from "node:path";
import YAML from "yaml";

const REPO = process.env.ECOM_REPO!;
const rules = YAML.parse(readFileSync(path.join(REPO, ".knowledge/rules/offer-eligibility.yaml"), "utf8")).rules;
let bad = 0;
for (const r of rules) {
  const [file, fn] = r.source.split("#");
  const p = path.join(REPO, file);
  if (!existsSync(p) || (fn && !readFileSync(p, "utf8").includes(fn))) {
    console.error(`STALE RULE ${r.id}: ${r.source} not found`); bad++;
  }
}
process.exit(bad ? 1 : 0);
```

Add the scripts:

```bash
cd ~/work/ecom-debug-bot
npm pkg set scripts.check-rules="tsx src/extract/check-rules.ts"
npm pkg set scripts.stale="tsx src/extract/stale.ts"
npm pkg set scripts.nightly="npm run extract && npm run flows && npm run stale && npm run index && npm run profile && npm run catalog && npm run logs"
```

### 10.3 Pre-commit hook in the backend (Husky)

```bash
cd ~/work/ecom-backend
npm i -D husky
npx husky init
cat > .husky/pre-commit <<'EOF'
npm --prefix ../ecom-debug-bot run extract
npm --prefix ../ecom-debug-bot run check-rules
git add .knowledge/generated
EOF
```

This assumes both repos sit side by side in `~/work`. Teammates without the tooling repo can skip the hook with `git commit --no-verify`, or you can move these two scripts into the backend repo later.

### 10.4 Nightly job on your machine

```bash
crontab -e
# add this line (runs at 02:00 every day):
0 2 * * * cd ~/work/ecom-debug-bot && /usr/bin/env bash -lc 'npm run nightly' >> ~/work/ecom-debug-bot/nightly.log 2>&1
```

On macOS, give your terminal app Full Disk Access if cron can't read the repos.

### 10.5 CI guard (optional)

In your backend CI, add a step that fails a pull request when offer code changes but the rules file doesn't:

```bash
if git diff --name-only origin/main...HEAD | grep -q '^src/offers/' && \
   ! git diff --name-only origin/main...HEAD | grep -q '^.knowledge/rules/'; then
  echo "Offer logic changed: please review .knowledge/rules/offer-eligibility.yaml"; exit 1
fi
```

**Verify:** rename a function referenced in the rules file and try to commit; the hook should print `STALE RULE` and block the commit. Then change any file under `src/offers/`, run `npm run stale`, and `offers` should appear in `.knowledge/STALE.md`.

## Phase 11 — Logs and OpenSearch (prod debugging)

You can't reproduce requests in prod, but you can read their logs. This phase teaches the bot which log lines each flow writes, where items can be dropped **without** a log line, and how to find a request in OpenSearch Dashboards. It produces ready-to-paste queries and importable dashboards. Stage 1 needs no new access: you run the queries yourself. Stage 2 (11.7) lets Cline query logs itself once approved.

| Output | Where | Used for |
| --- | --- | --- |
| Logger profile | `.knowledge/logs/logger.yaml` | How your Winston wrapper is called and which fields it writes |
| Log catalog | `.knowledge/logs/catalog.yaml` + `logs` in every flow file | Which log lines each flow step writes |
| Silent gates | `[SILENT]` marks in flows + `.knowledge/logs/gaps.md` | Places an item is dropped with no log line |
| Field mapping | `.knowledge/logs/opensearch.yaml` | Index patterns and field names in OpenSearch |
| Prod runbooks | `.knowledge/runbooks/<flow>.md` | Step-by-step DQL/PPL queries for a prod issue |
| Dashboards | `.knowledge/logs/dashboards/<flow>.ndjson` | Import into OpenSearch Dashboards |

### 11.1 Learn the logger wrapper

Your corporate wrapper around Winston decides how log calls look in code and which fields end up in OpenSearch. Ask Cline to read it (usually in `node_modules/@<corp>/<logger>/`) and one or two places where your code creates and uses the logger, then write `.knowledge/logs/logger.yaml`:

```yaml
library: "@corp/logger (wraps winston)"
call_patterns:
  receivers: [logger, log, this.logger, this.log, req.logger]   # how code refers to the logger
  methods: [error, warn, info, http, verbose, debug]
  message_arg: 0          # position of the message argument
  meta_arg: 1             # position of the metadata object (sku, offerId, reason...)
output_fields:            # how a log line looks in OpenSearch
  timestamp: "@timestamp"
  level: level
  message: message
  service: service.name
  correlation_id: traceId  # request/run id the wrapper adds (header, AsyncLocalStorage...)
  meta_prefix: "meta."     # where metadata keys land, e.g. meta.sku
  version: app.version     # app version or git SHA, if the wrapper adds it
```

If the wrapper adds no correlation id or app version, note it: those are the two most valuable fields to add for prod debugging (see 11.6).

### 11.2 Add log lines and silent gates to the flow maps

Extend `src/extract/flows.ts` (Phase 4.5). Add `readFileSync, existsSync` to its `node:fs` import, then add near the top:

```ts
const LOGCFG = existsSync(path.join(REPO, ".knowledge/logs/logger.yaml"))
  ? YAML.parse(readFileSync(path.join(REPO, ".knowledge/logs/logger.yaml"), "utf8")) : {};
const esc = (s: string) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
const LOG_RECEIVERS: string[] = LOGCFG.call_patterns?.receivers ?? ["logger", "log", "this.logger", "this.log"];
const LOG_METHODS = new Set<string>(LOGCFG.call_patterns?.methods ?? ["error", "warn", "info", "debug"]);
const LOG_RECV = new RegExp(`^(${LOG_RECEIVERS.map(esc).join("|")})$`);
const LOG_IN_TEXT = new RegExp(`(${LOG_RECEIVERS.map(esc).join("|")})\\.(${[...LOG_METHODS].join("|")})\\(`);

// Returns a log record if this call is a logger call, else undefined
function logCall(n: Node) {
  if (!Node.isCallExpression(n)) return;
  const e = n.getExpression();
  if (!Node.isPropertyAccessExpression(e) || !LOG_RECV.test(e.getExpression().getText()) || !LOG_METHODS.has(e.getName())) return;
  const args = n.getArguments();
  const m = args[LOGCFG.call_patterns?.message_arg ?? 0];
  const meta = args[LOGCFG.call_patterns?.meta_arg ?? 1];
  const message = !m ? ""
    : Node.isStringLiteral(m) || Node.isNoSubstitutionTemplateLiteral(m) ? m.getLiteralValue()
    : Node.isTemplateExpression(m) ? m.getHead().getLiteralText() + "*"
    : `<${short(m.getText(), 60)}>`;
  const fields = meta && Node.isObjectLiteralExpression(meta)
    ? meta.getProperties().map((p: any) => p.getName?.()).filter(Boolean) : [];
  return { at: at(n), level: e.getName(), message, fields };
}
```

In `factsOf`:

1. Add `logs: any[]` to the `Facts` type and `logs: []` to the initial object.
2. Replace the `IfStatement` gate line with one that marks silent gates:

   ```ts
   if (exit) {
     const kind = SyntaxKind[exit].replace("Statement", "").toLowerCase();
     const mark = LOG_IN_TEXT.test(then.getText()) ? "" : kind === "throw" ? "  [throws]" : "  [SILENT]";
     f.gates.push(`${at(n)} if (${short(n.getExpression().getText())}) -> ${kind}${mark}`);
   }
   ```
3. Make the `filter/find/some/every` gate line end with `${LOG_IN_TEXT.test(arg0.getText()) ? "" : "  [SILENT]"}`.
4. Right after `if (!Node.isCallExpression(n)) return;` add:

   ```ts
   const lc = logCall(n);
   if (lc) { f.logs.push(lc); return; }
   ```

In `walk`: add `if (f.logs.length) step.logs = f.logs;`. In the flow `summary`: add `logs: all("logs")` and `silent_gates: all("gates").filter((g: string) => g.includes("[SILENT]"))`.

At the end of the file, write a catalog of **every** log call in the repo:

```ts
const catalog: Record<string, any[]> = {};
for (const sf of files)
  for (const call of sf.getDescendantsOfKind(SyntaxKind.CallExpression)) {
    const lc = logCall(call);
    if (!lc) continue;
    const fn = call.getFirstAncestor((a) => Node.isFunctionDeclaration(a) || Node.isMethodDeclaration(a) || Node.isArrowFunction(a) || Node.isFunctionExpression(a));
    (catalog[rel(sf.getFilePath())] ??= []).push({ ...lc, fn: fn ? idOf(fn) : "<module>" });
  }
mkdirSync(path.join(REPO, ".knowledge/logs"), { recursive: true });
writeFileSync(path.join(REPO, ".knowledge/logs/catalog.yaml"), YAML.stringify(catalog, { lineWidth: 0 }));
```

Run `npm run flows`.

**Verify:** `.knowledge/logs/catalog.yaml` lists your log calls with messages and metadata keys; the offers flow has `summary.logs` and `summary.silent_gates`. If `catalog.yaml` is empty, the receivers or methods in `logger.yaml` don't match your code.

### 11.3 Map the fields in OpenSearch

Create `.knowledge/logs/opensearch.yaml`. Index pattern names and the exact field names come from OpenSearch Dashboards: open Discover, pick one log line from the offers service, and copy its JSON from the document view, **with customer data removed**.

```yaml
opensearch_version: "2.19.5"
dashboards_url: https://dashboards.example.internal      # no credentials
index_patterns:
  prod: "logs-ecom-prod-*"
  stage: "logs-ecom-stage-*"
time_field: "@timestamp"
fields:
  message: message
  level: level
  level_agg: level.keyword        # an aggregatable (keyword) field for charts
  service: service.name
  correlation_id: traceId
  meta_prefix: "meta."
  reason_agg: meta.reason.keyword # optional: reason codes, if you log them
  version: app.version            # optional
services:
  api: ecom-api                   # value of the service field for the Hapi API
  workers: ecom-workers           # value for the cron workers
```

### 11.4 Generate prod runbooks, dashboards and the gaps report

Create `src/logs/generate.ts` in the tooling repo:

````ts
import "dotenv/config";
import { readFileSync, writeFileSync, mkdirSync, readdirSync } from "node:fs";
import path from "node:path";
import YAML from "yaml";

const K = path.join(process.env.ECOM_REPO!, ".knowledge");
const OS = YAML.parse(readFileSync(path.join(K, "logs/opensearch.yaml"), "utf8"));
const F = OS.fields;
const FLOWS = path.join(K, "flows");
const RUN = path.join(K, "runbooks");
const DASH = path.join(K, "logs/dashboards");
mkdirSync(RUN, { recursive: true });
mkdirSync(DASH, { recursive: true });

const q = (s: string) => `"${s.replace(/"/g, '\\"')}"`;
const and = (...p: string[]) => p.filter(Boolean).join(" and ");
const meta = (k: string) => `${F.meta_prefix ?? ""}${k}`;
const staticPart = (m: string) => m.replace(/\*$/, "").replace(/^<.*>$/, "").trim();   // phrase without dynamic suffix
const slug = (s: string) => s.replace(/[^A-Za-z0-9]+/g, "-").toLowerCase();

// ---- OpenSearch Dashboards saved objects (2.x, aggregation-based visualizations) ----
const IDX = `ip-${slug(OS.index_patterns.prod)}`;
const idxRef = [{ name: "kibanaSavedObjectMeta.searchSourceJSON.index", type: "index-pattern", id: IDX }];
const ssj = (query: string) => JSON.stringify({ query: { query, language: "kuery" }, filter: [], indexRefName: "kibanaSavedObjectMeta.searchSourceJSON.index" });
const HISTOGRAM_PARAMS = {
  type: "histogram", grid: { categoryLines: false },
  categoryAxes: [{ id: "CategoryAxis-1", type: "category", position: "bottom", show: true, style: {}, scale: { type: "linear" }, labels: { show: true, filter: true, truncate: 100 }, title: {} }],
  valueAxes: [{ id: "ValueAxis-1", name: "LeftAxis-1", type: "value", position: "left", show: true, style: {}, scale: { type: "linear", mode: "normal" }, labels: { show: true, rotate: 0, filter: false, truncate: 100 }, title: { text: "Count" } }],
  seriesParams: [{ show: true, type: "histogram", mode: "stacked", data: { label: "Count", id: "1" }, valueAxis: "ValueAxis-1", drawLinesBetweenPoints: true, lineWidth: 2, showCircles: true }],
  addTooltip: true, addLegend: true, legendPosition: "right", times: [], addTimeMarker: false, labels: { show: false },
  thresholdLine: { show: false, value: 10, width: 1, style: "full", color: "#E7664C" },
};
const indexPattern = { id: IDX, type: "index-pattern", attributes: { title: OS.index_patterns.prod, timeFieldName: OS.time_field }, references: [] };
const search = (id: string, title: string, query: string, columns: string[]) => ({
  id, type: "search", references: idxRef,
  attributes: { title, description: "Generated by debug bot", columns, sort: [[OS.time_field, "desc"]], kibanaSavedObjectMeta: { searchSourceJSON: ssj(query) } },
});
const barChart = (id: string, title: string, query: string, splitField: string) => ({
  id, type: "visualization", references: idxRef,
  attributes: {
    title, description: "Generated by debug bot", uiStateJSON: "{}", version: 1,
    visState: JSON.stringify({ title, type: "histogram", params: HISTOGRAM_PARAMS, aggs: [
      { id: "1", enabled: true, type: "count", schema: "metric", params: {} },
      { id: "2", enabled: true, type: "date_histogram", schema: "segment", params: { field: OS.time_field, interval: "auto", min_doc_count: 1, extended_bounds: {} } },
      { id: "3", enabled: true, type: "terms", schema: "group", params: { field: splitField, size: 10, order: "desc", orderBy: "1" } },
    ] }),
    kibanaSavedObjectMeta: { searchSourceJSON: ssj(query) },
  },
});
const dashboard = (id: string, title: string, panels: { id: string; type: string }[]) => ({
  id, type: "dashboard",
  references: panels.map((p, i) => ({ name: `panel_${i}`, type: p.type, id: p.id })),
  attributes: {
    title, description: "Generated by debug bot", hits: 0, timeRestore: false, version: 1,
    optionsJSON: JSON.stringify({ useMargins: true, hidePanelTitles: false }),
    panelsJSON: JSON.stringify(panels.map((_, i) => ({ panelIndex: String(i + 1), gridData: { x: (i % 2) * 24, y: Math.floor(i / 2) * 15, w: 24, h: 15, i: String(i + 1) }, version: "2.19.5", panelRefName: `panel_${i}`, embeddableConfig: {} }))),
    kibanaSavedObjectMeta: { searchSourceJSON: JSON.stringify({ query: { query: "", language: "kuery" }, filter: [] }) },
  },
});

const gaps: string[] = ["# Silent gates (generated - do not edit)", "", "Places where an item can be dropped without any log line. Add a log with a reason code at each one.", ""];

for (const file of readdirSync(FLOWS).filter((f) => f.endsWith(".yaml") && !f.startsWith("_"))) {
  const flow = YAML.parse(readFileSync(path.join(FLOWS, file), "utf8"));
  const name = file.replace(/\.yaml$/, "");
  const service = flow.entry.startsWith("WORKER ") ? OS.services?.workers : OS.services?.api;
  const svc = service ? `${F.service} : ${q(service)}` : "";
  const logs = (flow.steps ?? []).flatMap((s: any) => (s.logs ?? []).map((l: any) => ({ ...l, fn: s.fn })));
  const phrases = [...new Set(logs.map((l: any) => staticPart(l.message)).filter((p: string) => p.length > 3))].slice(0, 20);
  const flowQuery = and(svc, phrases.length ? `(${phrases.map((p) => `${F.message} : ${q(p)}`).join(" or ")})` : "");
  const idFields = [...new Set(logs.flatMap((l: any) => l.fields))].filter((k: any) => /sku|offer|store|order|cart|product|customer|id$/i.test(k)) as string[];
  const silent: string[] = flow.summary?.silent_gates ?? [];

  // Runbook
  const md = [
    `# Prod runbook: ${flow.entry}`, "",
    `Generated from flows/${file}. Rerun \`npm run logs\` after code changes; don't edit by hand.`, "",
    `Index pattern: \`${OS.index_patterns.prod}\` · Time field: \`${OS.time_field}\` · Correlation id: \`${F.correlation_id ?? "(none - see gaps)"}\``, "",
    "## 1. Find the request or job run", "",
    "In Discover, set the time range around the problem, then paste (replace the <placeholders>):", "",
    "```", and(svc, ...idFields.slice(0, 1).map((k) => `${meta(k)} : "<${k}>"`)) || flowQuery, "```", "", `Other metadata you can add to narrow it: ${idFields.slice(1).map((k) => `\`${meta(k)}\``).join(", ") || "none"}.`, "",
    ...(F.correlation_id ? [
      `## 2. Take the \`${F.correlation_id}\` of a matching line and show the whole request`, "",
      "```", `${F.correlation_id} : "<id>"`, "```", "", "Sort by time, oldest first.", "",
      "Same in Query Workbench (PPL):", "",
      "```", `source = ${OS.index_patterns.prod} | where \`${F.correlation_id}\` = '<id>' | sort \`${OS.time_field}\` | fields \`${OS.time_field}\`, \`${F.level}\`, \`${F.message}\``, "```", "",
    ] : []),
    "## 3. Compare with the log lines this flow should write", "",
    "A line that should appear but doesn't tells you where the request stopped.", "",
    "| # | Level | Message | Written in | Metadata |", "| --- | --- | --- | --- | --- |",
    ...logs.map((l: any, i: number) => `| ${i + 1} | ${l.level} | ${l.message.replace(/\|/g, "\\|")} | ${l.at} | ${l.fields.join(", ")} |`), "",
    "## 4. Places this flow can drop an item without logging", "",
    silent.length ? "Logs can't show these. Check them with the stage reproduction (`debug request`) or the rule checks in `rules/`." : "None found.", "",
    ...silent.map((g) => `- ${g}`), "",
    "## 5. Errors and warnings in this flow", "",
    "```", and(svc, `${F.level} : ("error" or "warn")`), "```", "",
    `Dashboard: import \`logs/dashboards/${name}.ndjson\` (see guide 11.5).`, "",
  ].join("\n");
  writeFileSync(path.join(RUN, `${name}.md`), md);

  // Dashboard objects
  const base = slug(name);
  const objects: any[] = [
    indexPattern,
    search(`${base}-logs`, `${flow.entry} - flow logs`, flowQuery, [F.level, F.message, ...(F.correlation_id ? [F.correlation_id] : [])]),
    search(`${base}-errors`, `${flow.entry} - errors and warnings`, and(svc, `${F.level} : ("error" or "warn")`), [F.level, F.message]),
    barChart(`${base}-levels`, `${flow.entry} - log volume by level`, flowQuery, F.level_agg ?? F.level),
    ...(F.reason_agg ? [barChart(`${base}-reasons`, `${flow.entry} - reason codes`, and(svc, `${F.reason_agg.replace(/\.keyword$/, "")} : *`), F.reason_agg)] : []),
  ];
  objects.push(dashboard(`${base}-dashboard`, `Debug bot - ${flow.entry}`, objects.slice(1).map((o) => ({ id: o.id, type: o.type }))));
  writeFileSync(path.join(DASH, `${name}.ndjson`), objects.map((o) => JSON.stringify(o)).join("\n") + "\n");

  if (silent.length) gaps.push(`## ${flow.entry}`, "", ...silent.map((g) => `- ${g}`), "");
}
writeFileSync(path.join(K, "logs/gaps.md"), gaps.join("\n"));
console.log("runbooks, dashboards and gaps report written");
````

```bash
cd ~/work/ecom-debug-bot
npm pkg set scripts.logs="tsx src/logs/generate.ts"
npm run flows && npm run logs
```

**Verify:** open `.knowledge/runbooks/GET_products_sku_offers.md`. Step 1's query, pasted into Discover with a real SKU and a time range, should find that route's log lines.

### 11.5 Import the dashboards

In OpenSearch Dashboards: **Dashboards Management → Saved objects → Import**, choose `.knowledge/logs/dashboards/<flow>.ndjson`, and allow overwriting (the IDs are stable, so re-importing updates them). If your OpenSearch uses security tenants, switch to the tenant your team uses first. Import into a **non-prod** Dashboards first.

If a chart shows an error after import, the chart format differs slightly in your build: create one bar chart by hand in your Dashboards, export it (Saved objects → Export), and give the file to Cline to copy its `params` into `HISTOGRAM_PARAMS`.

### 11.6 Close the logging gaps

`.knowledge/logs/gaps.md` lists every place an item is dropped without a log line. For the ones that matter (offers first), add one log line with a reason code, using your wrapper, for example:

```ts
logger.info("offer dropped", { reason: "OFFER_NO_INVENTORY", sku, offerId, storeId, availableQty });
```

Also make sure every log line carries a **correlation id** (request id for the API, run id for workers) and the **app version**. These go into the backend through your normal code review. After they ship, rerun `npm run flows && npm run logs`: the gates stop being `[SILENT]` and the runbooks and dashboards pick up the new lines.

### 11.7 Later: Cline reads logs itself (needs approval)

Once security approves read access to prod logs, a `debug logs` subcommand can call OpenSearch's search API, and Cline can trace a prod request end to end: find it, read its lines, compare them with the flow, and give the verdict. Requirements before building it:

- A **read-only** OpenSearch user or role (whatever your cluster uses: internal user, SAML/LDAP-mapped role, or AWS SigV4 for Amazon OpenSearch Service), limited to the log index patterns.
- **Field-level security or field masking** in the OpenSearch security plugin for customer fields, so masking happens in the cluster, not only in the script.
- In the CLI: allow only `POST <index>/_search` and `POST /_plugins/_ppl`, force a time range and `size ≤ 200`, mask output, and add `{ENV}_OPENSEARCH_URL` and the credentials to the env files (via `env:init`).

Until then, the runbooks give you the same steps to run by hand. If you paste results back to Cline, remove customer data first.

## Phase 12 — Config differences, caches and queues

Three common causes the flows don't cover yet: **config that differs between environments** ("works in qa, not in stage"), **caches** that serve an old value while the source is already correct, and **queues/topics** that connect services asynchronously. This phase adds them to the flow maps and gives the `debug` CLI two new subcommands.

### 12.1 Record cache and queue calls in the flow maps

In `src/extract/flows.ts`, add these constants:

```ts
const CACHE_RECV = /redis|cache/i;
const CACHE_READ = /^(get|mget|hget|hgetall|hmget|smembers|sismember|zrange|lrange|exists|ttl)$/i;
const CACHE_WRITE = /^(set|setex|psetex|mset|hset|hmset|del|expire|sadd|srem|zadd|lpush|rpush|incr|decr)$/i;
const MQ_RECV = /kafka|producer|consumer|sqs|sns|queue|topic|bus|pubsub|channel/i;
const MQ_PUB = /^(send|sendMessage|sendBatch|publish|produce|emit)$/;
const MQ_SUB = /^(subscribe|consume|run|receiveMessage|process)$/;
```

Add `cache: any[]` and `topics: any[]` to `Facts` (and `cache: [], topics: []` to the initial object). Then, in `factsOf`, insert these two branches **right after** the `filter/find/some/every` branch and **before** the HTTP branch (so a `redisClient.get` isn't mistaken for an HTTP call):

```ts
else if (CACHE_RECV.test(recv) && (CACHE_READ.test(name) || CACHE_WRITE.test(name)))
  f.cache.push({ at: at(n), op: CACHE_READ.test(name) ? "read" : "write", key: short(arg0?.getText() ?? "", 120), call: `${short(recv, 40)}.${name}` });
else if (MQ_RECV.test(recv) && (MQ_PUB.test(name) || MQ_SUB.test(name))) {
  const prop = arg0 && Node.isObjectLiteralExpression(arg0)
    ? (arg0.getProperty("topic") ?? arg0.getProperty("QueueUrl") ?? arg0.getProperty("TopicArn")) : undefined;
  const topic = prop && Node.isPropertyAssignment(prop) ? prop.getInitializer()?.getText() : arg0?.getText();
  f.topics.push({ at: at(n), op: MQ_PUB.test(name) ? "publish" : "consume", topic: short(topic ?? "", 120), call: `${short(recv, 40)}.${name}` });
}
```

In `walk`, add `if (f.cache.length) step.cache = f.cache;` and `if (f.topics.length) step.topics = f.topics;`. In the flow `summary`, add `cache: all("cache")` and `topics: all("topics")`. In the outputs loop, after the tables are added to `links`, add:

```ts
for (const t of all("topics")) {
  const l = (links[`topic: ${t.topic}`] ??= { written_by: new Set(), read_by: new Set() });
  (t.op === "consume" ? l.read_by : l.written_by).add(e.name);
}
for (const c of all("cache")) {
  const l = (links[`cache: ${c.key}`] ??= { written_by: new Set(), read_by: new Set() });
  (c.op === "read" ? l.read_by : l.written_by).add(e.name);
}
```

Run `npm run flows`. `_data-links.yaml` now also shows which flows publish or consume each topic and which write or read each cache key. For example, a cache key `offers:${sku}` written by the offer-publisher worker and read by the offers route appears with `written_by: [WORKER offer-publisher]` and `read_by: [GET /products/{sku}/offers]`.

Also add one line to the `flow-to-rules` prompt (4.6): "`data_from` may be a cache key or a topic; `upstream` may be a topic's producer. Add a `cache` check (`debug cache`) for every cached value a gate uses."

### 12.2 `debug envdiff`: compare the same data in two environments

In `src/cli/debug.ts`, move the bodies of the `api` and `db` cases into two functions that **return** the data, and use them from the cases:

```ts
async function apiGet(e: Env, service: string, p: string, query?: string) {
  const c = cfg(e);
  const base = c.services?.[service];
  if (!base) throw new Error(`Unknown service. Known: ${Object.keys(c.services ?? {}).join(", ")}`);
  const token = secrets(e)[c.auth?.token_env];
  const params = query ? Object.fromEntries(query.split(",").map((kv) => kv.split("="))) : undefined;
  return (await axios.get(base + p, { params, timeout: 10_000, headers: token ? { Authorization: `Bearer ${token}` } : {} })).data;
}

async function dbSelect(e: Env, sql: string) {
  const clean = sql.trim().replace(/;\s*$/, "");
  if (!/^(select|with)\b/i.test(clean) || clean.includes(";") ||
      /\b(insert|update|delete|drop|alter|truncate|grant|create|copy)\b/i.test(clean))
    throw new Error("Only a single SELECT statement is allowed");
  const client = new pg.Client({ connectionString: secrets(e)[cfg(e).db_readonly_env] });
  try {
    await client.connect();
    await client.query("SET statement_timeout = 10000; SET default_transaction_read_only = on;");
    return (await client.query(`SELECT * FROM (${clean}) q LIMIT 200`)).rows;
  } finally { await client.end().catch(() => {}); }
}

const flatten = (v: any, p = "", out: Record<string, unknown> = {}) => {
  if (v && typeof v === "object") for (const [k, x] of Object.entries(v)) flatten(x, p ? `${p}.${k}` : k, out);
  else out[p] = v;
  return out;
};
```

The two existing cases become:

```ts
case "api": return print(await apiGet(env(args[0]), args[1], args[2], flags.query));
case "db":  return print({ rows: await dbSelect(env(args[0]), args[1] ?? "") });
```

Add the new case:

```ts
case "envdiff": {
  const [a, b, kind, x, y] = args;
  const fetch1 = kind === "api" ? (e: string) => apiGet(env(e), x, y, flags.query)
               : kind === "db"  ? (e: string) => dbSelect(env(e), x)
               : undefined;
  if (!fetch1) throw new Error('usage: envdiff <envA> <envB> api <service> <path> [--query k=v] | db "<SELECT ... ORDER BY ...>"');
  const [A, B] = await Promise.all([fetch1(a), fetch1(b)]);
  const fa = flatten(mask(A)), fb = flatten(mask(B));
  const keys = [...new Set([...Object.keys(fa), ...Object.keys(fb)])].sort();
  const diff = keys.filter((k) => JSON.stringify(fa[k]) !== JSON.stringify(fb[k])).map((k) => ({ path: k, [a]: fa[k], [b]: fb[k] }));
  return print({ compared: keys.length, different: diff.length, diff: diff.slice(0, 200) });
}
```

Examples:

```bash
npm --prefix ../ecom-debug-bot run -s debug -- envdiff qa stage api offers /offers/OFF-123
npm --prefix ../ecom-debug-bot run -s debug -- envdiff qa stage db "select key, value from feature_flags order by key"
```

For `db`, always add `ORDER BY`, otherwise rows may come back in a different order and every row looks different.

### 12.3 `debug cache`: read one cache key (read-only)

```bash
cd ~/work/ecom-debug-bot
npm i ioredis
```

Add `{ENV}_REDIS_URL_READONLY=` to the env template and run `env:init`. Ask your platform team for a **read-only Redis user**; with Redis ACLs that is, for example, a user allowed only `get`, `type`, `ttl`, `hgetall`, `smembers`, `lrange` and `zrange`. Then add the case:

```ts
case "cache": {
  const [e, key] = args;
  const E = env(e);
  const url = secrets(E)[`${E.toUpperCase()}_REDIS_URL_READONLY`];
  if (!url) throw new Error(`Fill ${E.toUpperCase()}_REDIS_URL_READONLY in the env file (run env:check)`);
  if (!key || /[*?\[]/.test(key)) throw new Error("Give one exact key; patterns and SCAN/KEYS are not allowed");
  const { default: Redis } = await import("ioredis");
  const r = new Redis(url, { lazyConnect: true, maxRetriesPerRequest: 1 });
  try {
    await r.connect();
    const type = await r.type(key);
    const ttl = await r.ttl(key);
    const value = type === "string" ? await r.get(key)
      : type === "hash" ? await r.hgetall(key)
      : type === "set" ? await r.smembers(key)
      : type === "list" ? await r.lrange(key, 0, 49)
      : type === "zset" ? await r.zrange(key, 0, 49, "WITHSCORES")
      : null;
    let parsed: unknown = value;
    if (typeof value === "string") { try { parsed = JSON.parse(value); } catch {} }
    return print({ key, type, ttl_seconds: ttl, value: parsed });
  } finally { r.disconnect(); }
}
```

Add `envdiff` and `cache` to the `USAGE` text.

**Verify:** `debug envdiff dev qa api <service> <path>` lists only the fields that differ; `debug cache dev <a real key from _data-links>` shows type, TTL and value; `debug cache dev "offers:*"` is refused.

### 12.4 Tell Cline when to use them

Add to the "For X is missing / wrong" steps in `AGENTS.md`:

```markdown
- If it works in one environment but not another, run `debug envdiff <good env> <bad env>` on the
  data source of every rule (api path or SELECT with ORDER BY), and on feature-flag/config tables.
- If a rule's data is cached (flow summary `cache`, or `_data-links` shows a cache key), compare
  `debug cache <env> <key>` with the source of truth. A difference means a stale cache: report the TTL.
- If the data arrives via a topic, check that the producer ran (`debug job-traces`, prod runbook) and
  that the consumer flow processed it.
- For prod issues: never reproduce in prod. Give the steps from .knowledge/runbooks/<flow>.md with the
  user's values filled in, and ask them to paste back the results (customer data removed).
```

## Troubleshooting and progress checklist

| Symptom | Likely cause | Fix |
| --- | --- | --- |
| Cline answers without running `debug` | Didn't load the rules, or in Plan mode | Use Act mode; check `.clinerules/ecom-debug.md` exists; say "follow AGENTS.md" in the question |
| Cline invents data | Command error ignored, or output cut off | Run the same command yourself (7.3); keep the "never guess data" rule in `AGENTS.md` |
| Cline tries `curl`, `node -e` or reads `.env` | Ignored the rules | Reject the command; remind it to use only the `debug` command; check `.clineignore` (1.2) |
| Cline never sees the command's output | VS Code shell integration off | Enable shell integration; restart VS Code (1.1) |
| `env must be one of ...` | Env not in `ALLOWED_ENVS` | Use dev, stage or qa (prod is excluded on purpose) |
| `worker` takes too long | Whole catalog processed | Pass `--skus` with one SKU, or `--limit 1` |
| `Cannot find module '@/...'` when the runner loads dist/ | Backend path aliases | Reuse whatever production uses to resolve aliases (tsc-alias or module-alias) |
| `ERROR: HTTP 401/403` | Wrong or expired token | Refresh the token in `.env.stage`; confirm it's a read-only service token |
| `ENOTFOUND` or timeouts to stage | Terminal can't reach stage | Connect VPN; set proxy variables for VS Code's terminal (1.1) |
| Trace stops early; call listed under BLOCKED WRITES | A downstream POST that only reads (search APIs) was blocked | Add its path to `allow_post_paths` in environments.yaml (Phase 6.3) |
| `search` misses an obvious function | Business word not in the code | Add it to `search-synonyms.yaml` (9.3) and run `npm run index` |
| Summaries are wrong | Cline misread code | Fix the `.md` by hand; it's only rewritten when listed in `STALE.md` |
| Empty Jaeger | `OTEL_ENABLED` not set, or tracing not imported first | Check both; confirm port 4318 is mapped |
| logs/catalog.yaml is empty | Logger receivers or methods in logger.yaml don't match the code | Check how the wrapper is called (11.1), fix call\_patterns, rerun npm run flows |
| Runbook query finds nothing in Discover | Field names or index pattern differ from opensearch.yaml, or wrong time range | Compare with a real document's JSON in Discover; fix opensearch.yaml; rerun npm run logs |
| Dashboard import fails or a chart shows an error | Wrong tenant, non-keyword field in a chart, or chart format differs | Switch tenant; set level\_agg/reason\_agg to keyword fields; export a hand-made chart as the template (11.5) |
| envdiff shows every row as different | Rows returned in different order | Add ORDER BY to the SELECT |

### Checklist

- [ ] Phase 1: Cline runs `node -v`, `tsx` and a stage health check from the terminal; `.clineignore` hides `.env*`
- [ ] Phase 2: security has OK'd masked stage/qa data going to Cline; prod excluded
- [ ] Phase 3: tooling repo created, dependencies installed
- [ ] Phase 4: `generated/` files produced; module summaries reviewed; flows/INDEX.md lists every route and worker; rules file for the offers flow reviewed
- [ ] Phase 5: INDEX, rules, environments, glossary written
- [ ] Phase 6: createServer + worker registry merged, runner CLI prints a trace
- [ ] Phase 7: every `debug` subcommand works when you run it; Cline runs it and explains the offer scenario
- [ ] Phase 8: one job traced in Jaeger, outputs profiled
- [ ] Phase 9: `debug search` finds the right functions
- [ ] Phase 10: pre-commit hook and nightly job running; `STALE.md` empty
- [ ] Phase 11: logger.yaml and opensearch.yaml written; catalog and silent gates in the flows; offers runbook query finds real log lines; dashboard imported in non-prod
- [ ] Phase 12: cache keys and topics in \_data-links; debug envdiff and debug cache work; AGENTS.md updated

Once the offer flow works end to end, extending to the next domain (pricing, promotions, cart, another worker) needs no new commands: add its folder to `WATCH`, register any new worker in the registry, and write its rules YAML, synonyms and module notes so Cline can explain what the trace shows.
