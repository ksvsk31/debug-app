# Track BE — Backend

**Purpose:** build the backend part of the debug bot: knowledge from code, flow maps, rules with checks, the debug runner and CLI, prod log runbooks and dashboards, env diff, caches and queues.
**Prerequisites:** none (this is the first track).
**Rules:** everything in `sdd.md` applies (operating rules §2, resumability §3, when to ask §4). References like "(4.1)" point to SDD §4.
**Code reference:** `guide.md` ("Guide §X"). Paths: use `tools/debug-bot` wherever the guide says `~/work/ecom-debug-bot` (SDD §2.6).

Each task: **Guide** = section with the code · **Steps** = numbered, each safe to rerun · **Done when** = checks · **Ask if** = allowed questions.

---

## Outputs and end state

```
ecom-backend/
  AGENTS.md                         # bot instructions (Guide §7.5)
  .clinerules/ecom-debug.md         # "Follow AGENTS.md"
  .clineignore                      # hides .env*, keys
  docs/debug-bot/                   # sdd.md, track files, guide.md, resume.md, progress.md, files.txt
  .knowledge/
    INDEX.md  glossary.yaml  search-synonyms.yaml  STALE.md
    generated/  flows/  rules/  modules/  envs/  data/  prompts/
    data/observed/  data/findings.md       # observed profiles of tables, endpoints, cache keys + code-vs-data findings (BE24)
    observed/flows/<flow>/<case>/         # saved runner spans, responses and gate outcomes per sample case (BE25)
    logs/       (logger.yaml, opensearch.yaml, catalog.yaml, gaps.md, suggested-log-lines.md, dashboards/*.ndjson)
    runbooks/   (<flow>.md: prod debugging steps with DQL/PPL queries)
  tools/debug-bot/                  # all tooling (own package.json + node_modules)
    package.json  package-lock.json  tsconfig.json
    src/paths.ts                    # repo paths from config/repos.yaml, no absolute paths
    src/extract/  (index.ts, flows.ts, stale.ts, check-rules.ts)
    src/runner/   (config.ts, mask.ts, instrument.ts, child.ts, compress.ts, runner.ts, cli.ts, catalog.ts)
    src/cli/debug.ts                # incl. diagnose (BE27) and kb (BE28)
    src/kb/       (build.ts, check.ts)              # knowledge index, cards, budgets (BE28)
    src/search/   (options.ts, index.ts)
    src/profile/index.ts
    src/logs/generate.ts            # runbooks, dashboards, gaps (BE20)
    src/data/     (observe.ts, observe-flows.ts)   # data knowledge (BE24-BE25)
    scripts/pack.mjs  scripts/env-init.mjs  scripts/env-check.mjs
    config/repos.yaml  config/environments.yaml  config/jobs.yaml  config/data-policy.yaml  config/samples.yaml
    env-templates/  (app.env.example, backend.env.example)   # variable names + comments, no secrets
    .env.dev  .env.stage  .env.qa                             # tool secrets: created by env:init, values filled by the human
    .env.backend.dev  .env.backend.stage  .env.backend.qa     # backend boot vars per env: same; never bundled, never read by Cline
  src/server.ts                     # createServer() without start()   (BE09, listed in files.txt as backend:...)
  src/workers/registry.ts           # WORKERS map                       (BE09, listed in files.txt as backend:...)
```

**Definition of done:**
- **Core (BE16):** Cline answers "Offer <id> is not showing for SKU <sku> in <env>, store <store>. Why?" with a table of every rule, the value found, pass/fail, code location and upstream job, using only the `debug` CLI and public `curl`.
- **Efficient (BE27, BE28):** one `debug diagnose` call checks every rule; cards, the `kb` index and budgets keep a typical diagnosis under ~10 tool calls and ~15k tokens of reading.
- **Data (BE24, BE25):** every table, endpoint and cache key used by the offers flow has an observed profile; the offers rules file shows observed pass/fail for each sample case; code-vs-data findings are listed.
- **Extended (BE11, BE20, BE22):** for a prod issue, Cline reads the public prod APIs directly, compares them with stage, and gives OpenSearch steps with the user's values filled in that find the request's log lines; for "works in qa, not in stage", it uses `debug envdiff` and, where cached, `debug cache`.

---

## Tasks

Each task: **Guide** = section with the code · **Steps** = numbered, each safe to rerun · **Done when** = checks · **Ask if** = allowed questions.

### BE00 — Set up tracking
- **Steps:**
  1. Confirm `docs/debug-bot/guide.md` exists (if not, ask 4.1).
  2. Create `docs/debug-bot/progress.md` from SDD section 7 (skip if it exists). Fill `Machine`, `Base commits` and the BE checklist from this file's task headings.
  3. Create `docs/debug-bot/files.txt` with a header comment line (skip if it exists).
  4. Optional: if git is available, create/switch to local branch `feat/debug-bot`.
- **Done when:** both state files exist and *Current position* is filled.

### BE01 — Environment checks
- **Guide:** §1.1
- **Steps:** 1. `node -v`, `npm -v`. 2. `npx -y tsx -e "console.log('tsx ok')"`. 3. Find a dev health/status endpoint of a downstream service in code/config (search `health`, `status`, `ping`) and GET it.
- **Done when:** Node ≥ 20; `tsx ok`; the health call returns any HTTP status.
- **Ask if:** Node < 20 (4.4); no health URL found (4.1); network fails (ask about VPN/proxy).

### BE02 — Protect secrets
- **Guide:** §1.2
- **Steps:** 1. Create/extend `.clineignore` with `.env`, `.env.*`, `**/*.pem`, `**/*.key`. 2. Ensure `.gitignore` (if present) ignores `.env*` and `tools/debug-bot/node_modules`, `tools/debug-bot/.search-index.json`, `debug-bot-handoff-*.tgz`.
- **Done when:** entries present. (Record `.clineignore`/`.gitignore` in `docs/debug-bot/files.txt` if you changed existing files.)

### BE03 — Data access decision
- **Guide:** Phase 2 (already settled, nothing to ask)
- **Steps:** Record under *Decisions*: "2026-10-28, user: no personal or secure data in these systems; dev, stage and qa may be used for live tests; prod may be read through public GET endpoints only (no credentials)." Set *Live test environments* in `progress.md` accordingly.
- **Done when:** the decision is recorded.

### BE04 — Tooling scaffold
- **Guide:** Phase 3, deps from §6.4, §8.4, §9.1
- **Steps:**
  1. Create `tools/debug-bot/` with `package.json` (`"type": "module"`, `"private": true`), `tsconfig.json` (Guide Phase 3), folders `src/{extract,runner,cli,search,profile}`, `scripts/`, `config/`, `env-templates/`.
  2. Install dependencies in one go: `ts-morph yaml zod dotenv axios fast-glob pg minisearch require-in-the-middle @opentelemetry/api @opentelemetry/sdk-node @opentelemetry/sdk-trace-base @opentelemetry/auto-instrumentations-node @duckdb/node-api`; dev: `typescript tsx @types/node @types/pg`.
  3. Create `src/paths.ts`:
     ```ts
     import path from "node:path";
     import { readFileSync, existsSync } from "node:fs";
     import { fileURLToPath } from "node:url";
     import YAML from "yaml";

     export const TOOL_ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
     export const REPO = process.env.ECOM_REPO ?? path.resolve(TOOL_ROOT, "../..");      // backend repo
     export const KNOWLEDGE = path.join(REPO, ".knowledge");                               // backend knowledge
     const cfgFile = path.join(TOOL_ROOT, "config/repos.yaml");
     export const REPOS_CFG = existsSync(cfgFile)
       ? YAML.parse(readFileSync(cfgFile, "utf8"))
       : { workspace_root: "..", system_knowledge: "system-knowledge", repos: { backend: { path: ".", kind: "hapi" } } };
     export const SYSTEM = path.resolve(REPO, REPOS_CFG.system_knowledge ?? "system-knowledge");
     export const repoNames = (kind?: string) =>
       Object.entries(REPOS_CFG.repos as Record<string, { path: string; kind: string }>)
         .filter(([, r]) => !kind || r.kind === kind).map(([n]) => n);
     export const repoPath = (name: string) => path.resolve(REPO, REPOS_CFG.repos[name].path);
     export const repoKnowledge = (name: string) => path.join(repoPath(name), ".knowledge");
     ```
     Use these everywhere the guide uses `process.env.ECOM_REPO` or `ROOT`; scripts that work on a repo take `--repo <name>` (default `backend`). Load secrets with `dotenv.config({ path: path.join(TOOL_ROOT, ".env.<env>") })`.
  4. Make sure the backend's own tooling ignores `tools/`: add `tools` to the `exclude` of the backend `tsconfig.json`, and to ESLint/Jest/Mocha/Lab ignore patterns if they glob the whole repo. Record changed files in `docs/debug-bot/files.txt` as `backend:<path>`. If the backend build would include `tools/` and excluding it needs a build-setting change, ask (4.4).
  5. Create `config/repos.yaml` exactly as in SDD 5.2 (backend only for now).
  6. Create `scripts/pack.mjs` and add `"pack": "node scripts/pack.mjs"`. It bundles every registered repo, relative to the workspace root:
     ```js
     import { execFileSync } from "node:child_process";
     import { readFileSync, existsSync } from "node:fs";
     import path from "node:path";
     import { fileURLToPath } from "node:url";
     import YAML from "yaml";

     const backend = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "../../..");
     const cfg = YAML.parse(readFileSync(path.join(backend, "tools/debug-bot/config/repos.yaml"), "utf8"));
     const root = path.resolve(backend, cfg.workspace_root ?? "..");
     const repos = Object.entries(cfg.repos)
       .map(([name, r]) => ({ name, dir: path.resolve(backend, r.path) }))
       .filter((r) => existsSync(r.dir));
     const items = new Set();
     const add = (dir, p) => { if (existsSync(path.join(dir, p))) items.add(path.relative(root, path.join(dir, p))); };

     add(backend, "tools/debug-bot");
     add(backend, "docs/debug-bot");
     add(backend, cfg.system_knowledge ?? "system-knowledge");
     for (const r of repos) for (const p of [".knowledge", "AGENTS.md", ".clinerules", ".clineignore"]) add(r.dir, p);
     const manifest = path.join(backend, "docs/debug-bot/files.txt");
     if (existsSync(manifest))
       for (const line of readFileSync(manifest, "utf8").split("\n").map((s) => s.trim()).filter((s) => s && !s.startsWith("#"))) {
         const [repo, rel] = line.includes(":") ? line.split(/:(.+)/) : ["backend", line];
         const r = repos.find((x) => x.name === repo);
         if (r) add(r.dir, rel);
       }
     const ws = path.join(root, "ecom-debug.code-workspace");
     if (existsSync(ws)) items.add(path.basename(ws));

     const stamp = new Date().toISOString().slice(0, 16).replace(/[:T]/g, "-");
     const out = path.join(root, `debug-bot-handoff-${stamp}.tgz`);
     execFileSync("tar", ["-czf", out,
       "--exclude=node_modules", "--exclude=.env", "--exclude=.env.*", "--exclude=.search-index.json", "--exclude=*.log",
       "-C", root, ...items], { stdio: "inherit" });
     console.log(`bundle: ${out} (${items.size} items from ${repos.map((r) => r.name).join(", ")}; no secrets, no node_modules)`);
     ```
  7. Env file tooling. Templates use `{ENV}` (upper case) and `{env}` placeholders and become one file per environment. Create `env-templates/app.env.example`:
     ```
     # Debug bot secrets for {env}. Fill in READ-ONLY values. Never commit or share this file.
     # Cline never reads this file. Check what's missing: npm --prefix tools/debug-bot run env:check
     {ENV}_API_TOKEN=
     {ENV}_DB_URL_READONLY=
     {ENV}_MIN_QTY=1
     ```
     and `env-templates/backend.env.example` with just the header for now (BE10 adds the backend's variable names).
     Create `scripts/env-init.mjs` and add `"env:init": "node scripts/env-init.mjs"`:
     ```js
     // Creates missing env files from templates and appends keys that are new in a template.
     // Never changes or prints existing values.
     import { readFileSync, writeFileSync, appendFileSync, existsSync, readdirSync } from "node:fs";
     import path from "node:path";
     import { fileURLToPath } from "node:url";

     const TOOL = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
     const TPL = path.join(TOOL, "env-templates");
     const ENVS = (process.argv[2] ?? "dev,stage,qa").split(",").map((s) => s.trim()).filter(Boolean);
     const keyOf = (line) => line.match(/^\s*([A-Z0-9_]+)\s*=/)?.[1];

     for (const tpl of readdirSync(TPL).filter((f) => f.endsWith(".env.example"))) {
       const kind = tpl.replace(/\.env\.example$/, "");                    // "app" or "backend"
       for (const env of ENVS) {
         const target = path.join(TOOL, kind === "app" ? `.env.${env}` : `.env.${kind}.${env}`);
         const name = path.relative(TOOL, target);
         const lines = readFileSync(path.join(TPL, tpl), "utf8")
           .replaceAll("{ENV}", env.toUpperCase()).replaceAll("{env}", env).split("\n");
         if (!existsSync(target)) {
           writeFileSync(target, lines.join("\n"), { mode: 0o600 });
           console.log(`created ${name}`);
           continue;
         }
         const have = new Set(readFileSync(target, "utf8").split("\n").map(keyOf).filter(Boolean));
         const missing = lines.filter((l) => keyOf(l) && !have.has(keyOf(l)));
         if (missing.length) {
           appendFileSync(target, `\n# added ${new Date().toISOString().slice(0, 10)} from ${tpl}\n${missing.join("\n")}\n`);
           console.log(`${name}: added ${missing.length} new key(s): ${missing.map(keyOf).join(", ")}`);
         } else console.log(`${name}: up to date`);
       }
     }
     ```
     Create `scripts/env-check.mjs` and add `"env:check": "node scripts/env-check.mjs"`:
     ```js
     // Lists, per env file, which keys are set and which are empty. Prints key NAMES only.
     import { readFileSync, readdirSync } from "node:fs";
     import path from "node:path";
     import { fileURLToPath } from "node:url";

     const TOOL = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
     const files = readdirSync(TOOL).filter((f) => /^\.env\./.test(f)).sort();
     if (!files.length) console.log("no env files yet - run: npm --prefix tools/debug-bot run env:init");
     for (const f of files) {
       const empty = [];
       let set = 0;
       for (const line of readFileSync(path.join(TOOL, f), "utf8").split("\n")) {
         const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)$/);
         if (!m) continue;
         if (m[2].replace(/^["']|["']$/g, "").trim()) set++; else empty.push(m[1]);
       }
       console.log(`${f}: ${set} set, ${empty.length} empty${empty.length ? " -> " + empty.join(", ") : ""}`);
     }
     ```
     Run `env:init` then `env:check`.
- **Done when:** `npm --prefix tools/debug-bot ls --depth=0` lists the packages; `npx tsx tools/debug-bot/src/paths.ts` runs; `env:init` creates `.env.dev`, `.env.stage`, `.env.qa` (and `.env.backend.*`); running it a second time reports "up to date"; `env:check` lists the empty keys; `npm --prefix tools/debug-bot run pack` creates a bundle, and `tar -tzf` on it shows no `.env` file and no `node_modules` (delete that test bundle afterwards); the backend build still passes.

### BE05 — Code extractor
- **Guide:** §4.1–4.3
- **Steps:** 1. Inspect how routes are declared, the HTTP client(s) and wrapper names, how config/env is read. 2. Create `src/extract/index.ts` adapted (`CLIENT` regex, route detection, `paths.ts`). 3. Add `extract` script and run it. 4. Generate `generated/deps.json` with madge.
- **Done when:** non-zero counts; `generated/downstream-calls.yaml` contains calls to the services you saw in the code; `manifest.json` exists.

### BE06 — Flow maps
- **Guide:** §4.5
- **Steps:** 1. Create `src/extract/flows.ts` reusing BE05's patterns. 2. Add `flows` script, run it. 3. Compare `flows/INDEX.md` with the routes/workers you can see in code; fix entry detection if any are missing (route arrays, `server.route([...])`, other worker setups) and rerun. 4. For each `summary.unresolved` item in the offers flow, try a pattern/type fix; record what remains.
- **Done when:** `flows/INDEX.md` lists every route and worker; the offers flow's `summary.gates` includes the ecomFlag, inventory and stackability checks (or equivalents); `_data-links.yaml` exists.
- **Ask if:** more than one plausible "offers" entry point (4.6).

### BE07 — Freshness scripts
- **Guide:** §10.1–10.2
- **Steps:** 1. Create `src/extract/stale.ts`. 2. Create `src/extract/check-rules.ts`, adapted to check **every** `.knowledge/rules/*.yaml`: take the code pointer from `source` (`file#function`) or `check_in_code` (`path/file.ts:line`); fail if the file is missing, the line is past the end, or the function isn't in the file; exit 0 when there are no rules files. 3. Add scripts; run `stale` and `check-rules`.
- **Done when:** `.knowledge/STALE.md` lists every module with its hash; `check-rules` exits 0.

### BE08 — Knowledge files
- **Guide:** §4.4, §4.6, Phase 5, §9.3
- **Steps** (each writes whole files, so each is resumable):
  1. Save prompts `.knowledge/prompts/module-summary.md` (§4.4) and `.knowledge/prompts/flow-to-rules.md` (§4.6), with commands rewritten for `tools/debug-bot`.
  2. Module summaries: for each module listed in `STALE.md`, follow `module-summary.md`; after **each** module, log it in *Step log* (BE08.2:<module>). Rerun `stale` until it reports 0.
  3. `envs/environments.yaml` (§5.4) from URLs in config/code; env var names only.
  4. `glossary.yaml` (§5.5) from flags, statuses and enums in the code.
  5. `search-synonyms.yaml` (§9.3).
  6. Rules files (include `probe`/`assert` where you can already; the format is in BE27): run `flow-to-rules.md` for the offers flow, then for each worker that `_data-links.yaml` lists as `written_by` for tables the offers flow reads. Log each finished flow.
  7. `.knowledge/INDEX.md` (§5.1, with the flows rows).
  8. `check-rules`.
- **Done when:** `STALE.md` says all current; the offers rules file maps every gate to a rule with a runnable `check`; `check-rules` exits 0; `INDEX.md` links every knowledge file.
- **Ask if:** a base URL isn't in the code (4.1); unresolved business meanings — collect all `UNCLEAR:` items and ask them together **at the end of this task**.

### BE09 — Backend refactors (only these)
- **Guide:** §6.1–6.2
- **Steps:**
  1. Record the baseline: run the backend build and tests; log results.
  2. If the Hapi server is already created without `start()`, reuse it; otherwise split into `src/server.ts` (`createServer()` + `initialize()`) and keep `src/index.ts` calling `start()`. Behaviour must not change.
  3. Guard background starters in plugins with `if (process.env.DEBUG_RUNNER !== "true")`.
  4. Create `src/workers/registry.ts`; make the cron file call it; add optional `skus` / `limit` filters to the offers-related workers only.
  5. Confirm the build output (`dist/`, CommonJS) works for the runner; if build settings must change, ask (4.4).
  6. Rerun build and tests; compare with the baseline.
  After **each** file change: add `backend:<path>` to `docs/debug-bot/files.txt`.
- **Done when:** build passes; tests match the baseline; every changed file is listed in `docs/debug-bot/files.txt`.
- **Ask if:** anything beyond server bootstrap, plugin start-up guards, cron wiring and the registry (4.4).

### BE10 — Debug runner
- **Guide:** §6.3–6.9
- **Steps:**
  1. `config/environments.yaml` (from BE08) and `src/runner/{config,mask,instrument,child,compress,runner,cli}.ts`, using `paths.ts`. Set the `WATCH` default to this repo's business folders; adapt the DB hook if not Postgres.
  2. Add to `env-templates/backend.env.example` every env var **name** the backend reads at boot (from `generated/env-vars.yaml`), one per line with a blank value and a one-line comment saying what it is (from how the code uses it). Use `NODE_ENV={env}` and similar non-secret defaults where the code makes them obvious. Add any keys the runner needs to `app.env.example`. Then run `env:init` (creates the files or appends the new keys) and `env:check`.
  3. Ask (4.2): "Please fill the empty values in `tools/debug-bot/.env.dev` and `tools/debug-bot/.env.backend.dev` (read-only credentials). Empty keys: <list from env:check>. Tell me when done." Set status `waiting-on-human`, then continue with BE12 and BE13. When the human says done, run `env:check` again; if keys the runner needs are still empty, ask once more with only those names.
  4. After confirmation: build the backend, then run `run-debug -- dev routes`, `-- dev workers`, `-- dev request "<offers route with a test SKU>"`.
- **Done when:** `routes` lists Hapi routes; `request` prints a TRACE with business functions; no secret or PII in the output.
- **Ask if:** a real test SKU/offer/store (4.1); boot needs infrastructure that `DEBUG_RUNNER` can't skip (4.6).

### BE11 — Debug CLI
- **Guide:** §7.1–7.3
- **Steps:**
  1. `src/cli/debug.ts`, `src/runner/catalog.ts`; add `debug`, `catalog` scripts.
  2. Run each §7.3 subcommand against `dev` with `-s`.
  3. `catalog`; add cron schedules to `generated/workers.yaml`.
  4. Confirm `debug db dev "update x set y=1"` is refused without running.
  5. **Prod public mode:**
     - Add a `prod` entry to `config/environments.yaml` with `public_only: true` and the base URLs of the **public** APIs and of the public storefront (from config/docs; ask 4.1 if not found). In `config.ts`, add `PUBLIC_ENVS = ["prod"]` next to `ALLOWED_ENVS`.
     - In `debug.ts`, allow `prod` only for `api` (never send an auth header in prod), `envdiff … api`, and later `page`/`page-api` (FE07).
     - `request`, `worker`, `db`, `cache` and `routes` must refuse `prod` with a clear message.
     - Add to `AGENTS.md`: "prod: public GET endpoints only, via `debug api prod …` or public `curl`."
- **Done when:** every subcommand returns a result or an expected, clear error; the update is refused; `debug api prod <public service> <path>` works without credentials and `debug request prod …` is refused.

### BE12 — Cline instructions
- **Guide:** §7.4–7.5
- **Steps:** 1. Write `AGENTS.md` as in §7.5 (the "give the COMPLETE picture" version), with every command using `npm --prefix tools/debug-bot run -s debug -- …`. 2. Write `.clinerules/ecom-debug.md` (one line pointing to `AGENTS.md`).
- **Done when:** both exist; commands in `AGENTS.md` use `tools/debug-bot` paths.

### BE13 — Search
- **Guide:** Phase 9
- **Steps:** 1. `src/search/options.ts`, `src/search/index.ts`; `index` script; run. 2. Test `debug search` with three glossary words; add synonyms and rerun until each finds a relevant function in the top 5.
- **Done when:** all three searches succeed.

### BE14 — Observability (optional)
- **Guide:** Phase 8
- **Steps:** 1. Ask once (4.4): "Phase 8 adds OpenTelemetry to one job and runs Jaeger in Docker. Do it now, later, or skip?" 2. If now: §8.1–8.4 for the offers-related worker; `config/jobs.yaml`; `profile`. List backend changes in `docs/debug-bot/files.txt` as `backend:<path>`.
- **Done when:** "later/skip" recorded, or Jaeger shows the job trace and `job-outputs.generated.yaml` exists.

### BE15 — Keep knowledge fresh (nightly; hook comes later)
- **Guide:** §10.4 (§10.3 hook and §10.5 CI are **not** done here)
- **Steps:** 1. `nightly` script (extract, flows, stale, index, profile if BE14 done, catalog). 2. **Don't install a git hook now.** The hook is built in track DOC (DOC05: `knowledge:update` + hook template) and installed only when the human asks. 3. Ask (4.4) before adding a crontab entry; if declined, record "nightly run manually".
- **Done when:** `nightly` runs end to end without errors.

### BE27 — One-shot diagnosis (`debug diagnose`)
Running each rule's check one by one costs many tool calls and tokens. This command runs **all** of a flow's checks in one go and prints a short verdict table; Cline only explains it.
- **Steps:**
  1. Extend the rules format (and the `flow-to-rules.md` prompt) with machine-checkable fields per rule, next to the human text:
     ```yaml
     - id: inventory
       meaning: The store must have at least minQty units
       check_in_code: "backend:src/inventory/availability.ts:22 if (qty < minQty) -> return"
       probe: { kind: api, service: inventory, path: "/inventory/{sku}", query: { storeId: "{storeId}" }, pick: "$.availableQty" }
       assert: { op: ge, value: "{config.minQty|1}" }
       fail_reason: OFFER_NO_INVENTORY
       upstream: WORKER inventory-sync
     ```
     - **Probe kinds:**
       - `api`: `debug api`;
       - `public`: a public GET URL;
       - `db`: SQL with `{placeholders}`, `pick` = column;
       - `cache`: key;
       - `page`: FE07;
       - `request`: runner request + `span: "<file>#<fn>"`, `pick` on its return/args;
       - `flow`: run another flow's diagnosis with mapped inputs, used by frontend rules to include the backend route;
       - `manual`: can't be expressed; the human `check` text is used.
     - **Assert ops:** `eq ne lt le gt ge in notin exists missing empty notempty contains notcontains matches within_now`.
     - **`pick`:** a simple JSON path (`$.a.b[0].c`, `$[*].id`).
  2. Backfill the probes and asserts in the rules files from BE08 (offers flow first). Extend `check-rules` to validate the probe/assert shape.
  3. Implement `debug diagnose <flow> --env <env> --<input> <value> … [--only <rules>] [--json] [--save <dir>]`:
     - substitute the inputs;
     - run probes concurrently (max 4);
     - **fetch identical probes once**, since one API call or runner request often feeds several rules;
     - for `request` probes, run the runner **once** per distinct request and read every needed span from that run;
     - evaluate the asserts;
     - for `manual` rules, print the human `check` so Cline can run it;
     - always exit 0.

     Default output is the compact table below (≤ ~40 lines); `--json` is for scripts:
     ```
     diagnose GET /products/{sku}/offers env=stage sku=4455 storeId=12 offerId=OFF-123 | 6 rules, 4 probes, 1 run, 2.1s
     PASS   offer_active  status=ACTIVE, ends 2026-11-30
     PASS   ecom_flag     ecomFlag=Y
     FAIL   inventory     availableQty=0 (need >= 1)          backend:src/inventory/availability.ts:22  upstream: WORKER inventory-sync
     FAIL   stackability  blocked by OFF-099 (stackable=false, priority 10 > 5)  backend:src/offers/stacking.ts:31
     PASS   channel       WEB in [WEB, APP]
     MANUAL segment       run: <check text from the rules file>
     VERDICT HIDDEN - 2 failing rules: inventory, stackability
     ```
  4. `prod`: allowed only if every probe in the run is a public kind; otherwise refuse and list the non-public rules.
  5. Add to both `AGENTS.md` files: "For 'X not showing / wrong', run `debug diagnose` first; investigate further only for FAIL and MANUAL rules."
- **Done when:**
  - diagnosing the offers case runs every rule with at most one runner run and prints the table;
  - ≥ 80 % of the offers rules are machine-checkable (the rest are `manual`, with the reason);
  - the header counts show identical probes were fetched once.

### BE28 — Knowledge index, cards and token budgets (`kb`)
Knowledge is built once and read many times. This task makes reading it cheap.
- **Steps:**
  1. **Router:** write `system-knowledge/INDEX.md` (≤ ~800 tokens). It says what exists, which `debug kb` command answers which kind of question, and lists the **query-only** files that must never be read whole. Each repo's `INDEX.md` points to it.
  2. **Cards:** `kb:build` generates them deterministically into `system-knowledge/kb/cards/`: one per flow, page and important field, each ≤ ~600 tokens, compact:
     ```
     CARD offers.visibility | GET /products/{sku}/offers | src 3f2a1c | ~420 tokens
     inputs: env, sku, storeId, offerId
     run: debug diagnose GET_products_sku_offers --env <env> --sku <sku> --storeId <id> --offerId <id>
     rules: offer_active > ecom_flag > inventory > channel > stackability > segment
       inventory     qty >= minQty             backend:src/inventory/availability.ts:22  probe api inventory  SILENT
       stackability  no higher non-stackable   backend:src/offers/stacking.ts:31         probe request
     upstream: product_offers <- WORKER offer-publisher (hourly); cache offers:{sku} ttl 300s
     prod: public api offers, catalog; logs: runbooks/GET_products_sku_offers.md
     findings: F-12 status PAUSED unhandled (data, stage, 2026-10-28)
     incidents: 2026-11-02-offer-hidden-stacking
     more: kb show flow:GET_products_sku_offers | kb show rule:GET_products_sku_offers.inventory | lineage
     ```
     Cards hold only ids, one-line meanings and pointers; details stay in the source files.
  3. **Index:** `kb:build` writes `system-knowledge/kb/index.json` and a small MiniSearch file `kb/search.json` over titles, summaries and tags.
     - One entry per knowledge item across all repos: flows, rules, routes, pages, modules, tables, endpoints, cache keys, topics, fields, findings, runbooks, incidents and doc pages.
     - Entry shape: `{ id, kind, title, repo, path, line, summary (≤ 120 chars), tokens, tags, links }`.
     - Stable ids: `flow:<name>`, `rule:<flow>.<id>`, `table:<name>`, `field:<node id>`, `finding:F-<n>`, `incident:<slug>`.
  4. **Query commands** in `debug.ts` (default output ≤ ~1,500 tokens; `--full` lifts it):
     - `kb find <words> [--kind <k>] [--limit 8]` → lines `id | kind | summary | path:line | ~tokens`;
     - `kb card <flow|page|field>`;
     - `kb show <id> [--section <name>]` prints only that entry or that section of its file;
     - `kb refs <id>` lists links in and out;
     - `kb similar "<question>"` finds the closest past incidents and cards.
  5. **Compact output everywhere:**
     - switch every `debug` command from pretty JSON to compact lines (`key=value`, aligned tables, no repeated keys);
     - truncate long arrays with a count (`… 37 more`);
     - keep `--json` for scripts.
  6. **Incident memory:** after the human confirms a diagnosis, Cline writes `system-knowledge/incidents/<date>-<slug>.md` (≤ ~400 tokens: symptom, inputs, failing rules with values, root cause, fix/owner, card ids) and runs `kb:build`. `kb similar` finds it next time, so a repeat problem costs one command.
  7. **Budgets (`kb:check`):** approximate tokens = characters / 4.
     - Limits: system INDEX ≤ 800, repo INDEX ≤ 1,500, card ≤ 600, incident ≤ 400, module summary ≤ 600, rules file ≤ 2,500, doc page ≤ 2,000.
     - AI-written files over budget fail the check (split or shorten them).
     - Generated files over 4,000 tokens must be listed as query-only in the router.
     - Print the 10 largest files.
     - Run `kb:check` together with `check-rules`; later `knowledge:update` runs it too.
  8. **Reading protocol:** replace the generic "start with INDEX.md" lines in both `AGENTS.md` files with:
     ```
     Token rules - follow in order and stop as soon as the answer is supported:
     1. debug kb similar "<question>"            reuse a past incident if it matches
     2. debug kb card <flow|page|field>          (debug kb find <words> to get the id)
     3. debug diagnose ...                       live data in one call; dig only into FAIL / MANUAL rules
     4. Code: read only the cited lines, with a range (±15 lines). Don't open whole files you weren't pointed to.
     5. Never read query-only files whole (graph.json, call-graph.json, symbols.yaml, catalog.yaml, spans.jsonl,
        export/*): use debug kb, debug lineage, debug search.
     6. Answer in the fixed table format; after the human confirms, write the incident and run kb:build.
     ```
- **Done when:**
  - `kb:build` and `kb:check` pass;
  - the offers card is ≤ 600 tokens and enough to start a diagnosis;
  - `kb find stacking` returns the stackability rule first;
  - a full offers diagnosis takes ≤ ~10 tool calls, with reads (kb output + diagnose output + code lines) under ~15k tokens.

  Record the numbers under *Evidence*.

### BE16 — End-to-end acceptance
- **Guide:** §7.6
- **Steps:** 1. Ask (4.1) for one real case: env (dev, or stage if approved), SKU, offer id, store id, and whether the offer should show. 2. Answer "Offer <id> is not showing for SKU <sku> in <env>, store <store>. Why?" by following `AGENTS.md` only (token rules: card → `debug diagnose` → cited code lines). 3. Ask the human to confirm the verdict; if wrong, find the faulty rule/check/pattern, fix it, and repeat.
- **Done when:** the answer has the rule table (rule | value | pass/fail | file:line | upstream), every rule in the offers rules file was checked, the human confirms the verdict, and the tool calls and approximate tokens used are recorded under *Evidence* (target: ≤ ~10 calls, < ~15k tokens read). Write the incident (BE28).

### BE17 — Logger profile
- **Guide:** §11.1
- **Steps:** 1. Find the corporate Winston wrapper (imports of the logger in `src/`, then its package in `node_modules`). Read its exported API (how a logger is created, `child()`, method names, argument order) and how it formats output (field names, where metadata goes, correlation id, service name, version). 2. Find two or three real call sites in `src/`. 3. Write `.knowledge/logs/logger.yaml` (§11.1 shape).
- **Done when:** `logger.yaml` exists; under *Decisions*, note whether the wrapper adds a correlation id and an app version (if not, they go into the BE20 suggestions).

### BE18 — Log catalog and silent gates
- **Guide:** §11.2
- **Steps:** 1. Extend `src/extract/flows.ts` as in §11.2 (logger detection, `[SILENT]` / `[throws]` marks, `logs` and `silent_gates` in each flow, `.knowledge/logs/catalog.yaml`). 2. Run `flows`. 3. If the catalog misses calls you saw in BE17, fix `call_patterns` in `logger.yaml` and rerun.
- **Done when:** `catalog.yaml` lists the call sites from BE17; the offers flow has `summary.logs` and `summary.silent_gates`.

### BE19 — OpenSearch field mapping
- **Guide:** §11.3
- **Steps:** 1. Ask (4.1) once, together: the OpenSearch Dashboards URL (no credentials), the index patterns per environment, the value of the service field for the API and for the workers, and one sample log document per service copied from Discover. 2. Write `.knowledge/logs/opensearch.yaml` from the answers and the BE17 output fields. Use `.keyword` sub-fields for `level_agg` / `reason_agg` if the sample shows text fields.
- **Done when:** `opensearch.yaml` exists and every field it names appears in the sample documents.

### BE20 — Prod runbooks, dashboards and logging gaps
- **Guide:** §11.4–11.6
- **Steps:**
  1. Create `src/logs/generate.ts` (§11.4), add the `logs` script, run `flows` then `logs`.
  2. Add `npm run logs` to the end of the `nightly` script.
  3. Ask (4.1): "Please paste step 1 of `.knowledge/runbooks/<offers flow>.md` into Discover with a real SKU and a time range when it was requested. Does it find log lines? Then import `.knowledge/logs/dashboards/<offers flow>.ndjson` in a **non-prod** OpenSearch Dashboards (Dashboards Management → Saved objects → Import). Does it load without errors?" If something fails, fix `opensearch.yaml` or the generator (or use an exported chart as the template, §11.5) and ask again.
  4. Write `.knowledge/logs/suggested-log-lines.md`: for each `[SILENT]` gate in the offers flow and its upstream workers, one log line in the wrapper's syntax with a reason code and the ids in scope, plus correlation id / app version suggestions from BE17. **Do not change backend code** (4.4); this file is for the team's code review.
  5. Add to `AGENTS.md`, under the debugging steps: "For prod issues: never run the backend, workers, DB or cache against prod. Read the public prod data directly (`debug api prod …`, `debug page prod …`, public `curl`), compare it with stage (`debug envdiff stage prod api …`), and give the steps from .knowledge/runbooks/<flow>.md with the user's values filled in for the logs; ask the user to paste back the log results."
- **Done when:** the human confirms the runbook query finds log lines and the dashboard imports (or a skip is recorded with the reason); `gaps.md` and `suggested-log-lines.md` exist.

### BE21 — Caches and queues in the flow maps
- **Guide:** §12.1
- **Steps:** 1. Check how the code uses Redis/caches and queues/topics (client names, wrapper methods); adapt `CACHE_RECV` / `MQ_RECV` and the method lists. 2. Extend `flows.ts` as in §12.1; run `flows`. 3. Add the §12.1 line to `.knowledge/prompts/flow-to-rules.md`. 4. If the offers flow now shows cache keys or topics, rerun `flow-to-rules` for it and `check-rules`.
- **Done when:** `_data-links.yaml` contains the cache keys and topics you found in the code (or *Decisions* records that the code uses none); the offers rules file includes them where relevant.

### BE22 — Env diff and cache reads
- **Guide:** §12.2–12.4
- **Steps:**
  1. Refactor `debug.ts` (`apiGet`, `dbSelect`, `flatten`) and add `envdiff`; update `USAGE`. Rerun the BE11 checks for `api` and `db`.
  2. If BE21 found cache usage: install `ioredis`, add the `cache` subcommand, add `{ENV}_REDIS_URL_READONLY=` to `env-templates/app.env.example`, run `env:init` and `env:check`, and ask (4.2) the human to fill it with a **read-only** Redis user. If no cache is used, skip this step and record it.
  3. Add the §12.4 lines (envdiff, cache, topics) to `AGENTS.md`.
- **Done when:** `debug envdiff dev qa api <service> <path>` prints only differing fields; `debug cache dev "x:*"` is refused; if Redis credentials were provided, `debug cache dev <real key>` prints type, TTL and value.

### BE23 — Data policy and sample cases
- **Steps:**
  1. Create `tools/debug-bot/config/data-policy.yaml`. It governs every data observation (SDD §2.14):
     ```yaml
     envs_allowed: [dev, stage, qa]   # full observation: DB, APIs, cache, runner (BE03)
     public_envs: [prod]              # public GET endpoints only: no DB, no cache, no runner
     max_rows_per_query: 200
     max_cases_per_flow: 6
     retention_days: 30               # observations older than this are listed in STALE.md
     store_raw_values_for: "*"        # all fields: no personal data in these systems (BE03)
     never_store: "password|secret|token|apikey|api_key|authorization|cookie"   # credentials-like fields, always masked
     max_value_bytes: 2000            # truncate very large values
     ```
     If a field ever turns out to be sensitive, add it to `never_store`; observations then keep only its shape and statistics.
  2. Design sample cases per key flow in `tools/debug-bot/config/samples.yaml`. Use the rules files to see which gates matter, then find real inputs with `debug db` / `debug api` in an allowed env:
     - one case where the item shows;
     - one case per main gate that blocks it (no stock, ecomFlag off, stacking conflict, expired…).
     ```yaml
     flows:
       GET_products_sku_offers:
         - { case: visible,        env: dev, inputs: { sku: "4455", storeId: "12", offerId: "OFF-123" }, expect: visible }
         - { case: no-stock,       env: dev, inputs: { sku: "5521", storeId: "12", offerId: "OFF-123" }, expect: hidden, gate: inventory }
         - { case: stacking-block, env: dev, inputs: { sku: "6310", storeId: "12", offerId: "OFF-200" }, expect: hidden, gate: stackability }
       WORKER_offer_publisher:
         - { case: one-sku, env: dev, inputs: { skus: ["4455"] }, expect: publishes }
     ```
  3. Show the proposed cases to the human once (4.1) and ask them to confirm, correct or add cases.
- **Done when:** both files exist; each key flow has ≥ 3 confirmed cases covering pass and fail of its main gates (or the reason why not is recorded).

### BE24 — Data knowledge (`data:observe`)
- **Guide:** §8.4 (profiler) for the table part
- **Steps:**
  1. Create `src/data/observe.ts` and add `"data:observe"`. For each env in `envs_allowed` (and, for downstream/public endpoints only, each env in `public_envs`), using only the read-only functions of the `debug` CLI (`dbSelect`, `apiGet`, cache read), it writes the following to `.knowledge/data/observed/`, each file with `source: data`, `env`, `observed_at`, `sample_size`:
     - **Tables:** every table in the backend flows' `summary.data` and `_data-links.yaml`. Per column (from `information_schema`): type, approximate row count, null %, approximate distinct count, min/max for numbers and dates, and the top 10 values for low-cardinality columns in `store_raw_values_for`. Sampled queries only (`LIMIT` / `TABLESAMPLE`), within `max_rows_per_query`.
     - **Downstream endpoints:** every `ds:` call in the key flows, called with the sample-case inputs. Records the response **shape** (JSON paths, types, presence % across cases) and example values only for allowed fields.
     - **Cache keys:** for the keys in `_data-links.yaml` with sample inputs: type, TTL and whether the key exists.
     - **Config/flag tables:** current values of allowed fields.
  2. Compare code with data and write `.knowledge/data/findings.md`. Each finding gets the evidence from both sides (code `file:line`, data file + env + date) and a severity:
     - status/enum values in the data that no gate or `switch` in the code handles;
     - fields the code reads that are missing or mostly null in the data;
     - response fields the code never reads;
     - columns that are always null;
     - unusually long cache TTLs;
     - and profile differences between environments, especially **stage vs prod** for the public endpoints ("works in stage, not in prod").
  3. Enrich `.knowledge/data/data-dictionary.yaml` with observed meaning and typical values (`source: data`) next to the code-based entries (`source: code`).
  4. Run `scan` (or a check for credential-like values until DOC05 exists) on `.knowledge/data/`.
- **Done when:** observed files exist for every table, endpoint and cache key of the offers flow (endpoints also for prod where public); `findings.md` lists findings or says "none"; no credentials are stored.

### BE25 — Observed flow behaviour (`observe:flows`)
- **Steps:**
  1. Runner capture:
     - add `--save <dir>` to `debug request` and `debug worker`;
     - with `TRACE_FULL=1`, `instrument.ts` also stores full args/returns and downstream bodies, masked per `data-policy.yaml` and capped at 20 KB each, next to the short versions used for the printed trace;
     - `child.ts` writes `spans.jsonl` (name, parent, args, return, downstream events, DB statements) and `response.json` to the save dir.
  2. Create `src/data/observe-flows.ts` and add `"observe:flows"`. For every case in `samples.yaml`:
     - run the request or worker with `--save .knowledge/observed/flows/<flow>/<case>/`;
     - for each rule in the flow's rules file, find the spans of the function at its `check_in_code` and record the outcome (`pass`/`fail`/`not reached`) and the value seen;
     - write `<case>/summary.yaml`.
  3. Maintain an `observed:` block under each rule in the rules files (`{ case, env, observed_at, value, result }`), written only by this script. Compare each case's outcome with its `expect`: a mismatch is a finding (`findings.md`, e.g. "case no-stock expected hidden at inventory, observed visible").
- **Done when:** every case of the offers flow has `spans.jsonl`, `response.json` and `summary.yaml`; its rules file shows observed results; every mismatch is investigated or listed.
- **Ask if:** a case can't run in an allowed env (ask for another sample, 4.1).

### BE26 — Hand-over report
- **Steps:** 1. Write *Summary* in the progress file: what was built (code and data knowledge), token numbers from BE16/BE28, the top findings from `findings.md`, decisions, open `UNCLEAR:` items, known gaps, skipped tasks, the suggested log lines for the team, and the prompts for the team: `Follow AGENTS.md. <question>` for stage/qa issues and `Follow AGENTS.md. Prod issue: <question>` for prod. 2. Run `pack` and report the bundle path.
- **Done when:** summary written; every task ticked or marked skipped with a reason; bundle created.

---

## Order within track BE

```
BE00 → BE01 → BE02 → BE03 → BE04 → BE05 → BE06 → BE07 → BE08
BE08 → BE09 → BE10 → BE11 → BE27 ┐
BE08 → BE12                      ├→ BE28 → BE16 (core done)
BE08 → BE13                      ┘
BE16 → BE17 → BE18 → BE19 → BE20 ┐
BE16 → BE21 → BE22               ┤
BE16 → BE23 → BE24 → BE25        ┴→ BE26
BE14: optional, any time after BE09        BE15: after BE08 and BE09
```

BE17–BE22 extend the core bot (prod logs, config differences, caches, queues). Do them after BE16 passes. BE19 and BE20 wait on the human (sample documents, a Discover test, a dashboard import), so work on BE21–BE22 while waiting.

While waiting on the human, continue with any task whose dependencies are done, and note the wait under *Waiting on the human*. BE12 and BE13 need no secrets, so do them while BE10 waits for the `.env` files.

