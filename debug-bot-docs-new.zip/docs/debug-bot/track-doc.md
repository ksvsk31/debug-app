# Track DOC — Documentation, automatic updates and export

**Purpose:** turn all knowledge (every repo + cross-repo) into clear, human-readable pages for Confluence; keep knowledge, pages and exports up to date automatically when code changes (ready for a git pre-commit hook later); and export everything in formats an MCP server, an LLM, or Vertex AI can load directly.
**Prerequisites:** BE16. Pages for the frontend and lineage are added as those tracks finish (the builder loops over whatever exists).
**Rules:** everything in `sdd.md` applies. Publishing to Confluence and installing git hooks need explicit approval (4.3, 4.4).

## Outputs and end state

```
<backend>/system-knowledge/
  docs/
    docs-config.yaml        # Confluence target, page tree root, diagram mode (DOC00)
    templates/              # page templates + style guide (DOC01)
    _prose/<page-id>.md     # explanations written by Cline, reviewed by humans (DOC03) - never overwritten by scripts
    pages/<page-id>.md      # built pages: front matter + prose + generated tables/diagrams (DOC02)
    html/                   # local static preview of all pages (DOC02)
  confluence/
    pages.yaml              # page tree + Confluence page ids after publishing
    <page-id>/page.xhtml    # Confluence storage format
    <page-id>/*.svg         # diagrams as attachments
  export/                   # (DOC06) manifest.json, documents.jsonl, chunks.jsonl, graph.json, llms.txt, llms-full.txt, README.md
  STALE.md                  # every AI-written part that needs refreshing, across all repos (DOC05)
  prompts/                  # page-prose.md and other shared prompts
<backend>/tools/debug-bot/
  src/docs/ (build.ts, confluence.ts, publish.ts)   src/update/ (update.ts, scan.ts)   src/export/ (export.ts)
  hooks/pre-commit          # hook TEMPLATE, installed only when the human asks (DOC05)
```

**Definition of done (DOC07):**
- the human reads three generated pages and confirms they're clear;
- a code change followed by `knowledge:update` updates the affected flow, page and export, and lists the AI-written parts to refresh;
- `knowledge:export` produces files that load into the target formats without edits.

---

## Tasks

### DOC00 — Documentation targets
- **Steps:**
  1. Look for existing docs to link rather than duplicate (READMEs, ADRs, `docs/` folders, API specs) in every registered repo.
  2. Ask the human once (4.1, 4.3): Confluence **Cloud or Data Center/Server**; base URL (no credentials); space key; title of the parent page to put everything under; whether the Mermaid macro is installed (otherwise diagrams become SVG images); who reviews pages; whether publishing through the API is allowed (default: **no**, generate only).
  3. Write `system-knowledge/docs/docs-config.yaml` with the answers.
- **Done when:** `docs-config.yaml` exists; publishing is recorded as allowed or not under *Decisions*.

### DOC01 — Page tree, templates and style guide
- **Steps:** Write `system-knowledge/docs/templates/` with the page tree, one template per page kind, and `style.md`.
  - **Page tree** (each node is a page; the builder fills in one page per item):
    ```
    <Parent page>
      eCommerce platform - how it works        (home: what the system does, big-picture diagram, how to use these pages)
        Architecture                           (repos, services, downstream systems, data stores, environments, diagram)
        How to debug                           (playbooks: offer not showing, value wrong on a page, works in qa not stage,
                                                prod issue via OpenSearch; the debug CLI reference)
        Backend
          Modules / <module>
          Flows / <route or worker>            (one page per flow)
          Data / tables, jobs, cache keys, topics, data links
          Prod runbooks / <flow>
        Frontend                                (after track FE)
          Packages / <package>
          Pages / <page>                        (one page per page/route)
          Frontend <-> backend links
        Data lineage                            (after track LN)
          <field>                               (one page per important field: chain, diagram, how to debug)
        Glossary
        Knowledge change log                    (what changed in each update)
    ```
  - **Template for every page:** front matter (`id`, `title`, `parent`, `kind`, `sources` (files + hashes), `generated_at`, `prose_hash`), then the sections:
    1. **Summary:** 2–3 sentences anyone can understand.
    2. **Who needs this.**
    3. **How it works:** numbered steps and a diagram.
    4. **Rules and decisions:** table.
    5. **Data in and out.**
    6. **Depends on / used by:** links.
    7. **What can go wrong and how to debug it:** commands and runbook links.
    8. **Example (observed):** a real sample case with non-personal values, taken from the observed data, with env and date.
    9. **Code vs data:** findings where the data disagrees with what the code expects.
    10. **Source:** code locations and data observations.

    Sections that don't apply are left out.
  - **`style.md`:** plain words; define each term on first use and link it to the glossary; sentences under 25 words; one idea per paragraph; explain *why*, not only *what*; numbers and names instead of adjectives; no customer data; mark anything unconfirmed as `UNCLEAR:`.
- **Done when:** templates and `style.md` exist; the tree in `docs-config.yaml` matches.

### DOC02 — Docs builder (`docs:build`)
- **Steps:**
  1. Create `src/docs/build.ts`. For every page in the tree, build the generated parts from knowledge files (flow summaries, gates, rules tables, data links, runbook steps, lineage chains, glossary), the **observed data** (profiles, example values, gate outcomes per sample case, observed lineage with real values, labelled with env and date) and the code-vs-data findings, and insert the prose from `_prose/<page-id>.md`. Missing prose → a visible placeholder plus a `STALE.md` entry. Prose written from older sources (its `source_hash` differs) → keep it, flag it in `STALE.md`.
  2. Diagrams: keep the Mermaid source in the page. Also render SVGs with `@mermaid-js/mermaid-cli` as a dev dependency of the tool. If it can't install or run (it needs a headless browser), ask (4.4) or fall back to the Mermaid macro / code block, per `docs-config.yaml`.
  3. Build a static HTML preview in `docs/html/` (an index plus one file per page, links working) so pages can be read locally before any publishing.
  4. Add `"docs:build"`.
- **Done when:** pages exist for every backend module and flow (plus frontend and lineage pages if those tracks are done); the preview opens in a browser and the links work.

### DOC03 — Write the explanations (prose)
- **Steps:**
  1. Save `system-knowledge/prompts/page-prose.md`: for one page id, read the page's sources (knowledge files, plus code only at cited lines), follow the template and `style.md`, and write `_prose/<page-id>.md` with `generated_by: cline` and the `source_hash`. Never invent; mark gaps `UNCLEAR:`.
  2. Write prose in this order: home → Architecture → How to debug → offers flow pages → modules → the rest. Log each page in *Step log* (resumable).
  3. After the first three pages, ask the human (4.1) once: "Please review these three pages in the preview. Is the depth and tone right? What should change?" Update `style.md` with the answer, rewrite those three, then continue.
  4. Run `docs:build`.
- **Done when:** every page has prose that isn't stale; `STALE.md` has no docs entries; the human approved the sample pages.

### DOC04 — Confluence output and publishing
- **Steps:**
  1. `src/docs/confluence.ts` (`docs:confluence`): convert every built page from Markdown (via the `marked` lexer) to **Confluence storage format**:
     - headings, paragraphs, lists and tables → XHTML;
     - code blocks → `code` macro (`<ac:structured-macro ac:name="code">` with a `language` parameter and the code in CDATA; split any `]]>` in the code);
     - Mermaid → `<ac:image><ri:attachment ri:filename="<name>.svg"/></ac:image>` (or the Mermaid macro if installed);
     - links between pages → `<ac:link><ri:page ri:content-title="<title>"/></ac:link>`;
     - `UNCLEAR:` lines → a `warning` macro.

     Write `confluence/<page-id>/page.xhtml`, its SVGs, and `confluence/pages.yaml` (tree, titles, content hashes).
  2. `src/docs/publish.ts` (`docs:publish`). The **default is `--dry-run`**: compare content hashes with `pages.yaml` and print what would be created, updated or left unchanged. A real publish runs only when the human says "publish to Confluence" in the current session (4.3).
     - Endpoints: REST API v1, `/wiki/rest/api/content` on Cloud and `/rest/api/content` on Data Center.
     - Create: `type: page`, `space.key`, `ancestors`, `body.storage`.
     - Update: `PUT /content/{id}` with `version.number + 1`.
     - Attachments: `POST /content/{id}/child/attachment` with header `X-Atlassian-Token: no-check`.
     - Store page ids in `pages.yaml`, so reruns update instead of duplicating.
     - Never delete pages; list orphans instead.
  3. Credentials: extend `env-init` so a template named `<name>.shared.env.example` produces a single `.env.<name>` (not one per environment). Add `confluence.shared.env.example` with `CONFLUENCE_BASE_URL=`, `CONFLUENCE_USER=`, `CONFLUENCE_API_TOKEN=` (Cloud) / `CONFLUENCE_PAT=` (Data Center), and ask (4.2) the human to fill them only when publishing is approved.
  4. First real publish goes under a **test parent page**. Ask the human to check the rendering, then publish under the real parent.
- **Done when:** `docs:confluence` output exists and the dry-run is correct; if publishing is approved, the test pages render correctly according to the human.

### DOC05 — Automatic knowledge updates (`knowledge:update`) and the hook template
- **Steps:**
  1. Create `src/update/update.ts` with `knowledge:update [--changed <files…> | --staged | --since <git ref> | --all] [--fast]`:
     1. Find changed files: the arguments, or `git diff --cached --name-only` for `--staged`, or `git diff --name-only <ref>`; map each to its repo via `repos.yaml`.
     2. Work out what they affect: modules (by folder), flows (files each flow touches), links, lineage edges with `at` in those files, doc pages whose `sources` include them, runbooks.
     3. Regenerate the deterministic parts for what's affected: `extract`, `flows`, `logs`, `links`, `lineage:build`, `docs:build`, `docs:confluence`. A step that can't run incrementally simply runs in full.
     4. Update `system-knowledge/STALE.md` with every **AI-written** part whose sources changed (module summaries, rules files, page prose, manual lineage edges), each with the reason and the prompt to rerun it.
     5. Rebuild `kb:build` (index, cards) and run the checks: `check-rules`, `kb:check` (token budgets), `lineage:check`, and the secret/PII scan (step 2) over all knowledge, docs and export files.
     6. Append an entry to the knowledge change log page and print a short summary.
     7. Exit non-zero only if a check fails (broken pointer, secret or PII found), **not** because something is stale.
  2. `src/update/scan.ts`: fail on likely secrets (personal data isn't expected in these systems, but the email/phone patterns stay as a safety net). Patterns:
     - emails, phone numbers;
     - JWTs, `Bearer` tokens;
     - connection strings with passwords (`://user:pass@`);
     - AWS keys (`AKIA…`), private key blocks;
     - long random strings next to words like token/secret/password/key.

     Allow-list known safe patterns in `scan-allow.yaml`.
  3. **Data knowledge is refreshed on a schedule, not by commits:** the nightly run (and `knowledge:update --all`) runs `data:observe`, `observe:flows` and `lineage:observe` in the allowed envs. Observations older than `retention_days` (data policy) are listed in `STALE.md`. A code change that affects a flow also marks that flow's observations stale, so they're re-run.
  4. `--fast` mode for the hook: only `extract` + `flows` + `check-rules` + `scan` for the changed repo, under ~30 seconds. Everything else is left to the nightly job.
  5. Write `tools/debug-bot/hooks/pre-commit` as a **template only** (POSIX `sh`): run `knowledge:update --staged --fast`, then `git add` the regenerated knowledge files of that repo, and block the commit only on failed checks. Add `hooks/README.md` with install instructions per repo (`core.hooksPath` or Husky) and how to skip in an emergency (`--no-verify`). **Install it only when the human asks** (4.4).
  6. Replace the `nightly` script steps with `knowledge:update --all`.
  7. Document in `hooks/README.md` how AI-written parts will be refreshed automatically later: when an LLM API, MCP server or Vertex is available, a `knowledge:refresh` command can read `STALE.md` and run each listed prompt through the API. Until then, Cline runs them when asked: "refresh everything in system-knowledge/STALE.md".
- **Done when:** after changing a backend file, `knowledge:update --changed <file>` regenerates the affected flow and page, lists the affected AI-written parts in `STALE.md`, and finishes in under ~30 s with `--fast`; the scan catches a planted fake email in a scratch file (then delete it); the hook template exists and is **not** installed.

### DOC06 — Export for MCP servers, LLMs and Vertex AI (`knowledge:export`)
- **Steps:**
  1. Create `src/export/export.ts` (`knowledge:export [--out <dir>] [--since <previous manifest.json>]`). It reads every registered repo's `.knowledge/` (including observed data and findings), `system-knowledge/` and the built docs, and writes to `system-knowledge/export/` (or `--out`):
     - `manifest.json`: one entry per document: `id` (stable: repo + relative path), `title`, `kind` (index, module, flow, rules, runbook, lineage, doc-page, glossary…), `repo`, `path`, `sha256`, `updated`, `approx_tokens`, `priority` (1 = router and cards, 2 = rules, flows, incidents, findings, 3 = everything else), `sources`, `links` (ids of related documents), and `source: code | data | both` with `env` and `observed_at` for data.
     - `documents.jsonl`: one line per document: `{ id, title, kind, repo, text, metadata }`. Text is Markdown; YAML/JSON knowledge is included as-is in a fenced block plus a one-line description.
     - `chunks.jsonl`: documents split by headings into ~800-token chunks with one paragraph of overlap: `{ id: "<doc id>#<heading-slug>#<n>", doc_id, heading_path, text, metadata }`. Ready for embeddings and vector search in any RAG system.
     - `graph.json`: flows, data links, HTTP links and lineage as one node/edge graph, for graph tools and MCP tools.
     - `llms.txt`: an index in the llms.txt style (title, one-line summary, link per document), with the router and cards first, and `llms-full.txt` (all documents concatenated with clear separators), for tools that take a single file.
     - `deleted.json` when `--since` is used: documents removed since the previous export.
     - `README.md`: how to load the export, written for the person doing it:
       - **MCP server:** expose `debug kb` (find, card, show, similar), `debug diagnose`, `debug lineage` and the other `debug` subcommands as tools (cheap tools first), and `manifest.json` documents as resources, priority 1 first. Same read-only rules.
       - **Vertex AI** (Vertex AI Search or RAG Engine): upload `documents.jsonl` or the per-document files to a Cloud Storage bucket and import them as a data store / corpus, with metadata fields from `manifest.json`.
       - **Any LLM or vector DB:** embed `chunks.jsonl` and keep `doc_id` for citations.
  2. Run `scan` on the export; it must pass.
  3. Make ids stable: run the export twice and compare the manifests; only changed documents should differ.
- **Done when:** all files are written; every JSONL line parses; counts and token totals are recorded under *Evidence*; the scan is clean; the second run with `--since` lists only actual changes.

### DOC07 — Acceptance
- **Steps:**
  1. Ask (4.1) the human to read three pages (home, How to debug, one flow page) in the preview or test Confluence space and confirm they're clear.
  2. On a scratch branch (or a temporary copy of one file), change one gate in a backend flow, run `knowledge:update --changed <file>`, and show that the flow file, its page, `STALE.md` and a fresh export reflect the change; then revert.
- **Done when:** the human confirms clarity and the update demo works.

### DOC08 — Hand-over
- **Steps:** Write the DOC summary (pages built, how to rebuild, how to publish, how to install the hook later, how to export and where each format goes) and run `pack`.
- **Done when:** summary and bundle exist.

---

## Order within track DOC

```
DOC00 → DOC01 → DOC02 → DOC03 → DOC04 ─┐
                  DOC05 → DOC06 ───────┴→ DOC07 → DOC08
```

DOC00–DOC03 can run as soon as BE16 is done (backend pages). Rerun `docs:build` and DOC03 for new pages after FE and LN finish; DOC05–DOC06 cover all repos automatically.
