# Track LN — Field lineage (DB → downstream → backend → frontend → UI)

**Purpose:** trace every property end to end, **from both the code and real data**, so any field on a page can be followed back to its database column or downstream API field (and forward from a column to every page that shows it), with the code location of each hop.
**Prerequisites:** FE05 (frontend linked to backend). LN00, LN01, LN04 (needs BE25) and LN05 can start after BE16 to get backend-only lineage early.
**Rules:** everything in `sdd.md` applies. References like "(4.1)" point to SDD §4.
**Code reference:** reference code below (LN01–LN02). It was written for this design and has **not** been run against your repos; adapt it to what discovery found and record changes under *Decisions*.

## Outputs and end state

```
<backend>/system-knowledge/lineage/
  schema.md            # node ids, edge kinds, confidence levels (LN00)
  graph.json           # all nodes and edges, every repo + joins (LN03)
  fields-index.yaml    # field name -> node ids, for quick lookup
  manual-edges.yaml    # edges added by Cline/humans with evidence (LN06)
  observed-edges.yaml  # links and transformations proved by real values (LN04)
  review.yaml          # where code and data disagree (LN04)
  unresolved.yaml      # hops the scripts couldn't prove, with file:line
<backend>/tools/debug-bot/src/lineage/  (edges.ts, jsx.ts, join.ts, build.ts, query.ts)
```

**Definition of done (LN07):** `debug lineage --ui <Component>.<prop>` prints the full chain from the page element to its sources (DB column and/or downstream field), every hop with code location, confidence and, with `--observed`, the real example values; and Cline uses it to find, for one real "value wrong on page" case, the first hop where the value changes.

### Example of the target output

```
UI      ProductPage > PriceBlock > <Price value>              frontend:apps/web/components/Price.tsx:12      exact
FE      ProductVM.displayPrice <- formatPrice(offer.price)    frontend:libs/data/src/mappers.ts:40           exact
FE      OffersResponse.price  <- GET /products/{sku}/offers   frontend:libs/data/src/offers.ts:18            name-match
ROUTE   GET /products/{sku}/offers#price <- OfferDto.price    backend:src/offers/handler.ts:55               exact
BE      OfferDto.price <- applyDiscount(product.listPrice)    backend:src/pricing/discount.ts:21             exact
DS      GET /products/{sku}#listPrice (catalog-api)           backend:src/catalog/product.ts:9               exact
DB      products.list_price -> written by WORKER product-feed backend:src/workers/productFeed.ts:77         exact
```

---

## Tasks

### LN00 — Lineage model
- **Steps:** Write `system-knowledge/lineage/schema.md` with:
  - **Node ids**
    - `<repo>:<file>#<Type>.<field>`: a field of a declared TypeScript type (e.g. `backend:src/offers/dto.ts#OfferDto.price`)
    - `route:<METHOD> <path>#<field>`: a field in a backend route's response
    - `ds:<METHOD> <url template>#<field>`: a field in a downstream API response (the service name comes from `downstream-calls.yaml` / `environments.yaml`)
    - `db:<table>.<column>`
    - `ui:<repo>:<file>#<Component>.<prop>`: a component prop
    - `render:<repo>:<file>:<line>`: a value rendered as text
    - `fn:<repo>:<file>#<function>.return.<json path>`: a runtime value from a function with no declared return type (observed only)
    - `page:<route>#props.<json path>`: a page prop observed at runtime (Pages Router) or a value found in the RSC payload
    - `?<expression>`: an unresolved source
  - **Edge kinds:** `maps` (object field ← expression), `reads` (DB/downstream → code), `returns` (code → route response), `http` (route response → frontend type), `passes` (JSX attribute → component prop type), `renders` (value → text in JSX), `writes` (code → DB/cache/topic), `transforms` (observed: the value changes between two hops, with examples).
  - **Confidence:** `exact` (proved by types), `pattern` (path match), `name-match` (same field name across a boundary), `spread` (`...obj`), `observed` (same value seen at both ends in ≥ 2 sample cases with different values, LN04), `observed-weak` (one case), `manual` (added in LN06 with evidence), `unresolved`.
  - **File formats** for `graph.json` (`{ nodes: [{id, layer, repo, at}], edges: [{from, to, kind, confidence, at, via}] }`), `fields-index.yaml` and `manual-edges.yaml`.
- **Done when:** `schema.md` exists and matches the code you write in LN01–LN05.

### LN01 — Backend field edges
- **Steps:** 1. Create `src/lineage/edges.ts` from the reference code below, adapted to the backend's HTTP clients (reuse `CLIENT`/`HTTP` from `flows.ts`), data access and response style. 2. Route handlers come from the backend flow files (entry + handler). 3. If Hapi routes declare Joi response schemas (FE01 profile), also read their `Joi.object({...})` keys as route fields and record mismatches between Joi and TypeScript in `unresolved.yaml`. 4. Run it on the backend and inspect the offers route.
- **Done when:** the offers route's response fields have edges back to downstream fields and/or DB columns for at least price, availability and the offer fields; the remaining gaps are in `unresolved.yaml` with file:line.

**Reference code** (`src/lineage/edges.ts`):

```ts
import { SyntaxKind, Node, Type, SourceFile } from "ts-morph";

export type Edge = { from: string; to: string; kind: string; confidence: string; at: string; via?: string };
export type Ctx = { repo: string; rel: (p: string) => string; edges: Edge[] };

const HTTP = new Set(["get", "post", "put", "patch", "delete"]);
const CLIENT = /axios|http|client|api/i;                       // reuse the patterns tuned in flows.ts
const short = (s: string, n = 80) => s.replace(/\s+/g, " ").slice(0, n);
const at = (c: Ctx, n: Node) => `${c.repo}:${c.rel(n.getSourceFile().getFilePath())}:${n.getStartLineNumber()}`;
const isFn = (a: Node) => Node.isArrowFunction(a) || Node.isFunctionExpression(a) || Node.isFunctionDeclaration(a) || Node.isMethodDeclaration(a);

// Id of a user-declared type (unwraps arrays and Promise), or undefined for anonymous/library types
export function typeId(c: Ctx, t?: Type): string | undefined {
  if (!t) return;
  if (t.isArray()) t = t.getArrayElementTypeOrThrow();
  if (t.getSymbol()?.getName() === "Promise") t = t.getTypeArguments()[0];
  if (t?.isArray()) t = t.getArrayElementTypeOrThrow();
  const sym = t?.getAliasSymbol() ?? t?.getSymbol();
  const decl = sym?.getDeclarations()[0];
  if (!sym || !decl || sym.getName().startsWith("__")) return;
  const sf = decl.getSourceFile();
  if (sf.isInNodeModules() || sf.isDeclarationFile()) return;
  return `${c.repo}:${c.rel(sf.getFilePath())}#${sym.getName()}`;
}

// Typed fields read inside an expression: `x.field` where x has a declared type; destructured identifiers too
export function sourcesOf(c: Ctx, expr: Node): string[] {
  const out = new Set<string>();
  for (const pa of [expr, ...expr.getDescendants()].filter(Node.isPropertyAccessExpression)) {
    const t = typeId(c, pa.getExpression().getType());
    if (t) out.add(`${t}.${pa.getName()}`);
  }
  for (const id of [expr, ...expr.getDescendants()].filter(Node.isIdentifier)) {
    const decl = id.getSymbol()?.getDeclarations()[0];
    if (!decl || !Node.isBindingElement(decl)) continue;               // const { listPrice } = product
    const owner = decl.getParent()?.getParent();
    const t = owner && (Node.isVariableDeclaration(owner) || Node.isParameterDeclaration(owner)) ? typeId(c, owner.getType()) : undefined;
    if (t) out.add(`${t}.${decl.getPropertyNameNode()?.getText() ?? decl.getName()}`);
  }
  return [...out];
}

// { price: product.listPrice } where the object has a declared (contextual) type
export function objectEdges(c: Ctx, sf: SourceFile) {
  for (const obj of sf.getDescendantsOfKind(SyntaxKind.ObjectLiteralExpression)) {
    const target = typeId(c, obj.getContextualType() ?? obj.getType());
    if (!target) continue;
    for (const p of obj.getProperties()) {
      if (Node.isPropertyAssignment(p) || Node.isShorthandPropertyAssignment(p)) {
        const value = Node.isPropertyAssignment(p) ? p.getInitializer()! : p.getNameNode();
        const to = `${target}.${p.getName()}`;
        const src = sourcesOf(c, value);
        if (src.length) src.forEach((s) => c.edges.push({ from: s, to, kind: "maps", confidence: "exact", at: at(c, p), via: short(value.getText()) }));
        else c.edges.push({ from: `?${short(value.getText(), 60)}`, to, kind: "maps", confidence: "unresolved", at: at(c, p) });
      } else if (Node.isSpreadAssignment(p)) {
        const s = typeId(c, p.getExpression().getType());
        c.edges.push({ from: s ? `${s}.*` : `?${short(p.getExpression().getText(), 60)}`, to: `${target}.*`, kind: "maps", confidence: s ? "spread" : "unresolved", at: at(c, p) });
      }
    }
  }
}

// What a route handler returns -> route:<METHOD> <path>#<field>
export function routeEdges(c: Ctx, handler: Node, route: string) {
  for (const ret of handler.getDescendantsOfKind(SyntaxKind.ReturnStatement)) {
    if (ret.getFirstAncestor(isFn) !== handler) continue;              // skip returns of nested callbacks
    let e = ret.getExpression();
    if (!e) continue;
    const resp = [e, ...e.getDescendantsOfKind(SyntaxKind.CallExpression)]
      .find((x) => Node.isCallExpression(x) && /\.response$/.test(x.getExpression().getText()));   // h.response(x).code(200)
    if (resp && Node.isCallExpression(resp) && resp.getArguments()[0]) e = resp.getArguments()[0];
    if (Node.isObjectLiteralExpression(e)) {
      for (const p of e.getProperties()) {
        if (!Node.isPropertyAssignment(p) && !Node.isShorthandPropertyAssignment(p)) continue;
        const value = Node.isPropertyAssignment(p) ? p.getInitializer()! : p.getNameNode();
        const src = sourcesOf(c, value);
        const to = `route:${route}#${p.getName()}`;
        (src.length ? src : [`?${short(value.getText(), 60)}`]).forEach((s) =>
          c.edges.push({ from: s, to, kind: "returns", confidence: src.length ? "exact" : "unresolved", at: at(c, p) }));
      }
    } else {
      let t = e.getType();
      if (t.isArray()) t = t.getArrayElementTypeOrThrow();
      const tid = typeId(c, t);
      if (tid) t.getProperties().forEach((pr) => c.edges.push({ from: `${tid}.${pr.getName()}`, to: `route:${route}#${pr.getName()}`, kind: "returns", confidence: "exact", at: at(c, ret) }));
      else c.edges.push({ from: `?${short(e.getText(), 60)}`, to: `route:${route}#*`, kind: "returns", confidence: "unresolved", at: at(c, ret) });
    }
  }
}

// axios.get<CatalogProduct>(`/products/${sku}`) -> ds:GET /products/{sku}#field -> CatalogProduct.field
const normalizeUrl = (s: string) => s.replace(/^[`'"]|[`'"]$/g, "").replace(/\$\{([^}]*)\}/g, (_m, g) => `{${String(g).split(".").pop()}}`);
export function downstreamEdges(c: Ctx, sf: SourceFile) {
  for (const call of sf.getDescendantsOfKind(SyntaxKind.CallExpression)) {
    const e = call.getExpression();
    if (!Node.isPropertyAccessExpression(e) || !HTTP.has(e.getName()) || !CLIENT.test(e.getExpression().getText())) continue;
    const ds = `ds:${e.getName().toUpperCase()} ${normalizeUrl(call.getArguments()[0]?.getText() ?? "")}`;
    let t = call.getTypeArguments()[0]?.getType();
    if (t?.isArray()) t = t.getArrayElementTypeOrThrow();
    const tid = typeId(c, t);
    if (tid && t) t.getProperties().forEach((pr) => c.edges.push({ from: `${ds}#${pr.getName()}`, to: `${tid}.${pr.getName()}`, kind: "reads", confidence: "exact", at: at(c, call) }));
    else c.edges.push({ from: `${ds}#*`, to: `?${short(call.getText(), 60)}`, kind: "reads", confidence: "unresolved", at: at(c, call) });
  }
}

// client.query<Row>("select list_price, sku as id from products ...") -> db:products.list_price -> Row.list_price
export function dbEdges(c: Ctx, sf: SourceFile) {
  for (const call of sf.getDescendantsOfKind(SyntaxKind.CallExpression)) {
    const e = call.getExpression();
    const arg = call.getArguments()[0];
    if (!Node.isPropertyAccessExpression(e) || !/^(query|raw)$/.test(e.getName()) || !arg) continue;
    if (!Node.isStringLiteral(arg) && !Node.isNoSubstitutionTemplateLiteral(arg) && !Node.isTemplateExpression(arg)) continue;
    const m = arg.getText().replace(/\s+/g, " ").match(/select (.+?) from ([\w."]+)/i);
    if (!m) continue;
    const table = m[2].replace(/"/g, "");
    const row = typeId(c, call.getTypeArguments()[0]?.getType());
    for (const col of m[1].split(",").map((s) => s.trim())) {
      const [expr, alias] = col.split(/\s+as\s+/i);
      const column = expr.split(".").pop()!.replace(/"/g, "");
      if (column === "*" || /\(/.test(expr)) continue;               // skip * and functions (record in unresolved)
      const field = (alias ?? column).replace(/"/g, "");
      c.edges.push({ from: `db:${table}.${column}`, to: row ? `${row}.${field}` : `?row.${field}`, kind: "reads", confidence: row ? "exact" : "name-match", at: at(c, call) });
    }
  }
}
```

Known limits (list what you hit in `unresolved.yaml`): untyped (`any`) values, `lodash` `pick`/`omit`/`mapKeys`, dynamic keys (`obj[key]`), ORMs (add an adapter: model field ↔ column), SQL with joins and aliases (only the first `FROM` table is used), GraphQL.

### LN02 — Frontend field edges
- **Steps:** 1. Run `objectEdges`, `downstreamEdges` (for frontend API calls; their url templates use the base URL variable) and the data-function returns (`getServerSideProps` → `props`, server component fetch results) on the frontend repo. 2. Add JSX edges (reference code below). 3. Include client-side transforms: React Query `select`, Redux selectors and mappers are covered by `objectEdges` when their results are typed; otherwise they go to `unresolved.yaml`. 4. Run it and inspect the product page.
- **Done when:** the product page's price and offer badge props have edges back to the frontend API response type.

**Reference code** (`src/lineage/jsx.ts`):

```ts
import { SyntaxKind, Node, SourceFile } from "ts-morph";
import { Ctx, sourcesOf, typeId } from "./edges.js";

const at = (c: Ctx, n: Node) => `${c.repo}:${c.rel(n.getSourceFile().getFilePath())}:${n.getStartLineNumber()}`;

export function jsxEdges(c: Ctx, sf: SourceFile) {
  // <Price value={offer.price} />  ->  ui:<repo>:<file>#Price.value  (+ link to PriceProps.value)
  for (const attr of sf.getDescendantsOfKind(SyntaxKind.JsxAttribute)) {
    const init = attr.getInitializer();
    if (!init || !Node.isJsxExpression(init) || !init.getExpression()) continue;
    const el = attr.getFirstAncestor((a) => Node.isJsxOpeningElement(a) || Node.isJsxSelfClosingElement(a));
    if (!el || !(Node.isJsxOpeningElement(el) || Node.isJsxSelfClosingElement(el))) continue;
    const tagNode = el.getTagNameNode();
    const tag = tagNode.getText();
    if (/^[a-z]/.test(tag)) continue;                                    // DOM element, not a component
    let sym = tagNode.getSymbol();
    if (sym?.isAlias()) sym = sym.getAliasedSymbol() ?? sym;
    const decl = sym?.getDeclarations()[0];
    const comp = decl ? `${c.rel(decl.getSourceFile().getFilePath())}#${tag}` : tag;
    const prop = attr.getNameNode().getText();
    const to = `ui:${c.repo}:${comp}.${prop}`;
    const src = sourcesOf(c, init.getExpression()!);
    (src.length ? src : [`?${init.getExpression()!.getText().slice(0, 60)}`]).forEach((s) =>
      c.edges.push({ from: s, to, kind: "passes", confidence: src.length ? "exact" : "unresolved", at: at(c, attr) }));
    // connect the prop to the component's props type, so the chain continues inside the component
    const fn = decl && (Node.isFunctionDeclaration(decl) ? decl
      : Node.isVariableDeclaration(decl) ? decl.getInitializerIfKind(SyntaxKind.ArrowFunction) ?? decl.getInitializerIfKind(SyntaxKind.FunctionExpression) : undefined);
    const propsType = fn ? typeId(c, fn.getParameters()[0]?.getType()) : undefined;
    if (propsType) c.edges.push({ from: to, to: `${propsType}.${prop}`, kind: "passes", confidence: "exact", at: at(c, attr) });
  }
  // {offer.price} rendered as text
  for (const jx of sf.getDescendantsOfKind(SyntaxKind.JsxExpression)) {
    if (Node.isJsxAttribute(jx.getParent()) || !jx.getExpression()) continue;
    for (const s of sourcesOf(c, jx.getExpression()!))
      c.edges.push({ from: s, to: `render:${c.repo}:${c.rel(sf.getFilePath())}:${jx.getStartLineNumber()}`, kind: "renders", confidence: "exact", at: at(c, jx) });
  }
}
```

Components wrapped in `memo()`/`forwardRef()` or exported as default from another file need one more resolution step; record misses in `unresolved.yaml`.

### LN03 — Join across HTTP and build the graph (`lineage:build`)
- **Steps:**
  1. Make the links builder (FE05) store each side's response type as a `typeId` (same format as LN00).
  2. Create `src/lineage/join.ts`: for every matched link, connect `route:<route>#<field>` to `<frontend response type>.<field>` (kind `http`; confidence `exact` if both sides use the same declared type from a shared package, else `name-match`). One level of nesting is enough at first; deeper JSON paths go to `unresolved.yaml`.
  3. Create `src/lineage/build.ts`: run LN01 on every `hapi` repo, LN02 on every `nextjs` repo, the join, then merge `manual-edges.yaml`; write `graph.json`, `fields-index.yaml` and `unresolved.yaml`; print counts by edge kind and confidence. Add `"lineage:build"`.
  4. Add `lineage:check`: every `at` in `graph.json` and `manual-edges.yaml` points to an existing file and line.
- **Done when:** `lineage:build` and `lineage:check` run cleanly; the counts are recorded under *Evidence*.

### LN04 — Observed lineage from real data (`lineage:observe`)
Static lineage (LN01–LN03) shows what the code **can** do; this task proves what **actually** happens. It uses the saved runs from BE25/FE09 and live reads, follows real values across the layers, and fills the gaps types can't prove.
- **Steps:**
  1. Create `src/lineage/observed.ts` and add `"lineage:observe"`. For every sample case, collect the values at each hop:
     - DB rows for the flow's tables with the case inputs (`dbSelect`);
     - downstream response bodies and every function's args and return (`spans.jsonl`, BE25);
     - the route response (`response.json`);
     - page props, the RSC payload or HTML text (FE09).
     - For prod (public only): public API responses and public pages for the same inputs. These confirm the public end of each chain in prod; DB and internal hops stay non-prod.

     Flatten each into `(json path, value)` pairs.
  2. Map runtime paths to node ids (LN00):
     - DB → `db:<table>.<column>`;
     - downstream → `ds:…#<path>`;
     - a function's return → its declared return type via `typeId` (else `fn:…return.<path>`);
     - route → `route:…#<path>`;
     - page → `page:<route>#props.<path>`;
     - rendered text → `render:` nodes where a `data-testid` or the static graph identifies the component.
  3. Match values across hops:
     - strings: exact;
     - numbers: normalized (units vs cents, rounding to 2 decimals, formatted currency such as `"$19.99"`).
     - Ignore trivial values: null, booleans, empty strings, numbers < 10 unless the field names also match, and values that occur more than 3 times in the same payload.
     - Confidence: a link is `observed` when it holds in ≥ 2 cases with **different** values, `observed-weak` with one case.
  4. Detect transformations: where the static graph links A → B but the values differ, record a `transforms` edge with examples (e.g. `24.99 → 19.99` in `applyDiscount`) and the function between them.
  5. Write `system-knowledge/lineage/observed-edges.yaml` (case ids, env, `observed_at`) and `review.yaml`:
     - static edges contradicted by the data in every case;
     - observed links with no static path (code paths the analysis missed).

     Resolve each review item: fix the scripts, add a manual edge (LN06), or note why.
  6. Make `lineage:build` merge the observed edges, and give `debug lineage` an `--observed` option that shows the example values per hop.
- **Done when:** for the important fields, every hop that has data in the sample cases is confirmed (`observed`) or explained in `review.yaml`; `debug lineage --observed` shows real example values along a full chain.
- **Ask if:** sample cases don't vary enough to tell links apart (e.g. every price is the same); ask for cases with different values (4.1).

### LN05 — `debug lineage` query
- **Steps:** Add `lineage <query> [--up | --down | --both] [--depth n] [--mermaid]` to `debug.ts`. Query forms: a node id; `Type.field` (searched via `fields-index.yaml`); `db:<table>.<column>`; `--ui <Component>.<prop>`; `--search <word>` (lists matching nodes). Output the chain as a table (layer, node, code location, confidence), like the example at the top, and list the unresolved hops. `--mermaid` adds a diagram. Output is compact by default (one line per hop, ≤ ~1,500 tokens; `--full` lifts it). Important fields also get a `kb` card (BE28) with their chain summary.
- **Done when:** `debug lineage --ui Price.value` (or your product page's price component) prints a chain reaching at least the backend route, and `debug lineage db:<a real column> --down` lists the pages that show it.

### LN06 — Close the important gaps
- **Steps:**
  1. Propose the most important fields from the flows and rules (price, availability, offer/badge, delivery promise …) and ask the human once (4.1) to confirm or add to the list.
  2. Save the prompt `system-knowledge/prompts/lineage-gaps.md`: for one field, read its chain and the `unresolved.yaml` entries on it, read the code at those lines, and add the missing edges to `manual-edges.yaml` as `{ from, to, kind, at, reason, confidence: manual, generated_by: cline, source_hash }`, or mark the gap `UNCLEAR:` with what's missing.
  3. Run it for every field on the list; then `lineage:build` and `lineage:check`.
- **Done when:** every listed field has a complete chain (UI → source) or a documented `UNCLEAR:` gap.

### LN07 — Field debugging playbook and acceptance
- **Steps:**
  1. Add to both `AGENTS.md` files: "When a value is wrong or missing on a page: (1) `debug lineage --ui <Component>.<prop>` (or `--search`) to get the chain; (2) get the actual value at each hop from the UI back to the source: page (`debug page --find`), frontend API / backend route (`debug request`), downstream (`debug api` or public `curl`), DB (`debug db`), cache (`debug cache`); (3) the first hop where the value differs from the previous one is where it goes wrong; (4) answer with a table: hop | value | same as previous? | code location."
  2. Ask (4.1) for one real case of a wrong or missing value on a page (env, page, SKU, expected value). Solve it with the playbook. Ask the human to confirm.
  3. Optional, if the frontend has Playwright (FE01): a script that loads a page on dev and checks that a backend value appears in the DOM, to verify chains at runtime.
- **Done when:** the human confirms the verdict for the real case.

### LN08 — Hand-over
- **Steps:** Write the LN summary (graph size, confidence breakdown, important fields covered, remaining gaps) and run `pack`.
- **Done when:** summary and bundle exist.

---

## Order within track LN

```
LN00 → LN01 → LN02 → LN03 → LN04 → LN05 → LN06 → LN07 → LN08
(LN00, LN01, LN04, LN05 for the backend alone can run right after BE16 + BE25)
```
