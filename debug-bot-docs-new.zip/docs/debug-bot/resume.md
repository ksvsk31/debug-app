# Debug bot — start, resume, move machines (card for humans)

Cline's full rules are in `sdd.md`; the tasks are in the `track-*.md` files.

## Files and where they go

Put the whole `docs/debug-bot/` folder into your **backend** repo:

```
<backend repo>/docs/debug-bot/
  sdd.md         master rules (start here)
  track-be.md    backend tasks
  track-fe.md    frontend (Next.js) tasks
  track-ln.md    field lineage tasks
  track-doc.md   Confluence, automatic updates, export tasks
  guide.md       backend build guide with full code
  resume.md      this card
```

Cline creates the rest: `progress.md`, `files.txt`, `tools/debug-bot/`, `system-knowledge/`, `.knowledge/` in each repo, `AGENTS.md`, `.clinerules/`, `.clineignore`, and the VS Code workspace file.

## One-time Cline settings (each machine)

Cline → Auto-approve: **on** for read files, edit files and safe commands; **off** for commands that call a network service or database.

## Start prompt (first run, after any interruption, on a new machine)

New Cline task, **Act** mode, paste:

```
Read docs/debug-bot/sdd.md and execute it. Begin with the session start check (section 3).
Follow the operating rules (section 2) exactly and only ask me what section 4 allows.
```

To steer it, add one line, for example:
- `Work on track FE.` (frontend)
- `Work on track DOC.` (Confluence pages, updates, export)
- `Refresh everything in system-knowledge/STALE.md.` (rewrite outdated summaries, rules and page text)

Where it is now: `docs/debug-bot/progress.md` → *Current position* and *Tracks*.

## If it stops

| What happened | What to do |
|---|---|
| Network dropped, Cline ran out of tokens, VS Code or laptop closed | Start a new Cline task with the start prompt |
| Cline is waiting on you | Answer the questions (also listed under *Waiting on the human* in `progress.md`), then say "continue" |
| Cline asks you to fill env values | It already created the file with every key. Open the file it names under `tools/debug-bot/`, fill the empty keys with **read-only** values, save, say "done". Never paste secrets into the chat. |
| Cline asks you to reopen VS Code (frontend track) | File → Open Workspace from File → `ecom-debug.code-workspace` (in the folder that contains your repos), then start a new Cline task with the start prompt |
| A task keeps failing | Cline asks after two fix attempts. Reply with what you know, or tell it to skip and record why. |

## Environment files (secrets)

All in `<backend>/tools/debug-bot/`. Cline creates them with blank values; you fill and update values whenever needed (e.g. an expired token). It can't read them, and they're never in the bundle.

| File | What goes in it |
|---|---|
| `.env.dev`, `.env.stage`, `.env.qa` | Debug tool's read-only API token, read-only DB URL, Redis URL… per environment |
| `.env.backend.dev`, `.env.backend.stage`, `.env.backend.qa` | Variables the backend needs to start in that environment |
| `.env.confluence` | Confluence URL, user and token (only if publishing is approved) |

`npm --prefix tools/debug-bot run env:check` shows which keys are still empty (names only).

## Move to another machine

**Old machine:** ask Cline `pack the debug bot` (or run `npm --prefix tools/debug-bot run pack` in the backend repo). The bundle `debug-bot-handoff-<date>.tgz` appears in the folder that **contains** your repos. It holds the tooling, progress, docs and knowledge of every registered repo, and the app files the bot changed, but no secrets and no `node_modules`.

**New machine:**
1. Have the same codebases, side by side in one folder, with the **same folder names** as on the old machine (otherwise update the paths in `tools/debug-bot/config/repos.yaml` after extracting).
2. Copy the bundle into that folder and extract it there: `tar -xzf debug-bot-handoff-<date>.tgz`
3. Set the Cline auto-approve settings, open the `ecom-debug.code-workspace` (or the backend repo if the frontend track hasn't started), and start Cline with the start prompt. It reinstalls dependencies, recreates the env files with blank values and tells you which to fill, then continues where it stopped.

## Using the bot when it's ready

| Need | Ask Cline |
|---|---|
| Stage/qa issue | `Follow AGENTS.md. Offer <id> is not showing for SKU <sku> in <env>, store <store>. Why?` |
| Something wrong on a page | `Follow AGENTS.md. The price on the product page for SKU <sku> in <env> shows <x>, expected <y>. Why?` |
| Works in one env, not another | `Follow AGENTS.md. Offer <id> works in qa but not in stage for SKU <sku>. Why?` |
| Prod issue | `Follow AGENTS.md. Prod issue: <what>, SKU <sku>, around <time>.` Cline reads the public prod APIs and pages itself, compares them with stage, and gives you OpenSearch queries for the logs; paste back the results. |
| Works in stage, not in prod | `Follow AGENTS.md. Offer <id> shows in stage but not in prod for SKU <sku>. Why?` (uses `debug envdiff stage prod api …` on public endpoints) |
| Fast diagnosis (one command) | `npm --prefix tools/debug-bot run -s debug -- diagnose <flow> --env <env> --sku <sku> ...` |
| Find anything in the knowledge | `npm --prefix tools/debug-bot run -s debug -- kb find <words>` / `kb card <flow>` |
| Where does a field come from | `Follow AGENTS.md. Trace <field> on <page> back to its source.` |
| Refresh what's known from real data (profiles, sample runs, observed lineage) | `npm --prefix tools/debug-bot run data:observe` and `observe:flows` (also nightly), then ask Cline to review `.knowledge/data/findings.md` |
| Update knowledge after code changes | `npm --prefix tools/debug-bot run knowledge:update -- --since <branch or commit>`, then ask Cline to refresh `STALE.md` |
| Export for an MCP server / LLM / Vertex | `npm --prefix tools/debug-bot run knowledge:export`, then see `system-knowledge/export/README.md` |
| Confluence | `npm --prefix tools/debug-bot run docs:build` (preview in `system-knowledge/docs/html/`); publishing only when you tell Cline "publish to Confluence" |
